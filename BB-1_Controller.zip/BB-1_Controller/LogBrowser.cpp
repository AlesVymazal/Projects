#include "LogBrowser.h"
#include "ui_LogBrowser.h"

#include <QDateTime>

LogBrowser::LogBrowser(QWidget* parent) : QDialog(parent), ui(new Ui::LogBrowser) {
    ui->setupUi(this);

    connect(ui->pushButton_clear, &QPushButton::clicked, [=]() { ui->textBrowser->clear(); });
}

LogBrowser::~LogBrowser() {
    delete ui;
}

void LogBrowser::writeMessage(LIBS::messageType type, QString msg) {
    QString message;
    QDateTime logTime    = QDateTime(QDateTime::currentDateTime());
    QString log_time_str = logTime.toString("dd.MM. yyyy hh:mm:ss ");
    switch (type) {
        case LIBS::Info:
            //           return;
            message =
                tr("%1<span style=\"color:#3465a4;font-weight:bold;\"> Info: </span>").arg(log_time_str).append(msg);
            ui->textBrowser->append(message);
            message = tr("%1: Info: ").arg(log_time_str).append(msg);
            break;
        case LIBS::Debug:
            //           return;
            message =
                tr("%1<span style=\"color:#4e9a06;font-weight:bold;\"> Debug: </span>").arg(log_time_str).append(msg);
            ui->textBrowser->append(message);
            message = tr("%1: Debug: ").arg(log_time_str).append(msg);
            break;
        case LIBS::Warning:
            message =
                tr("%1<span style=\"color:#f57900;font-weight:bold;\"> Warning: </span>").arg(log_time_str).append(msg);
            ui->textBrowser->append(message);
            message = tr("%1: Warning: ").arg(log_time_str).append(msg);
            break;
        case LIBS::Error:
            message =
                tr("%1<span style=\"color:#cc0000;font-weight:bold;\"> Error: </span>").arg(log_time_str).append(msg);
            ui->textBrowser->append(message);
            message = tr("%1: Error: ").arg(log_time_str).append(msg);
            break;
        case LIBS::FatalError:
            message = tr("%1<span style=\"color:#000000;font-weight:bold;\"> Fatal error: </span>")
                          .arg(log_time_str)
                          .append(msg);
            ui->textBrowser->append(message);
            message = tr("%1: Fatal error: ").arg(log_time_str).append(msg);
            break;
        default:
            break;
    }
}
