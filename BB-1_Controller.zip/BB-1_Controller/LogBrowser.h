#ifndef LOGBROWSER_H
#define LOGBROWSER_H

#include <QDialog>

#include "LIBS.h"

namespace Ui {
    class LogBrowser;
}

class LogBrowser : public QDialog {
    Q_OBJECT

public:
    explicit LogBrowser(QWidget* parent = nullptr);
    ~LogBrowser();

    void writeMessage(LIBS::messageType type, QString msg);

private:
    Ui::LogBrowser* ui;
};

#endif // LOGBROWSER_H
