#include "StageSettingsDialog.h"
#include "config.h"
#include "ui_StageSettingsDialog.h"

#include <QSettings>

#include <QDebug>
#include <QDir>

static int DEFAULT_BAUD_RATE = 115200;

StageSettingsDialog::StageSettingsDialog(QWidget* parent) : QDialog(parent), ui(new Ui::StageSettingsDialog) {
    ui->setupUi(this);
}

StageSettingsDialog::~StageSettingsDialog() {
    delete ui;
}

void StageSettingsDialog::connectTo(LIBSStageV2* stage) {
    DevicePort* prt = stage->Stage()->Driver()->Port();

    // Load baud rate settings
    QSettings t_settings(Config("trinamic").Default(), QSettings::defaultFormat());
    ui->spinBox_ftdiBaudRate->setValue(t_settings.value("private/ftdiPort/BaudRate", DEFAULT_BAUD_RATE).toInt());
    connect(ui->spinBox_ftdiBaudRate, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int value) {
        QSettings i_settings(Config("trinamic").Default(), QSettings::defaultFormat());
        i_settings.setValue("private/ftdiPort/BaudRate", value);
    });

    PortSelectDialog* dlg = prt->CreatePortSelectDlg(this);

    connect(prt, SIGNAL(PortDescriptorChanged(QString)), ui->label_trinamic_port, SLOT(setText(QString)));
    connect(ui->toolButton_trinamic_port, SIGNAL(clicked()), dlg, SLOT(show()));

    // Interlock port settings
    LibsInterlockSystem* interlockSystem = stage->InterlockSystem();

    interlockSystem->SetupConfigGui(ui->tabWidget);

    prt = interlockSystem->Driver()->Port();
    dlg = prt->CreatePortSelectDlg(this);

    connect(prt, SIGNAL(PortDescriptorChanged(QString)), ui->label_interlock_port, SLOT(setText(QString)));
    connect(ui->toolButton_interlock_port, SIGNAL(clicked()), dlg, SLOT(show()));

    // Primary DDG port settings
    LibsDelayGeneratorSystem* delayGenerator = stage->DelayGeneratorSystem();
    prt                                      = delayGenerator->Driver()->Port();
    dlg                                      = prt->CreatePortSelectDlg(this);
    connect(prt, SIGNAL(PortDescriptorChanged(QString)), ui->label_delayGenerator_port, SLOT(setText(QString)));
    connect(ui->toolButton_delayGenerator_port, SIGNAL(clicked()), dlg, SLOT(show()));

    // Secondary DDG port settings
    LibsDelayGeneratorSystem* secondaryDelayGenerator = stage->SecondaryDelayGeneratorSystem();
    prt                                               = secondaryDelayGenerator->Driver()->Port();
    dlg                                               = prt->CreatePortSelectDlg(this);
    connect(
        prt, SIGNAL(PortDescriptorChanged(QString)), ui->label_secondaryDelayGenerator_port, SLOT(setText(QString)));
    connect(ui->toolButton_secondaryDelayGenerator_port, SIGNAL(clicked()), dlg, SLOT(show()));

    // TODO: implement port settings for MRF & MTS like above ^ (first need to create classes for MRF & MTS)

    LibsAttenuator* attentuator = stage->Attenuator();

    QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
    QWidget* NewTab = new QWidget(ui->tabWidget);
    attentuator->SetupConfigGui(NewTab);
    QWidget* axisNum = new QWidget(NewTab);
    QVBoxLayout* lay = new QVBoxLayout(axisNum);
    QSpinBox* spin   = new QSpinBox(axisNum);
    QLabel* lab      = new QLabel(QString("Axis number:"), axisNum);
    lay->addWidget(lab);
    lay->addWidget(spin);
    spin->setMaximum(5);
    spin->setValue(stg.value(QString("private/stage/attAxis"), 3).toInt());
    axisNum->setLayout(lay);
    NewTab->layout()->addWidget(axisNum);
    ui->tabWidget->addTab(NewTab, "Expander");
    connect(spin, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int val) {
        QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
        stg.setValue(QString("private/stage/attAxis"), val);
    });

    NewTab              = new QWidget(ui->tabWidget);
    LinearAxis* focuser = stage->Focuser();
    focuser->SetupConfigGui(NewTab);
    axisNum = new QWidget(NewTab);
    lay     = new QVBoxLayout(axisNum);
    spin    = new QSpinBox(axisNum);
    lab     = new QLabel(QString("Axis number:"), axisNum);
    lay->addWidget(lab);
    lay->addWidget(spin);
    spin->setMaximum(5);
    spin->setValue(stg.value(QString("private/stage/focusAxis"), 5).toInt());
    axisNum->setLayout(lay);
    NewTab->layout()->addWidget(axisNum);
    ui->tabWidget->addTab(NewTab, "Focuser");
    connect(spin, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int val) {
        QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
        stg.setValue(QString("private/stage/focusAxis"), val);
    });
}
