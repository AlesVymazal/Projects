#ifndef STAGESETTINGSDIALOG_H
#define STAGESETTINGSDIALOG_H

#include "stage/libsstage.h"

#include <QDialog>

namespace Ui {
    class StageSettingsDialog;
}

class StageSettingsDialog : public QDialog {
    Q_OBJECT

public:
    explicit StageSettingsDialog(QWidget* parent = nullptr);
    ~StageSettingsDialog();

    void connectTo(LIBSStageV2* stage);

private:
    Ui::StageSettingsDialog* ui;
};

#endif // STAGESETTINGSDIALOG_H
