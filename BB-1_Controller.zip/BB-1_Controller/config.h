#ifndef HCONFIG_H
#define HCONFIG_H

//! trida pro generovani cest ke konfiguracim
//! u nas je ponekud komplexnejsi, neb se v ni resi uzivatelska nastaveni a nazvy ruznych konfiguracnich souboru
//! ponechavam napevno pouze konfiguraci pro motory

#include <QStandardPaths>

class Config 
{
public:
        Config(){}
        Config(QString _file) : file(_file) { }
        ~Config(){}

//        QString Default() { return QStandardPaths::writableLocation(QStandardPaths::ConfigLocation)+ "/" + file + ".xml"; }
        QString Default() { return "./" + file + ".xml"; }
        QString ConfigPrefix() { return file;  }

private:
	QString file;
};


#endif //HCONFIG_H
