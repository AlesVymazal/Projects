#include "libsdelaygeneratorsystemsettingsdialog.h"
#include "ui_libsdelaygeneratorsystemsettingsdialog.h"

LibsDelayGeneratorSystemSettingsDialog::LibsDelayGeneratorSystemSettingsDialog(LibsDelayGeneratorSystem* dg,
                                                                               QWidget* parent)
    : QDialog(parent), ui(new Ui::LibsDelayGeneratorSystemSettingsDialog) {
    ui->setupUi(this);
    m_delayGenerator = dg;

    connect(m_delayGenerator,
            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
            this,
            SLOT(appendMessage(LIBS::messageType, QString)));

    connect(ui->armChannelsPushButton, static_cast<void (QPushButton::*)(bool)>(&QPushButton::clicked), [=]() {
        m_delayGenerator->armChannels();
    });
    connect(ui->softwareTriggerPushButton, static_cast<void (QPushButton::*)(bool)>(&QPushButton::clicked), [=]() {
        m_delayGenerator->softwareTrigger();
    });
    connect(ui->loadAllPushButton, static_cast<void (QPushButton::*)(bool)>(&QPushButton::clicked), [=]() {
        this->loadAllParameters();
    });
    ui->autostartCheckBox->setChecked(m_delayGenerator->m_parameters.value(QString("AutoStart"), true).toBool());
    connect(ui->autostartCheckBox,
            static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::enableAutostart);

    ui->autoPowerUpCheckBox->setChecked(m_delayGenerator->m_autorun);
    connect(ui->autoPowerUpCheckBox,
            static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::enablePowerUpAutostart);

    ui->armChannelsInTriggerModeCheckBox->setChecked(
        m_delayGenerator->m_parameters.value(QString("EnableArmOnShoot"), true).toBool());
    connect(ui->armChannelsInTriggerModeCheckBox,
            static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::enableArmOnShoot);

    ui->sendSoftwareTriggCheckBox->setChecked(
        m_delayGenerator->m_parameters.value(QString("EnableSoftTriggOnShoot"), false).toBool());
    connect(ui->sendSoftwareTriggCheckBox,
            static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::enableSoftTriggOnShoot);

    ui->pulseModeComboBox->setCurrentIndex(m_delayGenerator->m_chanModes[0]);
    connect(
        ui->pulseModeComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            if (idx >= 0 && idx <= 3)
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelMode", Q_ARG(char, 0), Q_ARG(int, idx));
        });

    ui->pulsePeriodSpinBox->setValue(m_delayGenerator->m_period * 1.0e3);
    connect(
        ui->pulsePeriodSpinBox,
        static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
        [=](double period) { QMetaObject::invokeMethod(m_delayGenerator, "setPeriod", Q_ARG(double, period * 1e-3)); });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::periodChanged,
            this,
            [=](double period) { ui->pulsePeriodSpinBox->setValue(period * 1.0e3); },
            Qt::QueuedConnection);

    ui->burstCountSpinBox->setValue(m_delayGenerator->m_chanBurst[0]);
    connect(ui->burstCountSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelBurstCount", Q_ARG(char, 0), Q_ARG(int, count));
    });

    ui->dutyOnSpinBox->setValue(m_delayGenerator->m_chanDutyOn[0]);
    connect(ui->dutyOnSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelDutyCycleOnCount", Q_ARG(char, 0), Q_ARG(int, count));
    });

    ui->dutyOffSpinBox->setValue(m_delayGenerator->m_chanDutyOff[0]);
    connect(ui->dutyOffSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(
            m_delayGenerator, "setChannelDutyCycleOffCount", Q_ARG(char, 0), Q_ARG(int, count - 1));
    });

    ui->extTriggModeComboBox->setCurrentIndex(m_delayGenerator->m_triggMode);
    connect(ui->extTriggModeComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::setExtTriggMode);
    connect(m_delayGenerator, SIGNAL(extTriggModeChanged(int)), ui->extTriggModeComboBox, SLOT(setCurrentIndex(int)));

    ui->extTriggEdgeComboBox->setCurrentIndex(m_delayGenerator->m_triggEdge);
    connect(ui->extTriggEdgeComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::setExtTriggEdge);
    connect(m_delayGenerator, SIGNAL(extTriggEdgeChanged(int)), ui->extTriggEdgeComboBox, SLOT(setCurrentIndex(int)));

    ui->extTriggPolarityComboBox->setCurrentIndex(m_delayGenerator->m_triggPol);
    connect(ui->extTriggPolarityComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            m_delayGenerator,
            &LibsDelayGeneratorSystem::setExtTriggPolarity);
    connect(m_delayGenerator,
            SIGNAL(extTriggPolarityChanged(int)),
            ui->extTriggPolarityComboBox,
            SLOT(setCurrentIndex(int)));

    ui->extTriggThresholdSpinBox->setValue(m_delayGenerator->m_triggLevel);
    connect(ui->extTriggThresholdSpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double level) {
                QMetaObject::invokeMethod(m_delayGenerator, "setExtTriggLevel", Q_ARG(int, qRound(level * 10.0)));
            });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::extTriggLevelChanged,
            this,
            [=](int level) { ui->extTriggThresholdSpinBox->setValue(level * 0.1); },
            Qt::QueuedConnection);

    ui->chanAModeComboBox->setCurrentIndex(m_delayGenerator->m_chanModes[1]);
    ui->chanBModeComboBox->setCurrentIndex(m_delayGenerator->m_chanModes[2]);
    ui->chanCModeComboBox->setCurrentIndex(m_delayGenerator->m_chanModes[3]);
    ui->chanDModeComboBox->setCurrentIndex(m_delayGenerator->m_chanModes[4]);
    connect(
        ui->chanAModeComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            if (idx >= 0 && idx <= 3) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelMode", Q_ARG(char, 1), Q_ARG(int, idx));
                this->setStartButton(false);
            }
        });
    connect(
        ui->chanBModeComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            if (idx >= 0 && idx <= 3) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelMode", Q_ARG(char, 2), Q_ARG(int, idx));
                this->setStartButton(false);
            }
        });
    connect(
        ui->chanCModeComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            if (idx >= 0 && idx <= 3) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelMode", Q_ARG(char, 3), Q_ARG(int, idx));
                this->setStartButton(false);
            }
        });
    connect(
        ui->chanDModeComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            if (idx >= 0 && idx <= 3) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelMode", Q_ARG(char, 4), Q_ARG(int, idx));
                this->setStartButton(false);
            }
        });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelModeChanged,
            this,
            [=](int chan, int mode) {
                if (mode >= 0 && mode <= 3)
                    switch (chan) {
                        case 0:
                            ui->pulseModeComboBox->setCurrentIndex(mode);
                            break;
                        case 1:
                            ui->chanAModeComboBox->setCurrentIndex(mode);
                            break;
                        case 2:
                            ui->chanBModeComboBox->setCurrentIndex(mode);
                            break;
                        case 3:
                            ui->chanCModeComboBox->setCurrentIndex(mode);
                            break;
                        case 4:
                            ui->chanDModeComboBox->setCurrentIndex(mode);
                            break;
                        default:
                            break;
                    }
            },
            Qt::QueuedConnection);

    ui->startPushButton->setChecked(m_delayGenerator->m_chanEnabled[0]);
    ui->runningStateLabel->setText(m_delayGenerator->m_chanEnabled[0] ? QString("Running") : QString("Stopped"));
    if (m_delayGenerator->m_chanEnabled[0])
        ui->runningStateLabel->setStyleSheet(QString("QLabel{color:green;font-weight:bold;}"));
    else
        ui->runningStateLabel->setStyleSheet(QString("QLabel{color:black;font-weight:bold;}"));
    connect(ui->startPushButton, static_cast<void (QPushButton::*)(bool)>(&QPushButton::clicked), [=](bool enable) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelEnabled", Q_ARG(char, 0), Q_ARG(bool, enable));
    });

    setAllChansEnable();

    connect(ui->chanAEnableCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool enable) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelEnabled", Q_ARG(char, 1), Q_ARG(bool, enable));
    });
    connect(ui->chanBEnableCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool enable) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelEnabled", Q_ARG(char, 2), Q_ARG(bool, enable));
    });
    connect(ui->chanCEnableCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool enable) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelEnabled", Q_ARG(char, 3), Q_ARG(bool, enable));
    });
    connect(ui->chanDEnableCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool enable) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelEnabled", Q_ARG(char, 4), Q_ARG(bool, enable));
    });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelEnabledChanged,
            this,
            [=](int chan, bool enabled) {
                switch (chan) {
                    case 0:
                        ui->startPushButton->setChecked(enabled);
                        ui->runningStateLabel->setText(enabled ? QString("Running") : QString("Stopped"));
                        if (enabled)
                            ui->runningStateLabel->setStyleSheet(QString("QLabel{color:green;font-weight:bold;}"));
                        else
                            ui->runningStateLabel->setStyleSheet(QString("QLabel{color:black;font-weight:bold;}"));
                        break;
                    case 1:
                        ui->chanAEnableCheckBox->setChecked(enabled);
                        break;
                    case 2:
                        ui->chanBEnableCheckBox->setChecked(enabled);
                        break;
                    case 3:
                        ui->chanCEnableCheckBox->setChecked(enabled);
                        break;
                    case 4:
                        ui->chanDEnableCheckBox->setChecked(enabled);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    // connect(ui->chanAAmplitudeSpinBox,static_cast<void
    // (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),[=](double
    // level){m_delayGenerator->setChannelLevel(1,level);}); connect(ui->chanBAmplitudeSpinBox,static_cast<void
    // (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),[=](double
    // level){m_delayGenerator->setChannelLevel(2,level);}); connect(ui->chanCAmplitudeSpinBox,static_cast<void
    // (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),[=](double
    // level){m_delayGenerator->setChannelLevel(3,level);}); connect(ui->chanDAmplitudeSpinBox,static_cast<void
    // (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),[=](double
    // level){m_delayGenerator->setChannelLevel(4,level);});
    ui->chanASyncComboBox->setCurrentIndex(m_delayGenerator->m_chanSync[1] > 0 ? m_delayGenerator->m_chanSync[1] - 1
                                                                               : m_delayGenerator->m_chanSync[1]);
    ui->chanBSyncComboBox->setCurrentIndex(m_delayGenerator->m_chanSync[2] > 1 ? m_delayGenerator->m_chanSync[2] - 1
                                                                               : m_delayGenerator->m_chanSync[2]);
    ui->chanCSyncComboBox->setCurrentIndex(m_delayGenerator->m_chanSync[3] > 2 ? m_delayGenerator->m_chanSync[3] - 1
                                                                               : m_delayGenerator->m_chanSync[3]);
    ui->chanDSyncComboBox->setCurrentIndex(m_delayGenerator->m_chanSync[4] > 3 ? m_delayGenerator->m_chanSync[4] - 1
                                                                               : m_delayGenerator->m_chanSync[4]);
    connect(
        ui->chanASyncComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            int index = idx;
            if (idx > 0) {
                index = idx + 1;
            }
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelSync", Q_ARG(char, 1), Q_ARG(int, index));
        });
    connect(
        ui->chanBSyncComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            int index = idx;
            if (idx > 1) {
                index = idx + 1;
            }
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelSync", Q_ARG(char, 2), Q_ARG(int, index));
        });
    connect(
        ui->chanCSyncComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            int index = idx;
            if (idx > 2) {
                index = idx + 1;
            }
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelSync", Q_ARG(char, 3), Q_ARG(int, index));
        });
    connect(
        ui->chanDSyncComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            int index = idx;
            if (idx > 3) {
                index = idx + 1;
            }
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelSync", Q_ARG(char, 4), Q_ARG(int, index));
        });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelSyncChanged,
            this,
            [=](int chan, int sync) {
                switch (chan) {
                    case 1:
                        if (sync > 0)
                            ui->chanASyncComboBox->setCurrentIndex(sync - 1);
                        else
                            ui->chanASyncComboBox->setCurrentIndex(sync);
                        break;
                    case 2:
                        if (sync > 1)
                            ui->chanBSyncComboBox->setCurrentIndex(sync - 1);
                        else
                            ui->chanBSyncComboBox->setCurrentIndex(sync);
                        break;
                    case 3:
                        if (sync > 2)
                            ui->chanCSyncComboBox->setCurrentIndex(sync - 1);
                        else
                            ui->chanCSyncComboBox->setCurrentIndex(sync);
                        break;
                    case 4:
                        if (sync > 3)
                            ui->chanDSyncComboBox->setCurrentIndex(sync - 1);
                        else
                            ui->chanDSyncComboBox->setCurrentIndex(sync);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    setAllChansDelays();
    connect(ui->chanADelaySpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double delay) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelDelay", Q_ARG(char, 1), Q_ARG(double, delay * 1.0e-6));
            });
    connect(ui->chanBDelaySpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double delay) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelDelay", Q_ARG(char, 2), Q_ARG(double, delay * 1.0e-6));
            });
    connect(ui->chanCDelaySpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double delay) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelDelay", Q_ARG(char, 3), Q_ARG(double, delay * 1.0e-6));
            });
    connect(ui->chanDDelaySpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double delay) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelDelay", Q_ARG(char, 4), Q_ARG(double, delay * 1.0e-6));
            });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelDelayChanged,
            this,
            [=](int chan, double delay) {
                switch (chan) {
                    case 1:
                        ui->chanADelaySpinBox->setValue(delay * 1.0e6);
                        break;
                    case 2:
                        ui->chanBDelaySpinBox->setValue(delay * 1.0e6);
                        break;
                    case 3:
                        ui->chanCDelaySpinBox->setValue(delay * 1.0e6);
                        break;
                    case 4:
                        ui->chanDDelaySpinBox->setValue(delay * 1.0e6);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->chanAWidthSpinBox->setValue(m_delayGenerator->m_chanWidth[1] * 1.0e6);
    ui->chanBWidthSpinBox->setValue(m_delayGenerator->m_chanWidth[2] * 1.0e6);
    ui->chanCWidthSpinBox->setValue(m_delayGenerator->m_chanWidth[3] * 1.0e6);
    ui->chanDWidthSpinBox->setValue(m_delayGenerator->m_chanWidth[4] * 1.0e6);
    connect(ui->chanAWidthSpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double width) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelWidth", Q_ARG(char, 1), Q_ARG(double, width * 1.0e-6));
            });
    connect(ui->chanBWidthSpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double width) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelWidth", Q_ARG(char, 2), Q_ARG(double, width * 1.0e-6));
            });
    connect(ui->chanCWidthSpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double width) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelWidth", Q_ARG(char, 3), Q_ARG(double, width * 1.0e-6));
            });
    connect(ui->chanDWidthSpinBox,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double width) {
                QMetaObject::invokeMethod(
                    m_delayGenerator, "setChannelWidth", Q_ARG(char, 4), Q_ARG(double, width * 1.0e-6));
            });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelWidthChanged,
            this,
            [=](int chan, double width) {
                switch (chan) {
                    case 1:
                        ui->chanAWidthSpinBox->setValue(width * 1.0e6);
                        break;
                    case 2:
                        ui->chanBWidthSpinBox->setValue(width * 1.0e6);
                        break;
                    case 3:
                        ui->chanCWidthSpinBox->setValue(width * 1.0e6);
                        break;
                    case 4:
                        ui->chanDWidthSpinBox->setValue(width * 1.0e6);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->chanAWaitSpinBox->setValue(m_delayGenerator->m_chanWait[1]);
    ui->chanBWaitSpinBox->setValue(m_delayGenerator->m_chanWait[2]);
    ui->chanCWaitSpinBox->setValue(m_delayGenerator->m_chanWait[3]);
    ui->chanDWaitSpinBox->setValue(m_delayGenerator->m_chanWait[4]);
    connect(ui->chanAWaitSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int wait) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelWaitCount", Q_ARG(char, 1), Q_ARG(int, wait));
    });
    connect(ui->chanBWaitSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int wait) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelWaitCount", Q_ARG(char, 2), Q_ARG(int, wait));
    });
    connect(ui->chanCWaitSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int wait) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelWaitCount", Q_ARG(char, 3), Q_ARG(int, wait));
    });
    connect(ui->chanDWaitSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int wait) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelWaitCount", Q_ARG(char, 4), Q_ARG(int, wait));
    });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelWaitCountChanged,
            this,
            [=](int chan, int wait) {
                switch (chan) {
                    case 1:
                        ui->chanAWaitSpinBox->setValue(wait);
                        break;
                    case 2:
                        ui->chanBWaitSpinBox->setValue(wait);
                        break;
                    case 3:
                        ui->chanCWaitSpinBox->setValue(wait);
                        break;
                    case 4:
                        ui->chanDWaitSpinBox->setValue(wait);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->chanAPolarityComboBox->setCurrentIndex(m_delayGenerator->m_chanPolarity[1]);
    ui->chanBPolarityComboBox->setCurrentIndex(m_delayGenerator->m_chanPolarity[2]);
    ui->chanCPolarityComboBox->setCurrentIndex(m_delayGenerator->m_chanPolarity[3]);
    ui->chanDPolarityComboBox->setCurrentIndex(m_delayGenerator->m_chanPolarity[4]);
    connect(ui->chanAPolarityComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            [=](int idx) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelPolarity", Q_ARG(char, 1), Q_ARG(int, idx));
            });
    connect(ui->chanBPolarityComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            [=](int idx) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelPolarity", Q_ARG(char, 2), Q_ARG(int, idx));
            });
    connect(ui->chanCPolarityComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            [=](int idx) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelPolarity", Q_ARG(char, 3), Q_ARG(int, idx));
            });
    connect(ui->chanDPolarityComboBox,
            static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            [=](int idx) {
                QMetaObject::invokeMethod(m_delayGenerator, "setChannelPolarity", Q_ARG(char, 4), Q_ARG(int, idx));
            });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelPolarityChanged,
            this,
            [=](int chan, int pol) {
                if (pol >= 0 && pol < 3)
                    switch (chan) {
                        case 1:
                            ui->chanAPolarityComboBox->setCurrentIndex(pol);
                            break;
                        case 2:
                            ui->chanBPolarityComboBox->setCurrentIndex(pol);
                            break;
                        case 3:
                            ui->chanCPolarityComboBox->setCurrentIndex(pol);
                            break;
                        case 4:
                            ui->chanDPolarityComboBox->setCurrentIndex(pol);
                            break;
                        default:
                            break;
                    }
            },
            Qt::QueuedConnection);
    ui->chanAGateComboBox->setCurrentIndex(m_delayGenerator->m_chanGateMode[1]);
    ui->chanBGateComboBox->setCurrentIndex(m_delayGenerator->m_chanGateMode[2]);
    ui->chanCGateComboBox->setCurrentIndex(m_delayGenerator->m_chanGateMode[3]);
    ui->chanDGateComboBox->setCurrentIndex(m_delayGenerator->m_chanGateMode[4]);
    connect(
        ui->chanAGateComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelGateMode", Q_ARG(char, 1), Q_ARG(int, idx));
        });
    connect(
        ui->chanBGateComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelGateMode", Q_ARG(char, 2), Q_ARG(int, idx));
        });
    connect(
        ui->chanCGateComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelGateMode", Q_ARG(char, 3), Q_ARG(int, idx));
        });
    connect(
        ui->chanDGateComboBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), [=](int idx) {
            QMetaObject::invokeMethod(m_delayGenerator, "setChannelGateMode", Q_ARG(char, 4), Q_ARG(int, idx));
        });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelGateModeChanged,
            this,
            [=](int chan, int gate) {
                if (gate >= 0 && gate <= 3)
                    switch (chan) {
                        case 1:
                            ui->chanAGateComboBox->setCurrentIndex(gate);
                            break;
                        case 2:
                            ui->chanBGateComboBox->setCurrentIndex(gate);
                            break;
                        case 3:
                            ui->chanCGateComboBox->setCurrentIndex(gate);
                            break;
                        case 4:
                            ui->chanDGateComboBox->setCurrentIndex(gate);
                            break;
                        default:
                            break;
                    }
            },
            Qt::QueuedConnection);

    ui->chanABurstCountSpinBox->setValue(m_delayGenerator->m_chanBurst[1]);
    ui->chanBBurstCountSpinBox->setValue(m_delayGenerator->m_chanBurst[2]);
    ui->chanCBurstCountSpinBox->setValue(m_delayGenerator->m_chanBurst[3]);
    ui->chanDBurstCountSpinBox->setValue(m_delayGenerator->m_chanBurst[4]);
    connect(ui->chanABurstCountSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelBurstCount", Q_ARG(char, 1), Q_ARG(int, count));
    });
    connect(ui->chanBBurstCountSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelBurstCount", Q_ARG(char, 2), Q_ARG(int, count));
    });
    connect(ui->chanCBurstCountSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelBurstCount", Q_ARG(char, 3), Q_ARG(int, count));
    });
    connect(ui->chanDBurstCountSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelBurstCount", Q_ARG(char, 4), Q_ARG(int, count));
    });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelBurstCountChanged,
            this,
            [=](int chan, int burst) {
                switch (chan) {
                    case 1:
                        ui->chanABurstCountSpinBox->setValue(burst);
                        break;
                    case 2:
                        ui->chanBBurstCountSpinBox->setValue(burst);
                        break;
                    case 3:
                        ui->chanCBurstCountSpinBox->setValue(burst);
                        break;
                    case 4:
                        ui->chanDBurstCountSpinBox->setValue(burst);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->chanADutyOnSpinBox->setValue(m_delayGenerator->m_chanDutyOn[1]);
    ui->chanBDutyOnSpinBox->setValue(m_delayGenerator->m_chanDutyOn[2]);
    ui->chanCDutyOnSpinBox->setValue(m_delayGenerator->m_chanDutyOn[3]);
    ui->chanDDutyOnSpinBox->setValue(m_delayGenerator->m_chanDutyOn[4]);
    connect(ui->chanADutyOnSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelDutyCycleOnCount", Q_ARG(char, 1), Q_ARG(int, count));
    });
    connect(ui->chanBDutyOnSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelDutyCycleOnCount", Q_ARG(char, 2), Q_ARG(int, count));
    });
    connect(ui->chanCDutyOnSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelDutyCycleOnCount", Q_ARG(char, 3), Q_ARG(int, count));
    });
    connect(ui->chanDDutyOnSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelDutyCycleOnCount", Q_ARG(char, 4), Q_ARG(int, count));
    });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelDutyCycleOnCountChanged,
            this,
            [=](int chan, int count) {
                switch (chan) {
                    case 1:
                        ui->chanADutyOnSpinBox->setValue(count);
                        break;
                    case 2:
                        ui->chanBDutyOnSpinBox->setValue(count);
                        break;
                    case 3:
                        ui->chanCDutyOnSpinBox->setValue(count);
                        break;
                    case 4:
                        ui->chanDDutyOnSpinBox->setValue(count);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->chanADutyOffSpinBox->setValue(m_delayGenerator->m_chanDutyOff[1]);
    ui->chanBDutyOffSpinBox->setValue(m_delayGenerator->m_chanDutyOff[2]);
    ui->chanCDutyOffSpinBox->setValue(m_delayGenerator->m_chanDutyOff[3]);
    ui->chanDDutyOffSpinBox->setValue(m_delayGenerator->m_chanDutyOff[4]);
    connect(ui->chanADutyOffSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(
            m_delayGenerator, "setChannelDutyCycleOffCount", Q_ARG(char, 1), Q_ARG(int, count - 1));
    });
    connect(ui->chanBDutyOffSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(
            m_delayGenerator, "setChannelDutyCycleOffCount", Q_ARG(char, 2), Q_ARG(int, count - 1));
    });
    connect(ui->chanCDutyOffSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(
            m_delayGenerator, "setChannelDutyCycleOffCount", Q_ARG(char, 3), Q_ARG(int, count - 1));
    });
    connect(ui->chanDDutyOffSpinBox, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int count) {
        QMetaObject::invokeMethod(
            m_delayGenerator, "setChannelDutyCycleOffCount", Q_ARG(char, 4), Q_ARG(int, count - 1));
    });
    connect(m_delayGenerator,
            &LibsDelayGeneratorSystem::channelDutyCycleOffCountChanged,
            this,
            [=](int chan, int count) {
                switch (chan) {
                    case 1:
                        ui->chanADutyOffSpinBox->setValue(count + 1);
                        break;
                    case 2:
                        ui->chanBDutyOffSpinBox->setValue(count + 1);
                        break;
                    case 3:
                        ui->chanCDutyOffSpinBox->setValue(count + 1);
                        break;
                    case 4:
                        ui->chanDDutyOffSpinBox->setValue(count + 1);
                        break;
                    default:
                        break;
                }
            },
            Qt::QueuedConnection);

    ui->customDeviceNameLineEdit->setText(m_delayGenerator->getDeviceName());

    ui->chanACustomNameLineEdit->setText(m_delayGenerator->getChannelName(0));
    ui->chanBCustomNameLineEdit->setText(m_delayGenerator->getChannelName(1));
    ui->chanCCustomNameLineEdit->setText(m_delayGenerator->getChannelName(2));
    ui->chanDCustomNameLineEdit->setText(m_delayGenerator->getChannelName(3));

    connect(ui->customDeviceNameLineEdit,
            SIGNAL(textChanged(QString)),
            m_delayGenerator,
            SLOT(setDeviceCustomName(QString)));
    connect(ui->chanACustomNameLineEdit, &QLineEdit::textChanged, [=](QString name) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelCustomName", Q_ARG(char, 0), Q_ARG(QString, name));
    });
    connect(ui->chanBCustomNameLineEdit, &QLineEdit::textChanged, [=](QString name) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelCustomName", Q_ARG(char, 1), Q_ARG(QString, name));
    });
    connect(ui->chanCCustomNameLineEdit, &QLineEdit::textChanged, [=](QString name) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelCustomName", Q_ARG(char, 2), Q_ARG(QString, name));
    });
    connect(ui->chanDCustomNameLineEdit, &QLineEdit::textChanged, [=](QString name) {
        QMetaObject::invokeMethod(m_delayGenerator, "setChannelCustomName", Q_ARG(char, 3), Q_ARG(QString, name));
    });

    muxToUIHandler(1, m_delayGenerator->m_chanMux[1]);
    muxToUIHandler(2, m_delayGenerator->m_chanMux[2]);
    muxToUIHandler(3, m_delayGenerator->m_chanMux[3]);
    muxToUIHandler(4, m_delayGenerator->m_chanMux[4]);
    connect(ui->chanAmultiACheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(1);
    });
    connect(ui->chanAmultiBCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(1);
    });
    connect(ui->chanAmultiCCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(1);
    });
    connect(ui->chanAmultiDCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(1);
    });

    connect(ui->chanBmultiACheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(2);
    });
    connect(ui->chanBmultiBCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(2);
    });
    connect(ui->chanBmultiCCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(2);
    });
    connect(ui->chanBmultiDCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(2);
    });

    connect(ui->chanCmultiACheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(3);
    });
    connect(ui->chanCmultiBCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(3);
    });
    connect(ui->chanCmultiCCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(3);
    });
    connect(ui->chanCmultiDCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(3);
    });

    connect(ui->chanDmultiACheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(4);
    });
    connect(ui->chanDmultiBCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(4);
    });
    connect(ui->chanDmultiCCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(4);
    });
    connect(ui->chanDmultiDCheckBox, static_cast<void (QCheckBox::*)(bool)>(&QCheckBox::clicked), [=](bool) {
        uiToMuxHandler(4);
    });

    connect(m_delayGenerator, SIGNAL(channelMultiplexerChanged(char, int)), this, SLOT(muxToUIHandler(char, int)));

    connect(ui->storePushButton, &QPushButton::clicked, [=](bool) {
        bool ok = false;
        int slot =
            QInputDialog::getInt(this, tr("Save configuration"), tr("Select internal memory slot"), 1, 1, 6, 1, &ok);
        if (ok)
            QMetaObject::invokeMethod(m_delayGenerator, "saveDeviceState", Q_ARG(int, slot));
    });

    connect(ui->restorePushButton, &QPushButton::clicked, [=](bool) {
        bool ok = false;
        int slot =
            QInputDialog::getInt(this, tr("Configuration recall"), tr("Select internal memory slot"), 1, 1, 6, 1, &ok);
        if (ok) {
            QProgressDialog* dialog = new QProgressDialog(this);
            dialog->setMaximum(0);
            dialog->setMinimum(0);
            dialog->setValue(0);
            dialog->show();
            dialog->setCancelButton(nullptr);
            dialog->setLabelText(QString("Loading parameters ..."));
            connect(
                m_delayGenerator, &LibsDelayGeneratorSystem::allSettingsUpdated, dialog, &QProgressDialog::deleteLater);
            QMetaObject::invokeMethod(m_delayGenerator, "recallDeviceState", Q_ARG(int, slot));
        }
    });
}

LibsDelayGeneratorSystemSettingsDialog::~LibsDelayGeneratorSystemSettingsDialog() {
    delete ui;
}

void LibsDelayGeneratorSystemSettingsDialog::loadAllParameters() {
    QProgressDialog* dialog = new QProgressDialog(this);
    dialog->setMaximum(0);
    dialog->setMinimum(0);
    dialog->setValue(0);
    dialog->show();
    dialog->setCancelButton(nullptr);
    dialog->setLabelText(QString("Loading parameters ..."));
    connect(m_delayGenerator, &LibsDelayGeneratorSystem::allSettingsUpdated, dialog, &QProgressDialog::deleteLater);
    QMetaObject::invokeMethod(m_delayGenerator, "updateAllSettings");
}

void LibsDelayGeneratorSystemSettingsDialog::setAllChansDelays() {
    ui->chanADelaySpinBox->setValue(m_delayGenerator->m_chanDelay[1] * 1.0e6);
    ui->chanBDelaySpinBox->setValue(m_delayGenerator->m_chanDelay[2] * 1.0e6);
    ui->chanCDelaySpinBox->setValue(m_delayGenerator->m_chanDelay[3] * 1.0e6);
    ui->chanDDelaySpinBox->setValue(m_delayGenerator->m_chanDelay[4] * 1.0e6);
}

void LibsDelayGeneratorSystemSettingsDialog::setAllChansEnable() {
    ui->startPushButton->setChecked(m_delayGenerator->m_chanEnabled[0]);
    ui->chanAEnableCheckBox->setChecked(m_delayGenerator->m_chanEnabled[1]);
    ui->chanBEnableCheckBox->setChecked(m_delayGenerator->m_chanEnabled[2]);
    ui->chanCEnableCheckBox->setChecked(m_delayGenerator->m_chanEnabled[3]);
    ui->chanDEnableCheckBox->setChecked(m_delayGenerator->m_chanEnabled[4]);
}

void LibsDelayGeneratorSystemSettingsDialog::appendMessage(LIBS::messageType mType, QString msg) {
    QString message;
    QDateTime logTime    = QDateTime(QDateTime::currentDateTime());
    QString log_time_str = logTime.toString("dd.MM. yyyy hh:mm:ss ");
    /*    ui->logTableWidget->insertRow(ui->logTableWidget->rowCount());
        ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,0,new QTableWidgetItem(log_time_str));
        ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,2,new QTableWidgetItem(msg));
    */
    switch (mType) {
        case LIBS::Info:
            message =
                tr("%1<span style=\"color:#3465a4;font-weight:bold;\"> Info: </span>").arg(log_time_str).append(msg);
            ui->logTextBrowser->append(message);
            //            ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,1,new
            //            QTableWidgetItem(QString("Info")));
            break;
        case LIBS::Debug:
            message =
                tr("%1<span style=\"color:#4e9a06;font-weight:bold;\"> Debug: </span>").arg(log_time_str).append(msg);
            ui->logTextBrowser->append(message);
            //            ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,1,new
            //            QTableWidgetItem(QString("Debug")));
            break;
        case LIBS::Warning:
            message =
                tr("%1<span style=\"color:#f57900;font-weight:bold;\"> Warning: </span>").arg(log_time_str).append(msg);
            ui->logTextBrowser->append(message);
            //            ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,1,new
            //            QTableWidgetItem(QString("Warning")));
            break;
        case LIBS::Error:
            message =
                tr("%1<span style=\"color:#cc0000;font-weight:bold;\"> Error: </span>").arg(log_time_str).append(msg);
            ui->logTextBrowser->append(message);
            //            ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,1,new
            //            QTableWidgetItem(QString("Error")));
            break;
        case LIBS::FatalError:
            message = tr("%1<span style=\"color:#000000;font-weight:bold;\"> Fatal error: </span>")
                          .arg(log_time_str)
                          .append(msg);
            ui->logTextBrowser->append(message);
            //            ui->logTableWidget->setItem(ui->logTableWidget->rowCount()-1,1,new
            //            QTableWidgetItem(QString("Fatal error")));
            break;
        default:
            break;
    }
}

void LibsDelayGeneratorSystemSettingsDialog::uiToMuxHandler(char chan) {
    switch (chan) {
        case 1:
            QMetaObject::invokeMethod(m_delayGenerator,
                                      "setChannelMultiplexer",
                                      Q_ARG(char, 1),
                                      Q_ARG(bool, ui->chanAmultiACheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiBCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiCCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiDCheckBox->isChecked()));
            break;
        case 2:
            QMetaObject::invokeMethod(m_delayGenerator,
                                      "setChannelMultiplexer",
                                      Q_ARG(char, 2),
                                      Q_ARG(bool, ui->chanAmultiACheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiBCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiCCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiDCheckBox->isChecked()));
            break;
        case 3:
            QMetaObject::invokeMethod(m_delayGenerator,
                                      "setChannelMultiplexer",
                                      Q_ARG(char, 3),
                                      Q_ARG(bool, ui->chanAmultiACheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiBCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiCCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiDCheckBox->isChecked()));
            break;
        case 4:
            QMetaObject::invokeMethod(m_delayGenerator,
                                      "setChannelMultiplexer",
                                      Q_ARG(char, 4),
                                      Q_ARG(bool, ui->chanAmultiACheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiBCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiCCheckBox->isChecked()),
                                      Q_ARG(bool, ui->chanAmultiDCheckBox->isChecked()));
            break;
    }
}

void LibsDelayGeneratorSystemSettingsDialog::muxToUIHandler(char chan, int mux) {
    switch (chan) {
        case 1:
            ui->chanAmultiACheckBox->setChecked((mux & (1 << 0)) > 0);
            ui->chanAmultiBCheckBox->setChecked((mux & (1 << 1)) > 0);
            ui->chanAmultiCCheckBox->setChecked((mux & (1 << 2)) > 0);
            ui->chanAmultiDCheckBox->setChecked((mux & (1 << 3)) > 0);
            break;
        case 2:
            ui->chanBmultiACheckBox->setChecked((mux & (1 << 0)) > 0);
            ui->chanBmultiBCheckBox->setChecked((mux & (1 << 1)) > 0);
            ui->chanBmultiCCheckBox->setChecked((mux & (1 << 2)) > 0);
            ui->chanBmultiDCheckBox->setChecked((mux & (1 << 3)) > 0);
            break;
        case 3:
            ui->chanCmultiACheckBox->setChecked((mux & (1 << 0)) > 0);
            ui->chanCmultiBCheckBox->setChecked((mux & (1 << 1)) > 0);
            ui->chanCmultiCCheckBox->setChecked((mux & (1 << 2)) > 0);
            ui->chanCmultiDCheckBox->setChecked((mux & (1 << 3)) > 0);
            break;
        case 4:
            ui->chanDmultiACheckBox->setChecked((mux & (1 << 0)) > 0);
            ui->chanDmultiBCheckBox->setChecked((mux & (1 << 1)) > 0);
            ui->chanDmultiCCheckBox->setChecked((mux & (1 << 2)) > 0);
            ui->chanDmultiDCheckBox->setChecked((mux & (1 << 3)) > 0);
            break;
    }
}

void LibsDelayGeneratorSystemSettingsDialog::setStartButton(bool enabled) {
    ui->startPushButton->blockSignals(true);
    ui->startPushButton->setChecked(enabled);
    ui->startPushButton->blockSignals(false);
}
