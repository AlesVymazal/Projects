#ifndef LIBSDELAYGENERATORSYSTEMSETTINGSDIALOG_H
#define LIBSDELAYGENERATORSYSTEMSETTINGSDIALOG_H

#include "stage/libsdelaygeneratorsystem.h"
#include <QDialog>
#include <QInputDialog>
#include <QProgressDialog>

namespace Ui {
    class LibsDelayGeneratorSystemSettingsDialog;
}

class LibsDelayGeneratorSystemSettingsDialog : public QDialog {
    Q_OBJECT

public:
    explicit LibsDelayGeneratorSystemSettingsDialog(LibsDelayGeneratorSystem* dg, QWidget* parent = nullptr);
    ~LibsDelayGeneratorSystemSettingsDialog();
    void loadAllParameters();
    void setAllChansDelays();
    void setAllChansEnable();

public slots:
    void appendMessage(LIBS::messageType mType, QString msg);
    void uiToMuxHandler(char chan);
    void muxToUIHandler(char chan, int mux);

private:
    void setStartButton(bool enabled);

private:
    Ui::LibsDelayGeneratorSystemSettingsDialog* ui;
    LibsDelayGeneratorSystem* m_delayGenerator;
};

#endif // LIBSDELAYGENERATORSYSTEMSETTINGSDIALOG_H
