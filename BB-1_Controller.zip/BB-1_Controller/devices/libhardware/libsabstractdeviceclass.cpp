#include "libsabstractdeviceclass.h"

LibsAbstractDeviceClass::LibsAbstractDeviceClass(QObject *parent) :
    QObject(parent)
{
}
