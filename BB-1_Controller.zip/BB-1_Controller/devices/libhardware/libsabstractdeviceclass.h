/*!
 *  \file libsabstractdelaygenerator.h
 *
 *  \author David
 *
 *  \date 15.6. 2014
 *
 *  \brief Header with abstract class for devices used within laser pulse
 */

#ifndef LIBSABSTRACTDEVICECLASS_H
#define LIBSABSTRACTDEVICECLASS_H

//#if defined(LIBHARDWARE_LIBRARY)
//#  define LIBHARDWARESHARED_EXPORT Q_DECL_EXPORT
//#else
//#  define LIBHARDWARESHARED_EXPORT Q_DECL_IMPORT
//#endif

#include "LIBS.h"
#include <QDockWidget>
#include <QObject>
#include <QVariantMap>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>

/*!
 * \brief The LibsAbstractDeviceClass class is pure abstract class and defines required device methods
 *
 * This class defines deviceType list to determine device subtypes. Enum
 * responseTypes is used for laser pulse state machine to determine state of
 * device.
 *
 * \note This class should be reimplemented as QPlugin subclass.
 */
class /*LIBHARDWARESHARED_EXPORT*/ LibsAbstractDeviceClass : public QObject {
    Q_OBJECT

public:
    /*!
     * \brief The deviceType enum determines the type of device subclass
     *
     * Abstract devices are further subclasses of either LibsAbstractDelayGenerator
     * LibsAbstractLaser and/or LibsAbstractMonochromator.
     *
     * \note LibsAbstractMonochromator is not defined.
     */
    enum deviceType { devLaser, devDelayGenerator, devMonochromator, devOther };

    /*!
     * \brief The responseType enum determines the type of response given for laser pulse state machine
     *
     *  This enumeration shows that state machine should either continue, stop or retry requested operation.
     *
     */
    enum responseType {
        fail,  //!< This type of response determines unrecoverable error and state machine should stop
        retry, //!< This type of response states that device was unable to complete operation and request should be
               //!< repeated
        cont   //!< This type of response states that device has succefully completed operation
    };
    /*!
     * \brief LibsAbstractDeviceClass default constructor, currently empty.
     * \param parent
     */
    explicit LibsAbstractDeviceClass(QObject* parent = 0);

    /*!
     * \brief ~LibsAbstractDeviceClass default empty destructor.
     */
    virtual ~LibsAbstractDeviceClass() {
    }

    /*!
     * \brief pluginName constant string that identifies plugin.
     * \return
     */
    //    virtual QString pluginName() = 0;

    /*!
     * \brief initializeDevice this method is first method called by laser pulse state machine.
     *
     * State machine determining the laser pulse devices order calls first initialzation phase
     * of each device to ensure that each device is ready to be triggered or finalized. This is
     * applicable for measurement devices such as camera, that are synchronized via electrical
     * pulses emited from either delay generator nor laser.
     *
     * \return returns status of the device \sa responseType.
     */
    virtual responseType initializeDevice() = 0;

    /*!
     * \brief triggerDevice this method is called whent the laser pulse should be shooted.
     *
     * This method is used when devices should be either software triggered or internally
     * triggered. Devices waiting for external signals and devices that are not
     * part of the pulse initiation should return cont responseType.
     *
     * \return returns status of the device \sa responseType.
     */
    virtual responseType triggerDevice() = 0;

    /*!
     * \brief finalizeDevice this method is called to wait for succesfull finish of the deviceType.
     *
     * This method is used for finalizing the device. Devices that are waitin for end of the pulse
     * such as external cameras and spectrograph should be checked via this function. When data is
     * not ready (e.g. image retreived from camera) device should return retry state, otherwise it
     * should be safe to continue. On return of fail the state machine is stopped.
     *
     * \return returns status of the device \sa responseType.
     */
    virtual responseType finalizeDevice() = 0;

    /*!
     * \brief getDeviceName returns name of the device.
     *
     * Default name is empty and the device name should be vendor and device instance specific.
     *
     * \return returns QString with the device name.
     */
    virtual QString getDeviceName() = 0;

    /*!
     * \brief getDeviceType returns device subclass type.
     *
     * This method specifies subclass of the device.
     *
     * \return returns device subclass.
     */
    virtual deviceType getDeviceType() = 0;

    /*!
     * \brief getQuickSettingsWidget returns QWidget which contains essential controls.
     *
     * Returned QWidget is used for show parameters that directly influence
     * laser pulse generation (gate delay, number of accumulations, ...).
     *
     * \return returns QWidget to be shown.
     */
    virtual QWidget* getQuickSettingsWidget() = 0;

    /*!
     * \brief fillQuickSettingsWidget this method is used to update quick settings widget.
     *
     * This method can be used to update any widget to contain current quick
     * settings. In most cases is this function used internally to update quick
     * widget after settings dialog.
     *
     * \param widget determines the widget to be updated (filled).
     */
    virtual void fillQuickSettingsWidget(QWidget* widget) = 0;

    /*!
     * \brief writeSettings this method stores internal settings using xmlWriter.
     *
     * This method should create xml configuration, that allows full restore of
     * the device paramters.
     *
     * \param xmlWriter pointer to QXmlStreamWriter which allows writing the config file.
     */
    virtual void writeSettings(QXmlStreamWriter* xmlWriter) {
        Q_UNUSED(xmlWriter)
    }

    /*!
     * \brief readSettings this method is used to restore internal settings using xmlReader.
     *
     * This method should restore complete device configuration.
     *
     * \param xmlReader pointer to QXmlStream reader to read configuration from.
     */
    virtual void readSettings(QXmlStreamReader* xmlReader) {
        Q_UNUSED(xmlReader)
    }

    /*!
     * \brief autoStartEnabled determines state and capability of device autostart function.
     *
     * \return  returns true if device is capable of autostart (and autostart is enabled).
     */
    virtual bool autoStartEnabled() = 0;

    /*!
     * \brief dockWidget determines, whether it can show additional information in docking widget.
     *
     * \return return QDockWidget* or nullptr if device can not show additional information
     */
    virtual QDockWidget* dockWidget() {
        return nullptr;
    }

    /*!
     * \brief appendMetadata this method enables storage of parameters in ati file.
     *
     */
    virtual void appendMetadata(QVariantMap& metaData){Q_UNUSED(metaData)}

    signals :
        /*!
         * \brief deviceInitialized signal that is emited after succesfull initialization.
         */
        void deviceInitialized();

    /*!
     * \brief deviceTriggered signal that is emited after succesfull trigger.
     */
    void deviceTriggered();

    /*!
     * \brief deviceFinalized signal that is emited after finalization of the device.
     */
    void deviceFinalized();

    /*!
     * \brief sendDebugMessage signal used to pass messages to log.
     * \param mType type of message which is sent.
     * \param msg content of the message.
     */
    void sendDebugMessage(LIBS::messageType mType, QString msg);

    /*!
     * \brief quickSettingsChanged signal that is emited when quickSettings widgets should be updated.
     */
    void quickSettingsChanged();
public slots:
    /*!
     * \brief showSettingsDialog this method raises modal settings dialog for device.
     *
     * This is overloaded method for use with simple push buttons which don't
     * offer any instanse of QWidget to be passed.
     */
    virtual void showSettingsDialog() = 0;

    /*!
     * \brief showSettingsDialog this method raises modal settings dialog for device.
     *
     * If QWidget is given this method shows modal dialog as a parent of top.
     *
     * \param top QWidget parent of the modal dialog.
     */
    virtual void showSettingsDialog(QWidget* top) = 0;

    /*!
     * \brief autoStart is called for autostart enabled devices.
     *
     * This method is called when initializing the core application.
     *
     */
    virtual void autoStart() = 0;
};

class /*LIBHARDWARESHARED_EXPORT*/ LibsAbstractDeviceFactory {
public:
    virtual QString pluginName()                                             = 0;
    virtual LibsAbstractDeviceClass* createDevice(QObject* parent = nullptr) = 0;
};

// Q_DECLARE_INTERFACE(LibsAbstractDeviceFactory, "AtomTraceSuite.ChamberAbstractDeviceFactory")

#endif // LIBSABSTRACTDEVICECLASS_H
