#include "modulerangefinder.h"


ModuleRangeFinder::ModuleRangeFinder(TrinamicController *tmcmController, unsigned char address) : TMCMGPIO(address, tmcmController)
{
    trinamicDriver = tmcmController;
    //isEnabled = false;
}

void ModuleRangeFinder::Message(MirrorSystemCommands value)
{
    int ret=-1;
    static int Action = value;
    if((ret=trinamicDriver->SendCommand(Action,Type,0,0))==TMCMGPIO::STAT_OK)
    {
        emit sendDebugMessage(LIBS::Info,QString("Start Measuring"));
    }
    if((ret=trinamicDriver->SendCommand(Action,Type,0,0))==TMCMGPIO::STAT_OK)
    {
        emit sendDebugMessage(LIBS::Info,QString("Stop Measuring"));
    }
    if((ret=trinamicDriver->SendCommand(Action,Type,0,0))==TMCMGPIO::STAT_OK)
    {
        emit sendDebugMessage(LIBS::Info,QString("Reading Values"));

        switch (ret) {
            case 8:
                emit sendDebugMessage(LIBS::Info,QString("None Measuring"));
                break;
            case 10:
                emit sendDebugMessage(LIBS::Info,QString("Hardware Error"));
                break;
            case 15:
                emit sendDebugMessage(LIBS::Info,QString("Poor Reflex"));
                break;
            case 16:
                emit sendDebugMessage(LIBS::Info,QString("Strong Reflex"));
                break;
            case 17:
                emit sendDebugMessage(LIBS::Info,QString("Too light reflex"));
                break;
        }
    }
}
