#ifndef MODULERANGEFINDER_H
#define MODULERANGEFINDER_H

#include <QObject>
#include "../stage/hw_trinamic.h"
#include "LIBS.h"


class ModuleRangeFinder: public TMCMGPIO{

    Q_OBJECT
    public:
    ModuleRangeFinder(TrinamicController *tmcmController, unsigned char address);

    enum MirrorSystemCommands{
        StartMeasuring = 41,
        StopMeasuring = 42,
        Read = 43,
    };

    enum MirrorSystemCommandsType{
        Type = 0,
    };

    public slots:
    void Message(MirrorSystemCommands value);

    signals:
    void TemperatureIDUpdated(QString id);
    void sendDebugMessage(LIBS::messageType mType, QString msg);

private:
    TrinamicController* trinamicDriver;
    bool isEnabled;
};



#endif // MODULERANGEFINDER_H
