#include "moduletemperaturesensor.h"

ModuleTemperatureSensor::ModuleTemperatureSensor(TrinamicController *tmcmController, unsigned char address) : TMCMGPIO(address, tmcmController)
{
    trinamicDriver = tmcmController;
    isEnabled = false;
}

ModuleTemperatureSensor::~ModuleTemperatureSensor(){};

void ModuleTemperatureSensor::init(){
    if(!trinamicDriver){
        emit sendDebugMessage(LIBS::Error,QString("Trinamic driver unavailable."));
        return;
    }
    isEnabled = true;
}

QString ModuleTemperatureSensor::TemperatureID(int temperatureID)   //teplomer typ
{
    int ret=-1;
    QString temperatureVal;

    emit sendDebugMessage(LIBS::Debug,QString("Reading values sd."));
    if(!isEnabled)
        return temperatureVal;

    if((ret=trinamicDriver->SendCommand(CommandTemperature,GetSampleHolderID,0,temperatureID))==TMCMGPIO::STAT_OK){
    long long returnVal = trinamicDriver->ReturnValue(0);
    temperatureVal = temperatureVal.number(returnVal/100);
    emit TemperatureIDUpdated(temperatureVal);

    }
    else{
        if(temperatureID == 0)
        {
            emit sendDebugMessage(LIBS::Error,QString("Temperature system: Temperature value %1. temperature ID %2.").arg(temperatureVal).arg(temperatureID));
        }
        if(temperatureID == 1)
        {
            emit sendDebugMessage(LIBS::Error,QString("Temperature system: Temperature value %1. temperature ID %2.").arg(temperatureVal).arg(temperatureID));
        }
        if(temperatureID == 2)
        {
            emit sendDebugMessage(LIBS::Error,QString("Temperature system: Temperature value %1. temperature ID %2.").arg(temperatureVal).arg(temperatureID));
        }
    emit sendDebugMessage(LIBS::Error,QString("Temperature  system: Temperature sensor returned error %1 %2 %3.").arg(ret).arg(trinamicDriver->ReturnValue(0)).arg(trinamicDriver->ReturnBank(0)));
    }

    return temperatureVal;
}

void ModuleTemperatureSensor::MirrorPosition(MirrorPositionValue value)
{
    int ret=-1;
    //(value >= 0 && value <= 2)
    emit sendDebugMessage(LIBS::Error,QString("System returned error, data hasn't been sent"));
    static int valueInt = value;
    if((ret=trinamicDriver->SendCommand(CommandMirror,MirrorPositionType,0,valueInt))==TMCMGPIO::STAT_OK){
        if(value == MirrorPositionValue::Left)
        {
            emit sendDebugMessage(LIBS::Info,QString("Moves left"));
        }
        if(value == MirrorPositionValue::Center)
        {
            emit sendDebugMessage(LIBS::Info,QString("Moves center"));
        }
        if(value == MirrorPositionValue::Right)
        {
            emit sendDebugMessage(LIBS::Info,QString("Moves right"));
        }
    }
    else {
        emit sendDebugMessage(LIBS::Error,QString("System returned error, data hasn't been sent"));
    }
}


