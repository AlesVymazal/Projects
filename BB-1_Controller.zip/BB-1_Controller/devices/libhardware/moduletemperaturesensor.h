#ifndef MODULETEMPERATURESENSOR_H
#define MODULETEMPERATURESENSOR_H

#include <QObject>
#include "../stage/hw_trinamic.h"
#include "LIBS.h"


class ModuleTemperatureSensor: public TMCMGPIO{

    Q_OBJECT
public:
    explicit ModuleTemperatureSensor(TrinamicController *tmcmController, unsigned char address);
    ~ModuleTemperatureSensor();
    void init();

    enum TemperatureSystemCommands{
        CommandMirror = 14,
        CommandTemperature = 15,
    };

    enum TemperatureSystemCommandType{
        GetSampleHolderID = 0,
        WriteSampleHolderMem = 1,
        ReadSampleHolderMem = 2,
        MirrorPositionType = 3,
    };

    enum MotorType{
        Motor = 2,
    };

    enum MirrorPositionValue{
        Left = 0,
        Center = 1,
        Right = 2,
    };


signals:
    void TemperatureIDUpdated(QString id);
    void sendDebugMessage(LIBS::messageType mType, QString msg);

public slots:
    QString TemperatureID(int temperatureID);
    void MirrorPosition(MirrorPositionValue value);

private:
    TrinamicController* trinamicDriver;
    bool isEnabled;
};

#endif // MODULETEMPERATURESENSOR_H




