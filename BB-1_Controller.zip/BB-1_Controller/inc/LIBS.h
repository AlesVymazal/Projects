#ifndef LIBS_H
#define LIBS_H

namespace LIBS{
enum messageType{
        FatalError,
        Error,
        Warning,
        Debug,
        Info
    };
}

#endif // LIBS_H
