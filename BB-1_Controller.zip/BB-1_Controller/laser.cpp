#include "laser.h"
#include "ui_laser.h"
#include <QDebug>
#include <iostream>
#include <thread>
#include <QThread>

Laser::Laser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Laser)
{
    ui->setupUi(this);

    std::thread packetDecoderThread([=](){laserController.thread1Process();});
    packetDecoderThread.detach();
    std::thread packetParserThread([=](){laserController.thread2Process();});
    packetParserThread.detach();

    ui->portsComboBox->installEventFilter(this);

    qRegisterMetaType<LaserCommandDecoder::newInformation>();
    QObject::connect(this, SIGNAL(newInformation(LaserCommandDecoder::newInformation)), this, SLOT(setNewInformation(LaserCommandDecoder::newInformation)), Qt::ConnectionType::QueuedConnection);
    laserController.setNewInformationCallback([=](LaserCommandDecoder::newInformation information)
    {
        emit newInformation(information);
    });

    timerPoll.setInterval(1000);
    timerInitialise.setInterval(1000);
    timerStart.setInterval(1000);
    timerConnection.setInterval(5000);

    QObject::connect(&timerPoll, SIGNAL(timeout()), this, SLOT(timerPollTick()));
    QObject::connect(&timerInitialise, SIGNAL(timeout()), this, SLOT(timerInitialiseTick()));
    QObject::connect(&timerStart, SIGNAL(timeout()), this, SLOT(timerStartTick()));
    QObject::connect(&timerConnection, &QTimer::timeout, this, &Laser::handleTimeout);

    QObject::connect(&serialPort, &QSerialPort::readyRead, this, &Laser::handleReadyRead);
    QObject::connect(&serialPort, SIGNAL(errorOccurred(QSerialPort::SerialPortError)), this, SLOT(handleError(QSerialPort::SerialPortError)));

    resetStatuses();
    fillPortsComboBox();

    attenuator1FullScale = 115000;
    attenuator2FullScale = 115000;

    setUiEnabled(connected);
}

Laser::~Laser()
{
    delete ui;
}

void Laser::connectPort()
{
    serialPort.setPortName(ui->portsComboBox->currentText());
    if (!serialPort.open(QIODevice::ReadWrite))
    {
        return;
    }

    qInfo() << "LaserController Connected...";
    connected = true;
    ui->connectDisconnectButton->setText("Disconnect");

    laserController.reset();

    timerConnection.start();
    timerInitialise.start();

    setUiEnabled(connected);
}

void Laser::disconnectPort()
{
    if (connected)
    {
        qInfo() << "Disconnecting";
        timerConnection.stop();
        timerPoll.stop();
        timerInitialise.stop();
        timerStart.stop();
        if (serialPort.isOpen())
        {
            serialPort.close();
        }
        resetStatuses();
        connected = false;
        ui->connectDisconnectButton->setText("Connect");
        ui->startStopButton->setText("START");

        setUiEnabled(connected);
    }
}

void Laser::timerPollTick()
{
    timerPoll.stop();

    qInfo() << "LaserController polling PING";
    sendPacket(LaserCommand::ping());
    sendPacket(LaserCommand::requestFunctionStatus());

    if (connected)
    {
        timerPoll.start();
    }
}

void Laser::timerInitialiseTick()
{
    timerInitialise.stop();

    qInfo() << "LaserController initialising...";
    sendPacket(LaserCommand::independentTriggerMode());
//    sendPacket(LaserCommandNew::linkedTriggerMode());
    sendPacket(LaserCommand::requestSystemData());
    sendPacket(LaserCommand::requestAttenuatorValue(1));
    sendPacket(LaserCommand::requestAttenuatorValue(2));
    sendPacket(LaserCommand::requestAttenuatorFullScale());
    sendPacket(LaserCommand::requestTimingLimit(LaserCommand::TimingLimit::QSwitchDelayLow));
    sendPacket(LaserCommand::requestTimingLimit(LaserCommand::TimingLimit::QSwitchDelayHigh));
    sendPacket(LaserCommand::lampDriveVoltage(1, 4095));
    sendPacket(LaserCommand::lampDriveVoltage(2, 4095));
    sendPacket(LaserCommand::setRepRate(flashLampDelay));
    qInfo() << "LaserController initialised...";

    timerPoll.start();
}

void Laser::timerStartTick()
{
    timerStart.stop();

    if (!systemStatus.systemState)
    {
        qInfo() << "LaserController Turning on System...";
        sendPacket(LaserCommand::systemOn());
        timerStart.start();
        return;
    }

    if (!systemStatus.pumpState)
    {
        qInfo() << "LaserController Turning on Pump...";
        sendPacket(LaserCommand::pumpOn());
        timerStart.start();
        return;
    }

    if (!systemStatus.laserState)
    {
        qInfo() << "LaserController Turning on Laser...";
        sendPacket(LaserCommand::laserOn());
        timerStart.start();
        return;
    }

    if (ui->autoShutterCheckBox->isChecked() && !systemStatus.shutterState)
    {
        qInfo() << "Opening shutter...";
        sendPacket(LaserCommand::openShutter());
        timerStart.start();
        return;
    }
}

void Laser::handleReadyRead()
{
    QByteArray bArray = serialPort.readAll();
    laserController.newData(std::vector<std::uint8_t>(bArray.begin(), bArray.end()));
    timerConnection.start();
}

void Laser::handleError(QSerialPort::SerialPortError error)
{
    if (error != QSerialPort::SerialPortError::NoError)
    {
        qInfo() << error << serialPort.errorString(); // TODO WINDOW
        serialPort.clearError();
        disconnect();
    }
}

void Laser::handleTimeout()
{
    qInfo() << "Connection timed out"; // TODO WINDOW
    disconnect();
}

void Laser::fillPortsComboBox()
{
    ui->portsComboBox->clear();
    for (QSerialPortInfo type : QSerialPortInfo::availablePorts())
    {
        ui->portsComboBox->addItem(type.portName());
    }
}

bool Laser::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == ui->portsComboBox && event->type() == QEvent::MouseButtonPress)
    {
        fillPortsComboBox();
    }

    return false;
}

void Laser::sendPacket(packet data)
{
    if (serialPort.isOpen())
    {
        const qint64 bytesWritten = serialPort.write(reinterpret_cast<const char*>(data.data()), static_cast<qint64>(data.size()));

        if (bytesWritten == -1 || bytesWritten != static_cast<qint64>(data.size()))
        {
            disconnect();
        }

        timerConnection.start();
        return;
    }
}

void Laser::resetStatuses()
{
    systemStatus.setFromValue(0xDFF0);
    updateSystemStatus();
    functionStatus.setFromValue(0x00);
    updateFunctionStatus();
}

void Laser::setNewInformation(LaserCommandDecoder::newInformation information)
{
    if (!connected)
        return;

    switch (information.type)
    {
        case LaserCommandDecoder::InformationType::None:
            break;
        case LaserCommandDecoder::InformationType::FunctionStatus:
        std::cout << "New function status" << std::endl;
            functionStatus.setFromValue(information.data.funcStatus);
            updateFunctionStatus();
            break;
        case LaserCommandDecoder::InformationType::SystemStatus:
        std::cout << "New System status" << std::endl;
            systemStatus.setFromValue(information.data.sysStatus);
            updateSystemStatus();
            break;
        case LaserCommandDecoder::InformationType::Lamp1Voltage:
            std::cout << "Lamp 1 value: " << information.data.lampVoltage << std::endl;
            break;
        case LaserCommandDecoder::InformationType::Lamp2Voltage:
            std::cout << "Lamp 2 value: " << information.data.lampVoltage << std::endl;
            break;
        case LaserCommandDecoder::InformationType::Attenuator1Value:

            std::cout << "Attenuator 1 value: " << information.data.attenuatorValue << std::endl;
            if (attenuator1FullScale != 0)
            {
                int value = static_cast<int>(static_cast<double>(information.data.attenuatorValue) / static_cast<double>(attenuator1FullScale) * 100.0);
                ui->attenuator1Slider->setValue(value);
                ui->attenuator1ValueSpinBox->setValue(value);
            }
            break;
        case LaserCommandDecoder::InformationType::Attenuator2Value:

            std::cout << "Attenuator 2 value: " << information.data.attenuatorValue << std::endl;
            if (attenuator2FullScale != 0)
            {
                int value = static_cast<int>(static_cast<double>(information.data.attenuatorValue) / static_cast<double>(attenuator2FullScale) * 100.0);
                ui->attenuator2Slider->setValue(value);
                ui->attenuator2ValueSpinBox->setValue(value);
            }
            break;
        case LaserCommandDecoder::InformationType::Attenuator1FullScale:
            attenuator1FullScale = information.data.attenuatorFullScale;
            setAttenuator1Position();
            std::cout << "Attenuator 1 fullscale: " << attenuator1FullScale << std::endl;
            break;
        case LaserCommandDecoder::InformationType::Attenuator2FullScale:
            attenuator2FullScale = information.data.attenuatorFullScale;
            setAttenuator2Position();
            std::cout << "Attenuator 2 fullscale: " << attenuator1FullScale << std::endl;
            break;
        case LaserCommandDecoder::InformationType::QSwitch1Delay:
            ui->qSwitch1DelaySpinBox->setValue(static_cast<int>(information.data.qSwitchDelay));
            std::cout << "QSwitch 1 delay: " << static_cast<int>(information.data.qSwitchDelay) << std::endl;
            break;
        case LaserCommandDecoder::InformationType::QSwitch2Delay:
            ui->qSwitch2DelaySpinBox->setValue(static_cast<int>(information.data.qSwitchDelay));
            std::cout << "QSwitch 1 delay: " << static_cast<int>(information.data.qSwitchDelay) << std::endl;
            break;
        case LaserCommandDecoder::InformationType::QSwitchDelayLow:
            ui->qSwitch1DelaySpinBox->setMinimum(static_cast<int>(information.data.qSwitchDelayLimit));
            ui->qSwitch2DelaySpinBox->setMinimum(static_cast<int>(information.data.qSwitchDelayLimit));
            std::cout << "QSwitch Delay Low Limit: " << static_cast<int>(information.data.qSwitchDelayLimit) << std::endl;
            break;
        case LaserCommandDecoder::InformationType::QSwitchDelayHigh:
            ui->qSwitch1DelaySpinBox->setMaximum(static_cast<int>(information.data.qSwitchDelayLimit));
            ui->qSwitch2DelaySpinBox->setMaximum(static_cast<int>(information.data.qSwitchDelayLimit));
            std::cout << "QSwitch Delay High Limit: " << static_cast<int>(information.data.qSwitchDelayLimit) << std::endl;
            break;
        case LaserCommandDecoder::InformationType::PulsePeriod:
            std::cout << "Pulse Period:: " << information.data.pulseFrequency << std::endl;
            break;
    }
}

void Laser::updateSystemStatus()
{
    ui->systemButton->setText(systemStatus.systemState ? "System ON" : "System OFF");
    ui->pumpCheckBox->setChecked(systemStatus.pumpState ? true : false);
    ui->laserCheckBox->setChecked(systemStatus.laserState ? true : false);
    ui->shutterButton->setText(determineShutterText());

    ui->waterFlowCheckBox->setChecked(!systemStatus.interlockWaterFlow);
    ui->waterLevelCheckBox->setChecked(!systemStatus.interlockWaterLevel);
    ui->waterTempCheckBox->setChecked(!systemStatus.interlockWaterTemp);
    ui->charger2CheckBox->setChecked(!systemStatus.interlockCharger2);
    ui->psuTempCheckBox->setChecked(!systemStatus.interlockPsuTemp);
    ui->charger1CheckBox->setChecked(!systemStatus.interlockCharger1);
    ui->externalCheckBox->setChecked(!systemStatus.interlockExternal);
    ui->psuCoverCheckBox->setChecked(!systemStatus.interlockPsuCover);
    ui->laserHeadCheckBox->setChecked(!systemStatus.interlockLaserHead);
    ui->shutterCheckBox->setChecked(systemStatus.interlockShutter);
    ui->simmer1CheckBox->setChecked(!systemStatus.interlockSimmer1);
    ui->simmer2CheckBox->setChecked(!systemStatus.interlockSimmer2);

    ui->flowCheckBox->setChecked(systemStatus.waterFlow);
    ui->keyCheckBox->setChecked(systemStatus.keyState);

    ui->flashLamp1TriggerSourceComboBox->setCurrentText(determineTriggerSource(systemStatus.lamp1TrigSource));
    ui->flashLamp2TriggerSourceComboBox->setCurrentText(determineTriggerSource(systemStatus.lamp2TrigSource));
    ui->qSwitch1TriggerSourceComboBox->setCurrentText(determineTriggerSource(systemStatus.QS1TriggerSource));
    ui->qSwitch2TriggerSourceComboBox->setCurrentText(determineTriggerSource(systemStatus.QS2TriggerSource));
}

void Laser::updateFunctionStatus()
{
    ui->shutterButton->setText(determineShutterText());

    ui->extFrq1CheckBox->setChecked(!functionStatus.lowFrequency1);
    ui->extFrq2CheckBox->setChecked(!functionStatus.lowFrequency2);

    ui->qSwitch1TriggerEnabled->setChecked(functionStatus.QS1TrigEn);
    ui->qSwitch2TriggerEnabled->setChecked(functionStatus.QS2TrigEn);
    ui->flashLamp1TriggerEnabledCheckBox->setChecked(functionStatus.lamp1TrigEn);
    ui->flashLamp2TriggerEnabledCheckBox->setChecked(functionStatus.lamp2TrigEn);
}

void Laser::sendTimingsAndTriggerStates()
{
    LaserCommand::TriggerConfig config;
    config.lamp1IntTrigEnable = ui->flashLamp1TriggerEnabledCheckBox->isChecked();
    config.lamp2IntTrigEnable = ui->flashLamp2TriggerEnabledCheckBox->isChecked();
    config.qSwitch1IntTrigEnable = ui->qSwitch1TriggerEnabled->isChecked();
    config.qSwitch2IntTrigEnable = ui->qSwitch2TriggerEnabled->isChecked();
    sendPacket(LaserCommand::setTimingsAndTriggers(config, flashLampDelay, 0,
                                                      static_cast<std::uint32_t>(ui->qSwitch1DelaySpinBox->value()),
                                                      static_cast<std::uint32_t>(ui->qSwitch2DelaySpinBox->value())));
}

QString Laser::determineShutterText()
{
    if (functionStatus.shutterInhibited)
    {
        ui->shutterButton->setEnabled(false);
        return "Shutter inhibited";
    }
    else
    {
        ui->shutterButton->setEnabled(true);
        if (systemStatus.shutterState)
        {
            ui->indicator->setIsOn(true);
            return "Shutter open";
        }
        else
        {
            ui->indicator->setIsOn(false);
            return "Shutter closed";
        }
    }
}

QString Laser::determineTriggerSource(bool value)
{
    return value ? "External trigger" : "Internal trigger";
}

void Laser::on_startStopButton_clicked()
{
    if (!systemStatus.laserState)
    {
        timerStart.start();
        ui->startStopButton->setText("STOP");
    }
    else
    {
        timerStart.stop();
        sendPacket(LaserCommand::laserOff());
        ui->startStopButton->setText("START");
    }
}

void Laser::setUiEnabled(bool state)
{
    determineShutterButtonEnabled();
    ui->mainControlGroupBox->setEnabled(state);
    ui->channel1GroupBox->setEnabled(state);
    ui->channel2GroupBox->setEnabled(state);
}

void Laser::on_connectDisconnectButton_clicked()
{
    if (connected)
        disconnectPort();
    else
        connectPort();
}

void Laser::on_systemButton_clicked()
{
    timerStart.start();
}

void Laser::on_shutterButton_clicked()
{
    if (systemStatus.shutterState)
        sendPacket(LaserCommand::closeShutter());
    else
        sendPacket(LaserCommand::openShutter());
}

void Laser::determineShutterButtonEnabled()
{
    if (ui->autoShutterCheckBox->isChecked() || !connected)
        ui->shutterButton->setEnabled(false);
    else
        ui->shutterButton->setEnabled(true);
}

void Laser::on_autoShutterCheckBox_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    determineShutterButtonEnabled();
}

void Laser::on_flashLamp1TriggerEnabledCheckBox_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    sendTimingsAndTriggerStates();
}

void Laser::on_flashLamp1TriggerSourceComboBox_currentTextChanged(const QString &arg1)
{
    if (arg1 == "External trigger")
        sendPacket(LaserCommand::lamp1ExternalTrigger());
    else
        sendPacket(LaserCommand::lamp1InternalTrigger());
}

void Laser::on_qSwitch1TriggerEnabled_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    sendTimingsAndTriggerStates();
}

void Laser::on_qSwitch1TriggerSourceComboBox_currentTextChanged(const QString &arg1)
{
    if (arg1 == "External trigger")
        sendPacket(LaserCommand::QSwitch1ExternalTrigger());
    else
        sendPacket(LaserCommand::QSwitch1InternalTrigger());
}

void Laser::on_qSwitch1DelaySpinBox_editingFinished()
{
    sendTimingsAndTriggerStates();
}

void Laser::setAttenuator1Position()
{
    std::uint32_t value = static_cast<std::uint32_t>(ui->attenuator1Slider->value() / 100.0 * attenuator1FullScale);
    sendPacket(LaserCommand::setAttenuatorPosition(1, value));
}

void Laser::on_attenuator1Slider_sliderReleased()
{
    setAttenuator1Position();
}

void Laser::on_attenuator1Slider_valueChanged(int value)
{
    ui->attenuator1ValueSpinBox->setValue(value);
}

void Laser::on_attenuator1ValueSpinBox_editingFinished()
{
    ui->attenuator1Slider->setValue(ui->attenuator1ValueSpinBox->value());
    setAttenuator1Position();
}

void Laser::on_flashLamp2TriggerEnabledCheckBox_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    sendTimingsAndTriggerStates();
}

void Laser::on_flashLamp2TriggerSourceComboBox_currentTextChanged(const QString &arg1)
{
    if (arg1 == "External trigger")
        sendPacket(LaserCommand::lamp2ExternalTrigger());
    else
        sendPacket(LaserCommand::lamp2InternalTrigger());
}

void Laser::on_qSwitch2TriggerEnabled_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    sendTimingsAndTriggerStates();
}

void Laser::on_qSwitch2TriggerSourceComboBox_currentTextChanged(const QString &arg1)
{
    if (arg1 == "External trigger")
        sendPacket(LaserCommand::QSwitch2ExternalTrigger());
    else
        sendPacket(LaserCommand::QSwitch2InternalTrigger());
}

void Laser::on_qSwitch2DelaySpinBox_editingFinished()
{
    sendTimingsAndTriggerStates();
}

void Laser::setAttenuator2Position()
{
    std::uint32_t value = static_cast<std::uint32_t>((ui->attenuator2Slider->value() / 100.0) * attenuator2FullScale);
    sendPacket(LaserCommand::setAttenuatorPosition(2, value));
}

void Laser::on_attenuator2Slider_sliderReleased()
{
    setAttenuator2Position();
}

void Laser::on_attenuator2Slider_valueChanged(int value)
{
    ui->attenuator2ValueSpinBox->setValue(value);
}

void Laser::on_attenuator2ValueSpinBox_editingFinished()
{
    ui->attenuator2Slider->setValue(ui->attenuator2ValueSpinBox->value());
    setAttenuator2Position();
}
