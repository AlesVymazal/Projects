#pragma once

#include <QWidget>
#include <QStringListModel>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>
#include "laser/lasercontroller.h"

namespace Ui {
class Laser;
}

class Laser : public QWidget
{
    Q_OBJECT

signals:
    void portsChanged();
    void newInformation(LaserCommandDecoder::newInformation information);

private slots:
    void connectPort();
    void disconnectPort();

    void timerPollTick();
    void timerInitialiseTick();
    void timerStartTick();
    void handleReadyRead();
    void handleError(QSerialPort::SerialPortError error);
    void handleTimeout();

    void setNewInformation(LaserCommandDecoder::newInformation information);

    void on_systemButton_clicked();

    void on_connectDisconnectButton_clicked();

    void on_startStopButton_clicked();

    void on_shutterButton_clicked();

    void on_autoShutterCheckBox_stateChanged(int arg1);

    void on_flashLamp1TriggerEnabledCheckBox_stateChanged(int arg1);

    void on_flashLamp1TriggerSourceComboBox_currentTextChanged(const QString &arg1);

    void on_qSwitch1TriggerEnabled_stateChanged(int arg1);

    void on_qSwitch1TriggerSourceComboBox_currentTextChanged(const QString &arg1);

    void on_qSwitch1DelaySpinBox_editingFinished();

    void on_attenuator1Slider_sliderReleased();

    void on_attenuator1Slider_valueChanged(int value);

    void on_attenuator1ValueSpinBox_editingFinished();

    void on_flashLamp2TriggerEnabledCheckBox_stateChanged(int arg1);

    void on_flashLamp2TriggerSourceComboBox_currentTextChanged(const QString &arg1);

    void on_qSwitch2TriggerEnabled_stateChanged(int arg1);

    void on_qSwitch2TriggerSourceComboBox_currentTextChanged(const QString &arg1);

    void on_qSwitch2DelaySpinBox_editingFinished();

    void on_attenuator2Slider_sliderReleased();

    void on_attenuator2Slider_valueChanged(int value);

    void on_attenuator2ValueSpinBox_editingFinished();

public:
    explicit Laser(QWidget *parent = nullptr);
    ~Laser() override;

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private:
    Ui::Laser *ui;

    QSerialPort serialPort;

    std::uint32_t attenuator1FullScale = 0;
    std::uint32_t attenuator2FullScale = 0;

    QTimer timerPoll;
    QTimer timerInitialise;
    QTimer timerStart;
    QTimer timerConnection;

    LaserController laserController;
    LaserCommandDecoder::systemStatus systemStatus;
    LaserCommandDecoder::functionStatus functionStatus;

    bool connected = false;

    QString determineShutterText();
    QString determineTriggerSource(bool value);

    std::uint32_t flashLampDelay = 20000;

    void sendPacket(packet data);
    void resetStatuses();
    void updateSystemStatus();
    void updateFunctionStatus();
    void sendTimingsAndTriggerStates();

    void fillPortsComboBox();
    void setAttenuator1Position();
    void setAttenuator2Position();

    void setUiEnabled(bool state);

    void determineShutterButtonEnabled();
};

Q_DECLARE_METATYPE(LaserCommandDecoder::newInformation)
