#include "lasercommand.h"

packet LaserCommand::systemOn()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x2D, 0x37, 0x1D, 0xAA, 0xAA,
        0x01, 0x00, 0x00, 0x0E, 0x00, 0x0C, 0x10, 0x00,
        0x00, 0x01, 0x76, 0x13
    };
    return data;
}

packet LaserCommand::systemOff()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x2D, 0x6E, 0x4D, 0xAA, 0xAA,
        0x01, 0x00, 0x00, 0x0E, 0x00, 0x0C, 0x00, 0x00,
        0x00, 0x01, 0x75, 0x60
    };
    return data;
}

packet LaserCommand::pumpOn()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x21, 0x37, 0x11, 0xAA, 0xAA,
        0x01, 0x00, 0x00, 0x0E, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x20, 0x37, 0x10
    };
    return data;
}

packet LaserCommand::pumpOff()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x21, 0x6E, 0x41
    };
    return data;
}

packet LaserCommand::laserOn()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x23, 0x6E, 0x43, 0xAA, 0xAA,
        0x01, 0x00, 0x00, 0x0E, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x22, 0x37, 0x12
    };
    return data;
}

packet LaserCommand::laserOff()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x23, 0x37, 0x13
    };
    return data;
}

packet LaserCommand::openShutter()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12, 0x00, 0x0D,
        0x00, 0x00, 0x00, 0x69, 0x00, 0x00, 0x00, 0x24,
        0xEF, 0xD4
    };
    return data;
}

packet LaserCommand::closeShutter()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12, 0x00, 0x0D,
        0x00, 0x00, 0x00, 0x69, 0x00, 0x00, 0x00, 0x25,
        0xEF, 0xD5
    };
    return data;
}

packet LaserCommand::lamp1ExternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x32, 0x37, 0x02
    };
    return data;
}

packet LaserCommand::lamp2ExternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x33, 0x37, 0x03
    };
    return data;
}

packet LaserCommand::lamp1InternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x32, 0x6E, 0x52
    };
    return data;
}

packet LaserCommand::lamp2InternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x33, 0x6E, 0x53
    };
    return data;
}

packet LaserCommand::linkedTriggerMode()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12, 0x00, 0x11,
        0x00, 0x11, 0x00, 0x09, 0x00, 0x00, 0x00, 0x01,
        0xBF, 0x81
    };
    return data;
}

packet LaserCommand::independentTriggerMode()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12, 0x00, 0x11,
        0x00, 0x11, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00,
        0xBF, 0x80
    };
    return data;
}

packet LaserCommand::QSwitch1ExternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x34, 0x37, 0x04
    };
    return data;
}

packet LaserCommand::QSwitch2ExternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x35, 0x37, 0x05
    };
    return data;
}

packet LaserCommand::QSwitch1InternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x34, 0x6E, 0x54
    };
    return data;
}

packet LaserCommand::QSwitch2InternalTrigger()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E, 0x00, 0x02,
        0x00, 0x00, 0x00, 0x35, 0x6E, 0x55
    };
    return data;
}

packet LaserCommand::ping()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E,
        0x00, 0x0B, 0x00, 0x00, 0x00, 0x01,
        0xF0, 0xF0
    };
    return data;
}

packet LaserCommand::requestSystemData()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E,
        0x00, 0x1B, 0x00, 0x00, 0x00, 0x01,
        0xB3, 0x93
    };
    return data;
}

packet LaserCommand::requestTimingLimit(LaserCommand::TimingLimit limit)
{
    std::uint8_t index = limit;
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0D,
        0x00, 0x1A, 0x00, index, 0x04
    };

    addCRC(data);

    return data;
}

packet LaserCommand::requestFunctionStatus()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E,
        0x00, 0x1C, 0x00, 0x00, 0x00, 0x01,
        0x36, 0x03
    };
    return data;
}

packet LaserCommand::requestFunctionData(FunctionData functionData)
{
    std::uint8_t data0 = functionData;
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0D,
        0x00, 0x1C, 0x00, data0, 0x04
    };

    addCRC(data);

    return data;
}

packet LaserCommand::requestAttenuatorValue(std::uint8_t index)
{
    std::uint8_t data0 = index == 1 ? 0x02 : 0x03;
    std::uint8_t data1 = index == 1 ? 0xAC : 0x88;
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0D,
        0x00, 0x1A, data0, data1, 0x04
    };

    addCRC(data);

    return data;
}

packet LaserCommand::requestAttenuatorFullScale()
{
    static packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0D,
        0x00, 0x1A, 0x03, 0xB4, 0x04,
        0x68, 0xDF
    };
    return data;
}

packet LaserCommand::setTimingsAndTriggers(TriggerConfig triggerConfig, uint32_t pulsePeriod, uint32_t flashlampDelay, uint32_t qSwitch1Delay, uint32_t qSwitch2Delay)
{
    std::uint8_t config = triggerConfig.lamp1IntTrigEnable ? 0x01 : 0x00;
    config |= triggerConfig.lamp2IntTrigEnable ? 0x02 : 0x00;
    config |= triggerConfig.qSwitch1IntTrigEnable ? 0x04 : 0x00;
    config |= triggerConfig.qSwitch2IntTrigEnable ? 0x08 : 0x00;
    config |= triggerConfig.flashlampDelaySign ? 0x010 : 0x00;



    std::uint8_t pp0 = static_cast<std::uint8_t>((pulsePeriod >> 24) & 0xFF);
    std::uint8_t pp1 = static_cast<std::uint8_t>((pulsePeriod >> 16) & 0xFF);
    std::uint8_t pp2 = static_cast<std::uint8_t>((pulsePeriod >> 8) & 0xFF);
    std::uint8_t pp3 = static_cast<std::uint8_t>(pulsePeriod & 0xFF);

    std::uint8_t pd0 = static_cast<std::uint8_t>((flashlampDelay >> 24) & 0xFF);
    std::uint8_t pd1 = static_cast<std::uint8_t>((flashlampDelay >> 16) & 0xFF);
    std::uint8_t pd2 = static_cast<std::uint8_t>((flashlampDelay >> 8) & 0xFF);
    std::uint8_t pd3 = static_cast<std::uint8_t>(flashlampDelay & 0xFF);

    std::uint8_t q10 = static_cast<std::uint8_t>((qSwitch1Delay >> 24) & 0xFF);
    std::uint8_t q11 = static_cast<std::uint8_t>((qSwitch1Delay >> 16) & 0xFF);
    std::uint8_t q12 = static_cast<std::uint8_t>((qSwitch1Delay >> 8) & 0xFF);
    std::uint8_t q13 = static_cast<std::uint8_t>(qSwitch1Delay & 0xFF);

    std::uint8_t q20 = static_cast<std::uint8_t>((qSwitch2Delay >> 24) & 0xFF);
    std::uint8_t q21 = static_cast<std::uint8_t>((qSwitch2Delay >> 16) & 0xFF);
    std::uint8_t q22 = static_cast<std::uint8_t>((qSwitch2Delay >> 8) & 0xFF);
    std::uint8_t q23 = static_cast<std::uint8_t>(qSwitch2Delay & 0xFF);

    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x1F,
        0x00, 0x11, 0x00, 0x11, 0x00, 0x01,
        config,
        pp0, pp1, pp2, pp3,
        pd0, pd1, pd2, pd3,
        q10, q11, q12, q13,
        q20, q21, q22, q23
    };

    addCRC(data);

    return data;
}

packet LaserCommand::setRepRate(uint32_t value)
{
    std::uint8_t data0 = static_cast<std::uint8_t>((value >> 24) & 0xFF);
    std::uint8_t data1 = static_cast<std::uint8_t>((value >> 16) & 0xFF);
    std::uint8_t data2 = static_cast<std::uint8_t>((value >> 8) & 0xFF);
    std::uint8_t data3 = static_cast<std::uint8_t>(value & 0xFF);

    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12,
        0x00, 0x11, 0x00, 0x11, 0x00, 0x03,
        data0, data1, data2, data3
    };

    addCRC(data);

    return data;
}

packet LaserCommand::setRepRateDiv(std::uint8_t QSindex, bool enable, uint32_t value)
{
    std::uint8_t data0 = static_cast<std::uint8_t>((value >> 24) & 0xFF);
    std::uint8_t data1 = static_cast<std::uint8_t>((value >> 16) & 0xFF);
    std::uint8_t data2 = static_cast<std::uint8_t>((value >> 8) & 0xFF);
    std::uint8_t data3 = static_cast<std::uint8_t>(value & 0xFF);

    std::uint8_t index = QSindex == 1 ? 0x06 : 0x08;

    if (enable)
        data0 |= 0x80;

    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12,
        0x00, 0x11, 0x00, 0x11, 0x00, index,
        data0, data1, data2, data3
    };

    addCRC(data);

    return data;
}

packet LaserCommand::strikeEnable(bool lamp1, bool lamp2)
{
    std::uint8_t config = (lamp1 ? 0x01 : 0x00) | (lamp2 ? 0x02 : 0x00);
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0F,
        0x00, 0x11, 0x00, 0x11, 0x00, 0x0A,
        config
    };

    addCRC(data);

    return data;
}

packet LaserCommand::lampDriveVoltage(std::uint8_t lampIndex, uint16_t value)
{
    std::uint8_t data0 = static_cast<std::uint8_t>((value >> 8) & 0xFF);
    std::uint8_t data1 = static_cast<std::uint8_t>(value & 0xFF);
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x0E,
        0x00, 0x12, 0x00, lampIndex,
        data0, data1
    };

    addCRC(data);

    return data;
}

packet LaserCommand::setAttenuatorPosition(std::uint8_t attenuatorIndex, uint32_t value)
{
    std::uint8_t data0 = static_cast<std::uint8_t>((value >> 24) & 0xFF);
    std::uint8_t data1 = static_cast<std::uint8_t>((value >> 16) & 0xFF);
    std::uint8_t data2 = static_cast<std::uint8_t>((value >> 8) & 0xFF);
    std::uint8_t data3 = static_cast<std::uint8_t>(value & 0xFF);
    std::uint8_t index = attenuatorIndex - 1;
    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x10,
        0x00, 0x3E, index, 0,
        data0, data1, data2, data3
    };

    addCRC(data);

    return data;
}

packet LaserCommand::setBurst(std::uint8_t lampIndex, bool enable, uint32_t value)
{
    std::uint8_t data0 = static_cast<std::uint8_t>((value >> 24) & 0xFF);
    std::uint8_t data1 = static_cast<std::uint8_t>((value >> 16) & 0xFF);
    std::uint8_t data2 = static_cast<std::uint8_t>((value >> 8) & 0xFF);
    std::uint8_t data3 = static_cast<std::uint8_t>(value & 0xFF);

    if (enable)
        data0 |= 0x80;

    std::uint8_t index = lampIndex == 1 ? 0x05 : 0x07;

    packet data =
    {
        0xAA, 0xAA, 0x01, 0x00, 0x00, 0x12,
        0x00, 0x11, 0x00, 0x11, 0x00, index,
        data0, data1, data2, data3,
    };

    addCRC(data);

    return data;
}



void LaserCommand::addCRC(packet &data)
{
    std::uint32_t top17Bits;
    std::uint32_t kX;
    std::uint32_t crcFlag;
    std::uint32_t leadingBit;
    std::uint32_t mask;
    std::uint32_t nextByte;
    std::uint32_t nextBit;
    std::size_t byteNumber;
    std::size_t topByteIndex;

    if (data.empty())
        return;

    topByteIndex = data.size() - 1;

    if (topByteIndex < 8)
    {
        /*not enough data so just return*/
        return;
    }

    /* load first 3 bytes into processing register */
    top17Bits = data[6];
    top17Bits = (top17Bits << 8) + data[7];
    top17Bits = (top17Bits << 8) + data[8];

    /* next byte to load */
    byteNumber = 9;

    /* lowest 7 bits */
    nextByte = (top17Bits & 0x7f);

    mask = 0x40;

    /* we have 24 bits loaded, so drop bottom 7 bits
     * to get to the 17 bits we need */

    top17Bits = (top17Bits >> 7);

    kX = 0x11021; /*69665*/


    while (true)
    {
        /*initialise flag*/
        crcFlag = 0;

        /* check whether leading bit is 0 or 1  */
        leadingBit = (top17Bits & 0x10000);
        if (leadingBit > 0)
        {
            top17Bits = (top17Bits ^ kX);
        }
        else
        {
            top17Bits = (top17Bits ^ 0x00);
        }

        /* do we need another message byte */
        if (mask == 0x80)
        {
            crcFlag = 0x01;
            if (byteNumber < (topByteIndex + 1))
            {
                if (crcFlag == 1)
                {
                    nextByte = data[byteNumber];
                    byteNumber++;
                }
            }
            else
            {
                data.push_back(static_cast<std::uint8_t>((top17Bits & 0xFF00) >> 8));
                data.push_back(static_cast<std::uint8_t>(top17Bits & 0xFF));
                return;
            }
        }

        nextBit = (nextByte & mask);
        if (mask > 1)
        {
            mask = (mask >> 1);
        }
        else
        {
            mask = 0x80;
        }

        top17Bits = (top17Bits << 1);

        if (nextBit >= 1)
        {
            top17Bits++;
        }
    }
}
