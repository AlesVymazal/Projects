#pragma once

#include <vector>
#include <cstdint>

typedef std::vector<std::uint8_t> packet;

class LaserCommand
{
public:
    enum FunctionData
    {
        RepRateDiv1 = 0x40,
        RepRateDiv2 = 0x44,
        Burst1 = 0x50,
        Burst2 = 0x54
    };

    enum TimingLimit
    {
        PulsePeriodLow = 0x10,
        PulsePeriodHigh = 0x14,
        QSwitchDelayLow = 0x18,
        QSwitchDelayHigh = 0x1C
    };


    struct TriggerConfig
    {
        bool lamp1IntTrigEnable = false;
        bool lamp2IntTrigEnable = false;
        bool qSwitch1IntTrigEnable = false;
        bool qSwitch2IntTrigEnable = false;
        bool flashlampDelaySign = false;
    };

    static packet systemOn();
    static packet systemOff();
    static packet pumpOn();
    static packet pumpOff();
    static packet laserOn();
    static packet laserOff();
    static packet openShutter();
    static packet closeShutter();
    static packet lamp1ExternalTrigger();
    static packet lamp2ExternalTrigger();
    static packet lamp1InternalTrigger();
    static packet lamp2InternalTrigger();
    static packet linkedTriggerMode();
    static packet independentTriggerMode();
    static packet QSwitch1ExternalTrigger();
    static packet QSwitch2ExternalTrigger();
    static packet QSwitch1InternalTrigger();
    static packet QSwitch2InternalTrigger();
    static packet ping();
    static packet requestSystemData();
    static packet requestTimingLimit(TimingLimit limit);
    static packet requestFunctionStatus();
    static packet requestFunctionData(FunctionData data);
    static packet requestAttenuatorValue(std::uint8_t index);
    static packet requestAttenuatorFullScale();

    static packet setTimingsAndTriggers(TriggerConfig triggerConfig, std::uint32_t pulsePeriod, std::uint32_t flashlampDelay, std::uint32_t qSwitch1Delay, std::uint32_t qSwitch2Delay);
    static packet setRepRate(std::uint32_t value);
    static packet setRepRateDiv(std::uint8_t QSindex, bool enable, std::uint32_t value);
    static packet strikeEnable(bool lamp1, bool lamp2);
    static packet lampDriveVoltage(std::uint8_t lampIndex, std::uint16_t value);
    static packet setAttenuatorPosition(std::uint8_t attenuatorIndex, std::uint32_t value);
    static packet setBurst(std::uint8_t lampIndex, bool enable, std::uint32_t value);


private:
    static void addCRC(packet &data);
};

