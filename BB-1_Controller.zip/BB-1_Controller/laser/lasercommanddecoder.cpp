#include "lasercommanddecoder.h"
#include <iostream>

LaserCommandDecoder::LaserCommandDecoder()
    : isReset(false)
{

}

void LaserCommandDecoder::addPacket(std::vector<uint8_t> packet)
{
    std::unique_lock<std::mutex> lock(queueMutex);
    queue.push(packet);
    conditionalVariable.notify_one();
}

void LaserCommandDecoder::begin()
{
    std::vector<uint8_t> packet;

    while (true)
    {
        {
            std::unique_lock<std::mutex> lock(conditionMutex);
            conditionalVariable.wait_for(lock, std::chrono::milliseconds(10));
        }

        if (isReset)
        {
            std::unique_lock<std::mutex> lock(queueMutex);
            while (!queue.empty())
                queue.pop();
            isReset = false;
        }

        while(true)
        {
            {
                std::unique_lock<std::mutex> lock(queueMutex);
                if (queue.empty())
                    break;
                packet = queue.front();
                queue.pop();
            }

            information.type = InformationType::None;

            switch (packet[1])
            {
                case 0x11:
                    switch (packet[3])
                    {
                        case 0x03: // system status
                            information.type = InformationType::SystemStatus;
                            information.data.sysStatus = getUint32t(packet, 4);
                            break;

                        case 0x1C: // function status
                            information.type = InformationType::FunctionStatus;
                            information.data.funcStatus = getUint32t(packet, 4);
                            break;

                        case 0x12: // lamp volts
                            if (packet[5] == 1 || packet[5] == 2)
                            {
                                if (packet[5] == 1)
                                    information.type = InformationType::Lamp1Voltage;
                                else
                                    information.type = InformationType::Lamp2Voltage;

                                information.data.lampVoltage = static_cast<double>(getUint32t(packet, 6)) / 4095.0 * 100.0;
                            }

                            break;

                        case 0x1A: // Sysem Information
                            std::uint32_t index;

                            index = (static_cast<std::uint32_t>(packet[4]) * 0x100) + packet[5];

                            switch (index)
                            {
                                case 0x0020:  // pulse period
                                    information.type = InformationType::PulsePeriod;
                                    information.data.pulseFrequency = 1000000.0 / static_cast<double>(getUint32t(packet, 6));
                                    break;

                                case 0x0028:  // qs delay 1
                                    information.type = InformationType::QSwitch1Delay;
                                    information.data.qSwitchDelay = getUint32t(packet, 6);
                                    break;

                                case 0x002C:  // qs delay 2
                                    information.type = InformationType::QSwitch2Delay;
                                    information.data.qSwitchDelay = getUint32t(packet, 6);
                                    break;

                                case 0x02AC:  // Attenuator 1 position
                                    information.type = InformationType::Attenuator1Value;
                                    information.data.attenuatorValue = getUint32t(packet, 6);
                                    break;

                                case 0x0388:  // Attenuator 2 position
                                    information.type = InformationType::Attenuator2Value;
                                    information.data.attenuatorValue = getUint32t(packet, 6);
                                    break;

                                case 0x0018:  // QS Delay high limit
                                    information.type = InformationType::QSwitchDelayHigh;
                                    information.data.qSwitchDelayLimit = getUint32t(packet, 6);
                                    break;

                                case 0x001C:  // QS Delay low limit
                                    information.type = InformationType::QSwitchDelayLow;
                                    information.data.qSwitchDelayLimit = getUint32t(packet, 6);
                                    break;

                            }
                            break;
                    }
                    break;

                case 0x23: // Attenuator 1 fullscale
                    information.type = InformationType::Attenuator1FullScale;
                    information.data.attenuatorFullScale = getUint32t(packet, 2);
                    break;

                case 0x26: // Attenuator 1 position
                    information.type = InformationType::Attenuator1Value;
                    information.data.attenuatorValue = getUint32t(packet, 2);
                    break;

                case 0x3E: // Attenuator N
                    switch (packet[3])
                    {
                        case 0x00: // Attenuator position
                            information.data.attenuatorValue = getUint32t(packet, 4);
                            if (packet[2] == 0)
                                information.type = InformationType::Attenuator1Value;
                            else
                                information.type = InformationType::Attenuator2Value;
                            break;

                        case 0x01: // Attenuator fullscale
                            information.data.attenuatorFullScale = getUint32t(packet, 4);
                            if (packet[2] == 0)
                                information.type = InformationType::Attenuator1FullScale;
                            else
                                information.type = InformationType::Attenuator2FullScale;
                            break;
                    }
                    break;
            }

            if (information.type != InformationType::None)
            {
                newInformationCallback(information);
            }
        }
    }
}

void LaserCommandDecoder::setNewInformationCallback(const NewInformationCallback &value)
{
    newInformationCallback = value;
}

void LaserCommandDecoder::reset()
{
    isReset = true;
}

uint64_t LaserCommandDecoder::getUint64t(std::vector<uint8_t> &vector, size_t index)
{
    std::uint64_t value64;
    value64 = static_cast<std::uint64_t>(vector[index + 7])
            + (static_cast<std::uint64_t>(vector[index + 6]) << 8)
            + (static_cast<std::uint64_t>(vector[index + 5]) << 16)
            + (static_cast<std::uint64_t>(vector[index + 4]) << 24)
            + (static_cast<std::uint64_t>(vector[index + 3]) << 32)
            + (static_cast<std::uint64_t>(vector[index + 2]) << 40)
            + (static_cast<std::uint64_t>(vector[index + 1]) << 48)
            + (static_cast<std::uint64_t>(vector[index]) << 56);
    return value64;
}

uint32_t LaserCommandDecoder::getUint32t(std::vector<uint8_t> &vector, size_t index)
{
    std::uint32_t value32;
    value32 = static_cast<std::uint32_t>(vector[index + 3])
            + (static_cast<std::uint32_t>(vector[index + 2]) << 8)
            + (static_cast<std::uint32_t>(vector[index + 1]) << 16)
            + (static_cast<std::uint32_t>(vector[index]) << 24);
    return value32;
}
void LaserCommandDecoder::systemStatus::setFromValue(uint32_t value)
{
    systemState = ((value & 0x1) > 0);
    pumpState = ((value & 0x2) > 0);
    laserState = ((value & 0x4) > 0);
    shutterState = ((value & 0x8) > 0);

    interlockWaterFlow = ((value & 0x10) > 0);
    interlockWaterLevel = ((value & 0x20) > 0);
    interlockWaterTemp = ((value & 0x40) > 0);
    interlockCharger2 = ((value & 0x80) > 0);
    interlockPsuTemp = ((value & 0x100) > 0);
    interlockCharger1 = ((value & 0x200) > 0);
    interlockExternal = ((value & 0x400) > 0);
    interlockPsuCover = ((value & 0x800) > 0);
    interlockLaserHead = ((value & 0x1000) > 0);
    interlockShutter = ((value & 0x2000) > 0);
    interlockSimmer1 = ((value & 0x4000) > 0);
    interlockSimmer2 = ((value & 0x8000) > 0);

    waterFlow = ((value & 0x2000000) > 0);
    keyState = ((value & 0x4000000) > 0);

    QS1TriggerSource = ((value & 0x8000000) > 0);
    QS2TriggerSource = ((value & 0x10000000) > 0);
    lamp1TrigSource = ((value & 0x20000000) > 0);
    lamp2TrigSource = ((value & 0x40000000) > 0);
    interlocksLatched = ((value & 0x80000000) > 0);
}

void LaserCommandDecoder::functionStatus::setFromValue(uint32_t value)
{
    lamp1TrigEn = ((value & 0x1) > 0);
    lamp2TrigEn = ((value & 0x2) > 0);
    QS1TrigEn = ((value & 0x4) > 0);
    QS2TrigEn = ((value & 0x8) > 0);

    flashlampDelayNegative = ((value & 0x100) > 0);

    repRateDivMode1 = ((value & 0x200) > 0);
    burstMode1 = ((value & 0x400) > 0);
    repRateDivMode2 = ((value & 0x800) > 0);
    burstMode2 = ((value & 0x1000) > 0);

    trigMode = ((value & 0x2000) > 0);

    lowFrequency1 = ((value & 0x4000) > 0);
    lowFrequency2 = ((value & 0x8000) > 0);

    shutterInhibited = ((value & 0x10000) > 0);

    strike1 = ((value & 0x20000) > 0);
    strike2 = ((value & 0x40000) > 0);
    crystalTemp = ((value & 0x80000) > 0);
    wavelengthSelectorPosUndefined = ((value & 0x100000) > 0);
    mirrorMoverPosUndefined = ((value & 0x200000) > 0);
}
