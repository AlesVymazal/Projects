#pragma once

#include <functional>
#include <queue>
#include <mutex>
#include <atomic>
#include <vector>
#include <condition_variable>

class LaserCommandDecoder
{
public:
    struct systemStatus
    {
        bool systemState;
        bool pumpState;
        bool laserState;
        bool shutterState;

        bool interlockWaterFlow;
        bool interlockWaterLevel;
        bool interlockWaterTemp;
        bool interlockCharger2;
        bool interlockPsuTemp;
        bool interlockCharger1;
        bool interlockExternal;
        bool interlockPsuCover;
        bool interlockLaserHead;
        bool interlockShutter;
        bool interlockSimmer1;
        bool interlockSimmer2;

        bool waterFlow;
        bool keyState;

        bool QS1TriggerSource;
        bool QS2TriggerSource;
        bool lamp1TrigSource;
        bool lamp2TrigSource;
        bool interlocksLatched;

        void setFromValue(std::uint32_t value);
    };

    struct functionStatus {
        bool lamp1TrigEn;
        bool lamp2TrigEn;
        bool QS1TrigEn;
        bool QS2TrigEn;

        bool flashlampDelayNegative;

        bool repRateDivMode1;
        bool burstMode1;
        bool repRateDivMode2;
        bool burstMode2;

        bool trigMode;

        bool lowFrequency1;
        bool lowFrequency2;

        bool shutterInhibited;

        bool strike1;
        bool strike2;
        bool crystalTemp;
        bool wavelengthSelectorPosUndefined;
        bool mirrorMoverPosUndefined;

        void setFromValue(std::uint32_t value);
    };

    enum InformationType
    {
        None,
        FunctionStatus,
        SystemStatus,
        Lamp1Voltage,
        Lamp2Voltage,
        Attenuator1Value,
        Attenuator2Value,
        Attenuator1FullScale,
        Attenuator2FullScale,
        QSwitch1Delay,
        QSwitch2Delay,
        QSwitchDelayHigh,
        QSwitchDelayLow,
        PulsePeriod
    };

    union Data {
        std::uint32_t funcStatus;
        std::uint32_t sysStatus;
        std::uint32_t qSwitchDelay;
        std::uint32_t attenuatorValue;
        std::uint32_t attenuatorFullScale;
        std::uint32_t qSwitchDelayLimit;
        std::uint64_t value64;
        double lampVoltage;
        double pulseFrequency;
    };

    struct newInformation {
        InformationType type;
        Data data;
    } information;

    typedef std::function<void (newInformation)> NewInformationCallback;

    LaserCommandDecoder();

    void addPacket(std::vector<std::uint8_t> packet);

    void begin();

    void setNewInformationCallback(const NewInformationCallback &value);

    void reset();

private:
    std::uint64_t getUint64t(std::vector<std::uint8_t> &vector, size_t index);
    std::uint32_t getUint32t(std::vector<std::uint8_t> &vector, size_t index);

    NewInformationCallback newInformationCallback;

    std::atomic<bool> isReset;

    std::queue<std::vector<std::uint8_t>> queue;
    std::mutex queueMutex;

    std::condition_variable conditionalVariable;
    std::mutex conditionMutex;

};

