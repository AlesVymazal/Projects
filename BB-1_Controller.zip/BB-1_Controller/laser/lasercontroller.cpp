#include "lasercontroller.h"
#include <iostream>

LaserController::LaserController() :
    laserPacketParser(&laserCommandDecoder)
{
}

void LaserController::setNewInformationCallback(const LaserCommandDecoder::NewInformationCallback &value)
{
    laserCommandDecoder.setNewInformationCallback(value);
}

void LaserController::newData(std::vector<uint8_t> data)
{
    laserPacketParser.addData(data);
}

void LaserController::reset()
{
    laserPacketParser.reset();
    laserCommandDecoder.reset();
}

void LaserController::thread1Process()
{
    std::cout << "Decoder: " << std::this_thread::get_id() << std::endl;
    laserCommandDecoder.begin();
}

void LaserController::thread2Process()
{
    std::cout << "Parser: " << std::this_thread::get_id() << std::endl;
    laserPacketParser.begin();
}


