#pragma once

#include "lasercommand.h"
#include "laserpacketparser.h"

class LaserController
{
public:
    LaserController();

    void setNewInformationCallback(const LaserCommandDecoder::NewInformationCallback &value);

    void newData(std::vector<std::uint8_t> data);

    void reset();

    void thread1Process();

    void thread2Process();

private:
    LaserCommandDecoder laserCommandDecoder;
    LaserPacketParser laserPacketParser;
};

