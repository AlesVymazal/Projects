#include "laserpacketparser.h"
#include <iostream>

LaserPacketParser::LaserPacketParser(LaserCommandDecoder *commandDecoder)
    : commandDecoder(commandDecoder), isReset(false)
{
}

void LaserPacketParser::addData(std::vector<uint8_t> data)
{
    std::unique_lock<std::mutex> lock(queueMutex);
    for (uint8_t byte : data)
    {
        queue.push(byte);
    }
    conditionalVariable.notify_one();
}

void LaserPacketParser::begin()
{
    uint8_t newByte;

    while (true)
    {
        if (isReset)
        {
            packetState = PacketState::AA1;
            expectedDataSize = 0;
            realDataSize = 0;
            incomingPacket.clear();

            std::unique_lock<std::mutex> lock(queueMutex);
            while (queue.size())
                queue.pop();

            isReset = false;
        }

        {
            std::unique_lock<std::mutex> lock(conditionMutex);
            conditionalVariable.wait_for(lock, std::chrono::milliseconds(10));
        }

        while (true)
        {
            {
                std::unique_lock<std::mutex> lock(queueMutex);
                if (queue.empty()) {
                    break;
                }
                newByte = queue.front();
                queue.pop();
            }

            switch (packetState)
            {
                case PacketState::AA1:
                    if (newByte == 0xAA)
                    {
                        packetState = PacketState::AA2;
                    }
                    break;

                case PacketState::AA2:
                    if (newByte == 0xAA)
                    {
                        packetState = PacketState::Sender;
                    }
                    else
                        packetState = PacketState::AA1;
                    break;

                case PacketState::Sender:
                    if (!newByte)
                    {
                        packetState = PacketState::Destination;
                        break;
                    }
                    packetState = PacketState::AA1;
                    break;

                case PacketState::Destination:
                    if (newByte)
                    {
                        packetState = PacketState::Count1;
                        break;
                    }
                    packetState = PacketState::AA1;
                    break;

                case PacketState::Count1:
                    expectedDataSize = static_cast<std::uint32_t>(newByte) << 8;
                    packetState = PacketState::Count2;
                    break;

                case PacketState::Count2:
                    expectedDataSize += newByte - 6;

                    if (expectedDataSize > 20)
                    {
                        packetState = PacketState::AA1;
                        break;
                    }
                    packetState = PacketState::Data;
                    realDataSize = 0;
                    break;

                case PacketState::Data:
                    incomingPacket.push_back(newByte);
                    realDataSize += 1;
                    if (realDataSize == expectedDataSize)
                    {
                        commandDecoder->addPacket(incomingPacket);
                        incomingPacket.clear();
                        packetState = PacketState::AA1;
                    }
                    break;
            }
        }
    }
}

void LaserPacketParser::reset()
{
    isReset = true;
}
