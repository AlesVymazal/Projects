#pragma once

#include <queue>
#include <vector>
#include <cstdint>
#include <mutex>
#include <atomic>
#include <condition_variable>
#include "lasercommanddecoder.h"

class LaserPacketParser
{
public:
    LaserPacketParser(LaserCommandDecoder *commandDecoder);

    void addData(std::vector<std::uint8_t> data);

    void begin();

    void reset();

private:
    enum PacketState
    {
        AA1,
        AA2,
        Sender,
        Destination,
        Count1,
        Count2,
        Data
    };

    LaserCommandDecoder *commandDecoder;
    std::queue<std::uint8_t> queue;
    std::mutex queueMutex;

    PacketState packetState;
    std::vector<std::uint8_t> incomingPacket;
    std::uint32_t expectedDataSize = 0;
    std::uint32_t realDataSize = 0;

    std::atomic<bool> isReset;

    std::condition_variable conditionalVariable;
    std::mutex conditionMutex;
};

