#include "led.h"

Led::Led(QWidget *parent)
    : QWidget(parent), isOnState(false)
{
    setAttribute(Qt::WA_NoSystemBackground);
}

bool Led::setIsOn() const
{
    return isOnState;
}

void Led::setIsOn(bool state)
{
    if(state != isOnState)
    {
        isOnState = state;
        emit isOnChanged();
        update();
    }
}

void Led::paintEvent(QPaintEvent *event){
    Q_UNUSED(event)
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setPen(Qt::NoPen);

    if(isOnState)
        painter.setBrush(isEnabled() ? Qt::green : QColor::fromRgb(0x50, 0xFF, 0x50));
    else
        painter.setBrush(isEnabled() ? Qt::darkGray : Qt::lightGray);

    painter.drawRoundRect(rect(), 15, 30);
}
