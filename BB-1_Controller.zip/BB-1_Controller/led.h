#include <QWidget>
#include <QPainter>
#include <QColor>

#pragma once

class Led : public QWidget{
    Q_OBJECT
    Q_PROPERTY(bool setIsOn READ setIsOn WRITE setIsOn NOTIFY isOnChanged)

    Led(const Led&) = delete;
    Led& operator=(const Led&) = delete;

public:
    explicit Led(QWidget* parent=nullptr);

    bool setIsOn() const;

public slots:
    void setIsOn(bool setIsOn);

signals:
    void isOnChanged();

protected:
    virtual void paintEvent(QPaintEvent *event) override;

private:
    bool isOnState;
};


