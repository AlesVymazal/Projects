#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QStandardPaths>
#include <QXmlStreamReader>
#include <QDebug>
#include <QGenericArgument>
#include <ddg/libsdelaygeneratorsystemsettingsdialog.h>

bool readXmlFile(QIODevice& device, QSettings::SettingsMap& map) {
    QLocale cLoc = QLocale::c();
    cLoc.setNumberOptions(QLocale::OmitGroupSeparator);
    QXmlStreamReader xmlReader(&device);
    if (xmlReader.hasError())
        return false;
    xmlReader.readNextStartElement();
    while (!(xmlReader.tokenType() == QXmlStreamReader::EndElement && xmlReader.name() == QString("settings"))) {
        if (xmlReader.isStartElement()) {
            if (xmlReader.attributes().hasAttribute(QString("typeName")) &&
                xmlReader.attributes().hasAttribute(QString("name"))) {
                //                QVariant::Type type=
                //                QVariant::nameToType(xmlReader.attributes().value(QString("typeName")).toLocal8Bit().data());
                QVariant::Type type = (QVariant::Type)xmlReader.attributes().value(QString("type")).toInt();
                QString name        = xmlReader.attributes().value(QString("name")).toString();
                QVariant var        = QVariant(xmlReader.readElementText());
                switch (type) {
                    case QVariant::ByteArray: {
                        var = QByteArray::fromBase64(var.toByteArray());
                        map.insert(name, var);
                        break;
                    }
                    case QVariant::Rect: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 4) {
                            map.insert(name, QVariant(QRect(l[0].toInt(), l[1].toInt(), l[2].toInt(), l[3].toInt())));
                        }
                        break;
                    }
                    case QVariant::RectF: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 4) {
                            map.insert(
                                name,
                                QVariant(QRectF(l[0].toDouble(), l[1].toDouble(), l[2].toDouble(), l[3].toDouble())));
                        }
                        break;
                    }
                    case QVariant::Size: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 2) {
                            map.insert(name, QVariant(QSize(l[0].toInt(), l[1].toInt())));
                        }
                        break;
                    }
                    case QVariant::SizeF: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 2) {
                            map.insert(name, QVariant(QSizeF(l[0].toDouble(), l[1].toDouble())));
                        }
                        break;
                    }
                    case QVariant::Point: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 2) {
                            map.insert(name, QVariant(QPoint(l[0].toInt(), l[1].toInt())));
                        }
                        break;
                    }
                    case QVariant::PointF: {
                        QStringList l = var.toString().split(';');
                        if (l.count() == 2) {
                            map.insert(name, QVariant(QPointF(l[0].toDouble(), l[1].toDouble())));
                        }
                        break;
                    }
                    default:
                        if (var.canConvert(type)) {
                            if (var.convert(type))
                                map.insert(name, var);
                        }
                        break;
                }
            }
        }
        xmlReader.readNext();
    }
    return true;
}

bool writeXmlFile(QIODevice& device, const QSettings::SettingsMap& map) {
    QLocale cLoc = QLocale::c();
    cLoc.setNumberOptions(QLocale::OmitGroupSeparator);
    QXmlStreamWriter xmlWriter(&device);
    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    xmlWriter.writeStartElement(QString("settings"));
    QMapIterator<QString, QVariant> i(map);
    while (i.hasNext()) {
        i.next();
        xmlWriter.writeStartElement(QString("param"));
        xmlWriter.writeAttribute(QString("name"), i.key());
        xmlWriter.writeAttribute(QString("type"), QString::number(i.value().type()));
        xmlWriter.writeAttribute(QString("typeName"), i.value().typeName());
        switch (i.value().type()) {
            case QVariant::ByteArray:
                xmlWriter.writeCharacters(i.value().toByteArray().toBase64().data());
                break;
            case QVariant::Rect: {
                QRect r = i.value().toRect();
                xmlWriter.writeCharacters(QString("%1;%2;%3;%4").arg(r.x()).arg(r.y()).arg(r.width()).arg(r.height()));
                break;
            }
            case QVariant::RectF: {
                QRectF r = i.value().toRectF();
                xmlWriter.writeCharacters(QString("%1;%2;%3;%4").arg(r.x()).arg(r.y()).arg(r.width()).arg(r.height()));
                break;
            }
            case QVariant::Size: {
                QSize s = i.value().toSize();
                xmlWriter.writeCharacters(QString("%1;%2").arg(s.width()).arg(s.height()));
                break;
            }
            case QVariant::SizeF: {
                QSizeF s = i.value().toSizeF();
                xmlWriter.writeCharacters(QString("%1;%2").arg(s.width()).arg(s.height()));
                break;
            }
            case QVariant::Point: {
                QPoint p = i.value().toPoint();
                xmlWriter.writeCharacters(QString("%1;%2").arg(p.x()).arg(p.y()));
                break;
            }
            case QVariant::PointF: {
                QPointF p = i.value().toPointF();
                xmlWriter.writeCharacters(QString("%1;%2").arg(p.x()).arg(p.y()));
                break;
            }
            default:
                if (i.value().canConvert(QVariant::String)) {
                    xmlWriter.writeCharacters(i.value().toString());
                } else {
                    xmlWriter.writeCharacters("Unsupported type!");
                }
                break;
        }
        xmlWriter.writeEndElement();
    }
    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();
    return true;
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // Set config XML file default format
    QSettings::Format xmlFormat = QSettings::registerFormat("xml", readXmlFile, writeXmlFile);
    QSettings::setDefaultFormat(xmlFormat);
    QSettings::setPath(
        xmlFormat, QSettings::UserScope, QString(QStandardPaths::writableLocation(QStandardPaths::ConfigLocation)));

    // Activate log messages
    qRegisterMetaType<LIBS::messageType>("LIBS::messageType");
    m_logBrowser = new LogBrowser(this);
    connect(ui->actionLog_browser, &QAction::triggered, [=]() { m_logBrowser->show(); });

    // MOTORS tab part
    // Connect expander slider with spinbox
    QSettings stageSettings(Config("trinamic").Default(), QSettings::defaultFormat());
    int expanderAxisNum = stageSettings.value("private/stage/attAxis", 0).toInt();

    int minimalValue =
        stageSettings.value(QString("trinamic/mdriver_motor_%1_stopPositionMm").arg(expanderAxisNum), 0).toInt();
    int maximalValue =
        stageSettings.value(QString("trinamic/mdriver_motor_%1_startPositionMm").arg(expanderAxisNum), 360).toInt();

    ui->horizontalSlider_expander->setMinimum(minimalValue);
    ui->doubleSpinBox_expander->setMinimum(minimalValue);

    ui->horizontalSlider_expander->setMaximum(maximalValue);
    ui->doubleSpinBox_expander->setMaximum(maximalValue);

    connect(ui->horizontalSlider_expander, &QSlider::valueChanged, [=](int value) {
        ui->doubleSpinBox_expander->setValue(value);
    });
    connect(ui->doubleSpinBox_expander,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double value) { ui->horizontalSlider_expander->setValue(static_cast<int>(value)); });

    ui->horizontalSlider_expander->setValue(minimalValue);

    // Connect focuser slider with spinbox
    int focuserAxisNum = stageSettings.value("private/stage/focusAxis", 0).toInt();

    minimalValue =
        stageSettings.value(QString("trinamic/mdriver_motor_%1_stopPositionMm").arg(focuserAxisNum), 0).toInt();
    maximalValue =
        stageSettings.value(QString("trinamic/mdriver_motor_%1_startPositionMm").arg(focuserAxisNum), 200).toInt();

    ui->horizontalSlider_focuser->setMinimum(minimalValue);
    ui->doubleSpinBox_focuser->setMinimum(minimalValue);

    ui->horizontalSlider_focuser->setMaximum(maximalValue);
    ui->doubleSpinBox_focuser->setMaximum(maximalValue);

    connect(ui->horizontalSlider_focuser, &QSlider::valueChanged, [=](int value) {
        ui->doubleSpinBox_focuser->setValue(value);
    });

    connect(ui->doubleSpinBox_focuser,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double value) { ui->horizontalSlider_focuser->setValue(static_cast<int>(value)); });

    ui->horizontalSlider_focuser->setValue(minimalValue);

    m_stageSettingsDialog = new StageSettingsDialog(this);

    // Show stage settings dialog
    connect(ui->actionStage_settings, &QAction::triggered, [=]() { m_stageSettingsDialog->show(); });

    m_stageThread = new QThread(this);
    m_stage       = new LIBSStageV2();
    m_stage->moveToThread(m_stageThread);
    m_stageThread->start();
    m_stageSettingsDialog->connectTo(m_stage);
    m_stage->readSettings();

    connect(m_stage, &LIBSStageV2::openDevicesFinished, this, [=]() { m_stage->init(); }, Qt::QueuedConnection);

    QMetaObject::invokeMethod(m_stage, "OpenDevices", Qt::QueuedConnection);

    //  logging messages from m_stage to LogBrowser
    connect(m_stage,
            &LIBSStageV2::sendMessage,
            this,
            [=](LIBS::messageType type, QString msg) { m_logBrowser->writeMessage(type, msg); },
            Qt::QueuedConnection);

    // Primary DDG tab part
    QVBoxLayout* layoutMasterDDG = new QVBoxLayout(ui->tab_DDGMaster);
    layoutMasterDDG->addWidget(new LibsDelayGeneratorSystemSettingsDialog(m_stage->DelayGeneratorSystem(), this));
    ui->tab_DDGMaster->setLayout(layoutMasterDDG);

    // Secondary DDG tab part
    QVBoxLayout* layoutLaserDDG = new QVBoxLayout(ui->tab_DDGLaser);
    layoutLaserDDG->addWidget(
        new LibsDelayGeneratorSystemSettingsDialog(m_stage->SecondaryDelayGeneratorSystem(), this));
    ui->tab_DDGLaser->setLayout(layoutLaserDDG);

    connect(m_stage,
            &LIBSStageV2::calibrationProcessStarted,
            this,
            [=]() {
                m_calibrationProgressDialog =
                    new QProgressDialog(QString("Calibration ..."), QString(), 0, 0, this, Qt::Dialog);
                m_calibrationProgressDialog->setModal(true);
                m_calibrationProgressDialog->show();
            },
            Qt::QueuedConnection);

    connect(m_stage,
            &LIBSStageV2::calibrationProcessFinished,
            this,
            [=]() {
                if (m_calibrationProgressDialog) {
                    m_calibrationProgressDialog->setValue(10);
                    delete m_calibrationProgressDialog;
                    m_calibrationProgressDialog = nullptr;
                }
            },
            Qt::QueuedConnection);

    // Connect action stop motors with m_stage
    connect(ui->actionStop_motors, &QAction::triggered, [=]() { m_stage->Stop(); });

    // Connect action Calibrate motors
    connect(ui->actionCalibrate_motors, &QAction::triggered, [=]() {
        if (m_stage->calibrationNeeded()) {
            QMetaObject::invokeMethod(m_stage, "calibrate", Q_ARG(bool, false));
        } else {
            QMessageBox::StandardButton btn =
                QMessageBox::information(this,
                                         QString("Chamber is calibrated"),
                                         QString("Chamber calibration is valid, do you want to force recalibration?"),
                                         QMessageBox::Yes,
                                         QMessageBox::No);
            if (btn == QMessageBox::Yes) {
                QMetaObject::invokeMethod(m_stage, "calibrate", Q_ARG(bool, true));
            }
        }
    });

    connect(ui->doubleSpinBox_expander,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double value) {
                QMetaObject::invokeMethod(m_stage->Attenuator(), "MoveToPosition", Q_ARG(double, value));
            });

    connect(
        ui->doubleSpinBox_focuser,
        static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
        [=](double value) { QMetaObject::invokeMethod(m_stage->Focuser(), "MoveToPosition", Q_ARG(double, value)); });

    connect(ui->doubleSpinBox_stepMultiplier,
            static_cast<void (QDoubleSpinBox::*)(double)>(&QDoubleSpinBox::valueChanged),
            [=](double value) { m_stepMultiplier = value; });

    connect(ui->pushButton_moveUp, &QPushButton::clicked, [=]() {
        QMetaObject::invokeMethod(m_stage->Focuser(), "MoveRelative", Q_ARG(double, m_stepMultiplier));
    });

    connect(ui->pushButton_moveDown, &QPushButton::clicked, [=]() {
        QMetaObject::invokeMethod(m_stage->Focuser(), "MoveRelative", Q_ARG(double, -m_stepMultiplier));
    });

    connect(ui->pushButton_rotateLeft, &QPushButton::clicked, [=]() {
        QMetaObject::invokeMethod(m_stage->Attenuator(), "MoveRelative", Q_ARG(double, m_stepMultiplier));

    });

    connect(ui->pushButton_rotateRight, &QPushButton::clicked, [=]() {
        QMetaObject::invokeMethod(m_stage->Attenuator(), "MoveRelative", Q_ARG(double, -m_stepMultiplier));
    });

    //connect(ui->pushButton_11, SIGNAL(clicked()),this,SLOT(ui->lineEdit_7->setText("....")));

    //connect(ui->pushButton_11, &QPushButton::clicked, this, [=](){ui->lineEdit_7->setText("temperatureVal");});
    /*connect(ui->pushButton_11, &QPushButton::clicked,[=]() {
        QMetaObject::invokeMethod(m_stage->TemperatureSystem(), "TemperatureID", ui->lineEdit_7->setText(temperatureVal));});*/ //{ui->lineEdit_7->setText(temperatureVal);});


    connect(ui->pushButton_11, &QPushButton::clicked,[=]() {
        QMetaObject::invokeMethod(m_stage->TemperatureSystem(), "MirrorPosition", Q_ARG(ModuleTemperatureSensor::MirrorPositionValue, ModuleTemperatureSensor::Center));
        QMetaObject::invokeMethod(m_stage->TemperatureSystem(), "TemperatureID", Q_ARG(int,1));
        QMetaObject::invokeMethod(m_stage->RangeFinderSystem(), "Message", Q_ARG(ModuleRangeFinder::MirrorSystemCommands, ModuleRangeFinder::StopMeasuring));



    });

//    connect(ui->pushButton_11, &QPushButton::clicked,[=]() {
//        QMetaObject::invokeMethod(m_stage->TemperatureSystem(), "TemperatureID", Q_ARG(int,1));
//    });

//    QString ReturnVal = m_stage->TemperatureSystem()->TemperatureID(1);

//    connect(ui->pushButton_11, &QPushButton::clicked, this, [=](){ui->lineEdit_7->setText(ReturnVal);});

//    connect(ui->pushButton_11, &QPushButton::clicked,[=]() {
//        QMetaObject::invokeMethod(m_stage->TemperatureSystem(), "MirrorPosition(MirrorPositionValue)", Q_ARG(ModuleTemperatureSensor::MirrorPositionValue ,ModuleTemperatureSensor::MirrorPositionValue::Left));
//    });



    //m_stage->TemperatureSystem()->TemperatureID(0);

    //m_stage->TemperatureSystem()->MirrorPosition(ModuleTemperatureSensor::Center);
    //m_stage->Attenuator()->MoveRelative(-m_stepMultiplier);



   //connect()

    m_initialWaitProgressDialog =
        new QProgressDialog("Initializing ... please wait", QString(), 0, 5, this, Qt::Dialog);
    m_initialWaitProgressDialog->setModal(true);
    m_initialWaitProgressDialog->setValue(0);
    m_initialWaitProgressDialog->show();
    int counter   = 1;
    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [=]() mutable {
        if (counter <= 5)
            m_initialWaitProgressDialog->setValue(counter);
        counter++;
    });
    timer->start(1000);
    // Run automatic calibration on startup if needed
    // TODO: try to reimplement this to wait until stage is ready to check if calibration is really needed
    //       maybe using locks and semaphores
    QTimer::singleShot(5000, [=]() {
        m_initialWaitProgressDialog->setValue(5);
        timer->stop();
        if (m_initialWaitProgressDialog) {
            delete m_initialWaitProgressDialog;
            m_initialWaitProgressDialog = nullptr;
        }
        if (m_stage->calibrationNeeded()) {
            QMessageBox::StandardButton btn =
                QMessageBox::information(this,
                                         QString("Chamber is not calibrated"),
                                         QString("Chamber is not currently calibrated, can be calibration performed?"),
                                         QMessageBox::Yes,
                                         QMessageBox::No);
            if (btn == QMessageBox::Yes) {
                QMetaObject::invokeMethod(m_stage, "calibrate", Qt::QueuedConnection, Q_ARG(bool, false));
            }
        }
    });

    QMainWindow::showMaximized();

    // QTimer::singleShot(1000, [=]() { m_stage->init(); });
}

MainWindow::~MainWindow() {
    m_stage->deleteLater();
    m_stageThread->quit();
    m_stageThread->wait();
    delete m_stageThread;
    delete ui;
}





