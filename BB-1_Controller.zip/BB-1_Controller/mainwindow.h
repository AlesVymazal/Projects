#pragma once

#include "LogBrowser.h"
#include "StageSettingsDialog.h"

#include <QMainWindow>
#include <QProgressDialog>
#include <QSettings>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:


private:
    Ui::MainWindow* ui;

    StageSettingsDialog* m_stageSettingsDialog;
    LogBrowser* m_logBrowser;
    QProgressDialog* m_calibrationProgressDialog = nullptr;
    QProgressDialog* m_initialWaitProgressDialog = nullptr;

    QThread* m_stageThread;
    LIBSStageV2* m_stage;

    double m_stepMultiplier = 1.00;
};
