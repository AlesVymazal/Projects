#include "spectrometercamera.h"
#include "ui_spectrometercamera.h"

#include "VmbTransform.h"

#include <QFileDialog>
#include <iostream>

using AVT::VmbAPI::FramePtr;
using AVT::VmbAPI::CameraPtrVector;

SpectrometerCamera::SpectrometerCamera(QWidget *parent) :
    QWidget(parent), ui(new Ui::SpectrometerCamera), m_bIsStreaming(false), connected(false), actualCamera("")
{
    ui->setupUi(this);
    ui->cameraLiveView->setAlignment(Qt::AlignCenter);
    // Start Vimba
    VmbErrorType err = m_ApiController.StartUp();

    if (err == VmbErrorSuccess)
    {
        // Connect new camera found event with event handler
        QObject::connect(m_ApiController.GetCameraObserver(), SIGNAL(CameraListChangedSignal(int)), this, SLOT(onCameraListChanged(int)));

        // Initially get all connected cameras
        fillCameraComboBox();
    }

    setUiEnabled(connected);
}

SpectrometerCamera::~SpectrometerCamera()
{
    // if we are streaming stop streaming
    if (m_bIsStreaming)
    {
        on_startStopButton_clicked();
    }

    // Before we close the application we stop Vimba
    m_ApiController.ShutDown();
    delete ui;
}

//
// This event handler (Qt slot) is triggered through a Qt signal posted by the frame observer
//
// Parameters:
//  [in]    status          The frame receive status (complete, incomplete, ...)
//
void SpectrometerCamera::onFrameReady(int status)
{
    if (m_bIsStreaming)
    {
        // Pick up frame
        FramePtr pFrame = m_ApiController.GetFrame();
        if (SP_ISNULL(pFrame))
        {
            return;
        }
        // See if it is not corrupt
        if (status == VmbFrameStatusComplete)
        {
            VmbUchar_t *pBuffer;
            VmbErrorType err = SP_ACCESS(pFrame)->GetImage(pBuffer);
            if (err == VmbErrorSuccess)
            {
                VmbUint32_t nSize;
                err = SP_ACCESS(pFrame)->GetImageSize(nSize);
                if (err == VmbErrorSuccess)
                {
                    VmbPixelFormatType ePixelFormat = m_ApiController.GetPixelFormat();
                    if (!m_Image.isNull())
                    {
//                        // Copy it
//                        // We need that because Qt might repaint the view after we have released the frame already
//                        if( ui.m_ColorProcessingCheckBox->checkState()==  Qt::Checked )
//                        {
//                            static const VmbFloat_t Matrix[] = {    8.0f, 0.1f, 0.1f, // this matrix just makes a quick color to mono conversion
//                                                                    0.1f, 0.8f, 0.1f,
//                                                                    0.0f, 0.0f, 1.0f };
//                            if( VmbErrorSuccess != copyToImage( pBuffer,ePixelFormat, m_Image, Matrix ) )
//                            {
//                                ui.m_ColorProcessingCheckBox->setChecked( false );
//                            }
//                        }
//                        else
//                        {
                            copyToImage(pBuffer,ePixelFormat, m_Image);
//                        }

                        // Display it
                        const QSize s = ui->cameraLiveView->size();
                        ui->cameraLiveView->setPixmap(QPixmap::fromImage(m_Image).scaled(s, Qt::KeepAspectRatio));
                    }
                }
            }
        }
        else
        {
            // If we receive an incomplete image we do nothing but logging
            Log( "Failure in receiving image", static_cast<VmbErrorType>(status) );
            ui->liveViewGroupBox->setTitle("Failure in receiving image");
        }

        // And queue it to continue streaming
        m_ApiController.QueueFrame(pFrame);
    }
}

//
// Copies the content of a byte buffer to a Qt image with respect to the image's alignment
//
// Parameters:
//  [in]    pInbuffer       The byte buffer as received from the cam
//  [in]    ePixelFormat    The pixel format of the frame
//  [out]   OutImage        The filled Qt image
//
VmbErrorType SpectrometerCamera::copyToImage(VmbUchar_t *pInBuffer, VmbPixelFormat_t ePixelFormat, QImage &pOutImage, const float *Matrix)
{
    const VmbUint32_t nHeight = m_ApiController.GetHeight();
    const VmbUint32_t nWidth = m_ApiController.GetWidth();

    VmbImage SourceImage, DestImage;
    VmbError_t Result;
    SourceImage.Size = sizeof(SourceImage);
    DestImage.Size = sizeof(DestImage);

    Result = VmbSetImageInfoFromPixelFormat(ePixelFormat, nWidth, nHeight, &SourceImage);
    if (Result != VmbErrorSuccess)
    {
        Log( "Could not set source image info", static_cast<VmbErrorType>( Result ) );
        return static_cast<VmbErrorType>(Result);
    }
    QString OutputFormat;
    const int bytes_per_line = pOutImage.bytesPerLine();

    switch (pOutImage.format())
    {
        case QImage::Format_RGB888:
            if (bytes_per_line != static_cast<int>(nWidth * 3))
            {
                Log( "image transform does not support stride",VmbErrorWrongType );
                return VmbErrorWrongType;
            }
            OutputFormat = "RGB24";
            break;

        default:
            Log( "unknown output format",VmbErrorBadParameter );
            return VmbErrorBadParameter;
    }

    Result = VmbSetImageInfoFromString(OutputFormat.toStdString().c_str(), static_cast<VmbUint32_t>(OutputFormat.length()), nWidth, nHeight, &DestImage);
    if (Result != VmbErrorSuccess)
    {
        Log( "could not set output image info",static_cast<VmbErrorType>( Result ) );
        return static_cast<VmbErrorType>(Result);
    }

    SourceImage.Data = pInBuffer;
    DestImage.Data = pOutImage.bits();
    // do color processing?
    if (Matrix != nullptr)
    {
        VmbTransformInfo TransformParameter;
        Result = VmbSetColorCorrectionMatrix3x3(Matrix, &TransformParameter);
        if (Result == VmbErrorSuccess)
        {
            Result = VmbImageTransform(&SourceImage, &DestImage, &TransformParameter, 1);
        }
        else
        {
            Log( "could not set matrix to transform info ", static_cast<VmbErrorType>( Result ) );
            return static_cast<VmbErrorType>(Result);
        }
    }
    else
    {
        Result = VmbImageTransform(&SourceImage, &DestImage, nullptr, 0);
    }
    if (Result != VmbErrorSuccess)
    {
        Log( "could not transform image", static_cast<VmbErrorType>( Result ) );
        return static_cast<VmbErrorType>(Result);
    }
    return static_cast<VmbErrorType>(Result);
}

void SpectrometerCamera::onCameraListChanged(int reason)
{
    if (reason == AVT::VmbAPI::UpdateTriggerPluggedIn || reason == AVT::VmbAPI::UpdateTriggerPluggedOut)
    {
        fillCameraComboBox();

        if (ui->cameraComboBox->findText(actualCamera) == -1)
        {
            if (m_bIsStreaming)
                on_startStopButton_clicked();
            if (connected)
                on_connectDisconnectButton_clicked();
        }
    }
}

void SpectrometerCamera::fillCameraComboBox()
{
    CameraPtrVector cameras = m_ApiController.GetCameraList();

    // Simply forget about all cameras known so far
    ui->cameraComboBox->clear();
    m_cameras.clear();

    // And query the camera details again
    for (auto camera : cameras)
    {
        std::string strCameraName;
        std::string strCameraID;
        if (SP_ACCESS(camera)->GetName(strCameraName) != VmbErrorSuccess)
        {
            strCameraName = "[NoName]";
        }
        // If for any reason we cannot get the ID of a camera we skip it
        if (SP_ACCESS(camera)->GetID(strCameraID) == VmbErrorSuccess)
        {
            ui->cameraComboBox->addItem(QString::fromStdString(strCameraName + " " + strCameraID));
            m_cameras.push_back(strCameraID);
        }
    }
}

void SpectrometerCamera::setUiEnabled(bool state)
{
    ui->detectorGroupBox->setEnabled(state);
    ui->spectraExportGroupBox->setEnabled(state);
    ui->liveViewGroupBox->setEnabled(state);
    ui->cameraComboBox->setEnabled(!state);
}

void SpectrometerCamera::on_connectDisconnectButton_clicked()
{
    VmbErrorType err;

    if (!connected)
    {
        int nRow = ui->cameraComboBox->currentIndex();
        if (nRow > -1)
        {
            err = m_ApiController.OpenCamera(m_cameras[static_cast<size_t>(nRow)]);
            std::cout << "Camera: " << m_cameras[static_cast<size_t>(nRow)] << std::endl;
            connected = err == VmbErrorSuccess;
        }
    }
    else
    {
        connected = false;
        m_ApiController.CloseCamera();
    }

    setUiEnabled(connected);

    if (connected == false)
    {
        actualCamera.clear();
        ui->connectDisconnectButton->setText("Connect");
    }
    else
    {
        actualCamera = ui->cameraComboBox->currentText();
        ui->connectDisconnectButton->setText("Disconnect");
    }
}

void SpectrometerCamera::on_expositionSpinBox_editingFinished()
{

}

void SpectrometerCamera::on_gainSpinBox_editingFinished()
{

}

void SpectrometerCamera::on_triggerComboBox_currentTextChanged(const QString &arg1)
{
    Q_UNUSED(arg1);
}

void SpectrometerCamera::on_strobeDelaySpinBox_editingFinished()
{

}

void SpectrometerCamera::on_startStopButton_clicked()
{
    VmbErrorType err;
    if (!m_bIsStreaming)
    {
        // Start acquisition
        err = m_ApiController.StartContinuousImageAcquisition();
        // Set up Qt image
        if (err == VmbErrorSuccess)
        {
            m_Image = QImage(static_cast<int>(m_ApiController.GetWidth()), static_cast<int>(m_ApiController.GetHeight()), QImage::Format_RGB888 );

            QObject::connect(m_ApiController.GetFrameObserver(), SIGNAL(FrameReceivedSignal(int)), this, SLOT( onFrameReady(int)));
        }
        Log( "Starting Acquisition", err );
        m_bIsStreaming = err == VmbErrorSuccess;
    }
    else
    {
        m_bIsStreaming = false;
        // Stop acquisition
        err = m_ApiController.StopContinuousImageAcquisition();
        // Clear all frames that we have not picked up so far
        m_ApiController.ClearFrameQueue();
        m_Image = QImage();
        Log( "Stopping Acquisition", err );
    }

    if (m_bIsStreaming == false)
    {
        ui->startStopButton->setText("START");
    }
    else
    {
        ui->startStopButton->setText("STOP");
    }
}

void SpectrometerCamera::on_browseButton_clicked()
{
    static QString fileName;
    fileName = QFileDialog::getExistingDirectory(this, tr("Open Directory"), fileName);
    ui->filenameTextBox->setText(fileName);
}



//
// Prints out a given logging string, error code and the descriptive representation of that error code
//
// Parameters:
//  [in]    strMsg          A given message to be printed out
//  [in]    eErr            The API status code
//
void SpectrometerCamera::Log( std::string strMsg, VmbErrorType eErr )
{
    strMsg += "..." + m_ApiController.ErrorCodeToMessage( eErr );
    std::cout << strMsg << std::endl;
}

//
// Prints out a given logging string
//
// Parameters:
//  [in]    strMsg          A given message to be printed out
//
void SpectrometerCamera::Log( std::string strMsg)
{
    std::cout << strMsg << std::endl;
}
