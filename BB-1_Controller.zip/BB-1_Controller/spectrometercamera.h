#pragma once

#include <QWidget>

#include "camera/ApiController.h"

using AVT::VmbAPI::Examples::ApiController;

namespace Ui {
class SpectrometerCamera;
}

class SpectrometerCamera : public QWidget
{
    Q_OBJECT

public:
    explicit SpectrometerCamera(QWidget *parent = nullptr);
    ~SpectrometerCamera();

private slots:
    void on_connectDisconnectButton_clicked();

    void on_expositionSpinBox_editingFinished();

    void on_gainSpinBox_editingFinished();

    void on_triggerComboBox_currentTextChanged(const QString &arg1);

    void on_strobeDelaySpinBox_editingFinished();

    void on_startStopButton_clicked();

    void on_browseButton_clicked();

    void onFrameReady( int status );
    void onCameraListChanged( int reason );

private:
    Ui::SpectrometerCamera *ui;
    // Our controller that wraps API access
    ApiController m_ApiController;
    // A list of known camera IDs
    std::vector<std::string> m_cameras;
    // Are we streaming?
    bool m_bIsStreaming;
    // Our Qt image to display
    QImage m_Image;
    QString actualCamera;
    bool connected;
    VmbErrorType copyToImage( VmbUchar_t *pInBuffer, VmbPixelFormat_t ePixelFormat, QImage &pOutImage, const float *Matrix = NULL );

    void fillCameraComboBox();

    void setUiEnabled(bool state);



    //
    // Prints out a given logging string, error code and the descriptive representation of that error code
    //
    // Parameters:
    //  [in]    strMsg          A given message to be printed out
    //  [in]    eErr            The API status code
    //
    void Log( std::string strMsg, VmbErrorType eErr );

    //
    // Prints out a given logging string
    //
    // Parameters:
    //  [in]    strMsg          A given message to be printed out
    //
    void Log( std::string strMsg);
};

