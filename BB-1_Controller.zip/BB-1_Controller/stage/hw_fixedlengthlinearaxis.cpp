#include "hw_fixedlengthlinearaxis.h"

FixedLengthLinearAxis::FixedLengthLinearAxis(unsigned char _motorIndex, TrinamicController* _driver, QObject* parent)
    : LinearAxis(_motorIndex, _driver, parent) {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    minRefDistance = settings.value(tmp + "minRefDistance", 1.4).toDouble();
    axisLength     = settings.value(tmp + "axisLength", 10).toDouble();
}

FixedLengthLinearAxis::~FixedLengthLinearAxis() {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    settings.setValue(tmp + "axisLength", axisLength);
    settings.setValue(tmp + "minRefDistance", minRefDistance);
}

void FixedLengthLinearAxis::calculateLimits() {
    //    qDebug() << QString("Calculating limits reference minimum %1 reference offset %2 axis length %3")
    //                    .arg(this->MinRefDistance())
    //                    .arg(this->ReferenceSwitchOffset())
    //                    .arg(this->AxisLength());
    this->SetStopPosition(-this->ReferenceSwitchOffset() + this->MinRefDistance());
    this->SetStartPosition(this->StopPosition() + this->AxisLength());
    emit LimitsChanged(this->StopPosition(), this->StartPosition());
}

void FixedLengthLinearAxis::SetupConfigGui(QWidget* _toSet) {
    TMCM610Motor::SetupConfigGui(_toSet);

    QGroupBox* groupBox;
    QGridLayout* gridLayout;
    QLabel* label;
    QDoubleSpinBox* doubleSpinBox;
    // QSpinBox *spinBox;

    groupBox = new QGroupBox(_toSet);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    groupBox->setTitle(QApplication::translate("groupBox", "axis settings", 0));

    gridLayout = new QGridLayout(groupBox);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "reference offset", 0));

    gridLayout->addWidget(label, 0, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxRefOffset"));
    doubleSpinBox->setMaximum(100);
    doubleSpinBox->setMinimum(-100);
    doubleSpinBox->setValue(this->ReferenceSwitchOffset());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetReferenceSwitchOffset(double)));
    connect(this, SIGNAL(ReferenceSwitchOffsetChanged(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 0, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "gear ratio", 0));

    gridLayout->addWidget(label, 1, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxGearRatio"));
    doubleSpinBox->setMaximum(1000);
    doubleSpinBox->setValue(this->GearRatio());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", ":1", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetGearRatio(double)));

    gridLayout->addWidget(doubleSpinBox, 1, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "thread pitch", 0));

    gridLayout->addWidget(label, 2, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxBolt"));
    doubleSpinBox->setMaximum(1000);
    doubleSpinBox->setValue(this->BoltMmPerRot());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetBoltMmPerRot(double)));

    gridLayout->addWidget(doubleSpinBox, 2, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "upper limit", 0));

    gridLayout->addWidget(label, 3, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxStart"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(this->StartPosition());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);
    doubleSpinBox->setReadOnly(true);

    //    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetStartPosition(double)));
    connect(this, SIGNAL(startPositionChanged(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 3, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "lower limit", 0));

    gridLayout->addWidget(label, 4, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxStop"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(this->StopPosition());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);
    doubleSpinBox->setReadOnly(true);

    //    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetStopPosition(double)));
    connect(this, SIGNAL(stopPositionChanged(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 4, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "axis length", 0));

    gridLayout->addWidget(label, 5, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxAxisLength"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(this->AxisLength());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetAxisLength(double)));

    gridLayout->addWidget(doubleSpinBox, 5, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "minimal distance from reference", 0));

    gridLayout->addWidget(label, 6, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxMinRefDist"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(this->MinRefDistance());
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetMinRefDistance(double)));

    gridLayout->addWidget(doubleSpinBox, 6, 1, 1, 1);

    ui.verticalLayout->addWidget(groupBox);

    groupBox = new QGroupBox(_toSet);
    groupBox->setObjectName(QString::fromUtf8("groupBox_calib"));
    groupBox->setTitle(QApplication::translate("groupBox_calib", "calibration control", 0));

    gridLayout = new QGridLayout(groupBox);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout_calib"));

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "target position", 0));
    gridLayout->addWidget(label, 1, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxTargetPos"));
    doubleSpinBox->setMaximum(this->StartPosition());
    doubleSpinBox->setMinimum(this->StopPosition());
    doubleSpinBox->setValue(this->GetRealPosition());
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);
    doubleSpinBox->setKeyboardTracking(false);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox:focus{color:red;}"));

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(MoveToPosition(double)));

    gridLayout->addWidget(doubleSpinBox, 1, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "relative movement", 0));
    gridLayout->addWidget(label, 2, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinRelativePos"));
    doubleSpinBox->setMaximum(5.0);
    doubleSpinBox->setMinimum(-5.0);
    doubleSpinBox->setValue(0);
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox:focus{color:red;}"));
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    gridLayout->addWidget(doubleSpinBox, 2, 1, 1, 1);

    QDoubleSpinBox* relSpinBox = doubleSpinBox;

    QPushButton* button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("relativePlus"));
    button->setText(QString(""));
    button->setIcon(QIcon(":/list-add.png"));

    connect(button, &QPushButton::clicked, [=](bool enable) {
        Q_UNUSED(enable) QMetaObject::invokeMethod(this, "MoveRelative", Q_ARG(double, relSpinBox->value()));
    });
    gridLayout->addWidget(button, 2, 3, 1, 1);

    button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("relativeMinus"));
    button->setText(QString(""));
    button->setIcon(QIcon(":/list-remove.png"));

    connect(button,
            &QPushButton::clicked,
            this,
            [=](bool enable) {
                Q_UNUSED(enable)
                QMetaObject::invokeMethod(this, "MoveRelative", Q_ARG(double, -relSpinBox->value()));
            },
            Qt::QueuedConnection);
    gridLayout->addWidget(button, 2, 2, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "current position", 0));
    gridLayout->addWidget(label, 3, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinCurrentPos"));
    doubleSpinBox->setMaximum(this->StartPosition());
    doubleSpinBox->setMinimum(this->StopPosition());
    doubleSpinBox->setValue(this->GetRealPosition());
    doubleSpinBox->setReadOnly(true);
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox{background-color:#f0f0f0;}"));
    doubleSpinBox->setFrame(false);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(this, SIGNAL(RealPosition(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 3, 1, 1, 1);

    button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("doubleSpinBoxStop"));
    button->setText(QApplication::translate("groupBox", "Tare", 0));
    button->setIcon(QIcon(":/applications-accessories.png"));

    connect(button, SIGNAL(clicked()), this, SLOT(TareReferenceSwitchOffset()));

    gridLayout->addWidget(button, 3, 2, 1, 2);
    gridLayout->setColumnStretch(0, 1);

    ui.verticalLayout->addWidget(groupBox);
    ui.verticalLayout->addSpacerItem(new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding));

    emit LimitsChanged(this->StopPosition(), this->StartPosition());
}

void FixedLengthLinearAxis::saveSettings() {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    settings.setValue(tmp + "axisLength", axisLength);
    settings.setValue(tmp + "minRefDistance", minRefDistance);
    LinearAxis::saveSettings();
}
