#ifndef FIXEDLENGTHLINEARAXIS_H
#define FIXEDLENGTHLINEARAXIS_H

#include "hw_linearAxis.h"

class FixedLengthLinearAxis : public LinearAxis {
    Q_OBJECT

public:
    FixedLengthLinearAxis(unsigned char _motorIndex, TrinamicController* _driver, QObject* parent);
    ~FixedLengthLinearAxis();

    virtual void SetupConfigGui(QWidget* _toSet);

    double AxisLength() {
        return axisLength;
    }
    double MinRefDistance() {
        return minRefDistance;
    }

    void calculateLimits();
public slots:
    void SetReferenceSwitchOffset(double _value) {
        LinearAxis::SetReferenceSwitchOffset(_value);
        calculateLimits();
    }
    void TareReferenceSwitchOffset() {
        LinearAxis::SetReferenceSwitchOffset(this->ReferenceSwitchOffset() + this->GetRealPosition());
        calculateLimits();
        this->CalculateRealPosition();
    }
    void SetMinRefDistance(double _dist) {
        minRefDistance = _dist;
        calculateLimits();
    }
    void SetAxisLength(double _length) {
        axisLength = _length;
        calculateLimits();
    }

    void saveSettings();

private:
    double axisLength;
    double minRefDistance;
};

#endif // FIXEDLENGTHLINEARAXIS_H
