#include "hw_general_axis.h"

DeviceController::~DeviceController() {
    foreach (DeviceAxis* motor, childAxes) // vypada to, ze pokud nesmazu odbjekty tady a necham to na QObject, tak
                                           // dojde ke smazani az pos mazadni rodice
        // funkce RemoveChildMotor(TMCM610Motor *motor) pak pristupuje do uvolnene pameti a heap error
        delete motor;
}

void DeviceController::CheckReferenceStatus() {
    int r = 0;
    foreach (DeviceAxis* motor, childAxes)
        if (motor->IsReferenced())
            ++r;

    if (childAxes.size() == r)
        emit AllAxesReferenced();
}

void DeviceController::CheckAxesStatus() {
    int m = 0;
    foreach (DeviceAxis* motor, childAxes)
        if (!motor->IsMoving())
            ++m;

    if (childAxes.size() == m)
        emit AllAxesStoped();
}

DeviceAxis::DeviceAxis(unsigned char _axisIndex, DeviceController* _driver, QObject* parent)
    : QObject(parent), driver(_driver), axisIndex(_axisIndex) {
    driver->AppendChildAxis(this);
    this->setParent(driver);
}
