#ifndef HWGENERALAXIS_H
#define HWGENERALAXIS_H

#include "LIBS.h"
#include "hw_ports.h"
#include <QObject>

class DeviceController;

//!  Trida reprezentuje obecnou osu libovolneho posuvu.
/*!
 * \ingroup hardware
 */
class DeviceAxis : public QObject {
    Q_OBJECT
public:
    DeviceAxis(unsigned char _axisIndex, DeviceController* _driver, QObject* parent = nullptr);
    virtual ~DeviceAxis() {
    }

    //! Generuje ovladaci GUI
    virtual void SetupConfigGui(QWidget* _toSet) = 0;

    //! vraci true pokud je motor referencovany
    virtual bool IsReferenced() = 0;

    //! true pokud je motor v pohybu
    virtual bool IsMoving() = 0;

signals:
    //! kdyz se motor zastavi
    void AxisStoped();
    //! kdyz se najde reference
    void AxisReferenced();

    void logMessage(LIBS::messageType mType, QString str);

protected:
    //! index motoru ktery trida obsluhuje
    unsigned char axisIndex;
    //! trida reprezentuje radic motoru trinamic
    DeviceController* driver;
};

//!  Trida reprezentuje pobecny kontroler.
/*!
 * \ingroup hardware
 */
class DeviceController : public QObject {
    Q_OBJECT

public:
    DeviceController(Config _config, QObject* parent = nullptr) : QObject(parent) {
        port   = nullptr;
        config = _config;
    }
    virtual ~DeviceController();

    Config ConfigPrefix() {
        return config;
    }

    // void SetPort(DevicePort* _port) { port = _port; };
    DevicePort* Port() {
        return port;
    }

    void AppendChildAxis(DeviceAxis* axis) {
        childAxes.append(axis);
    }
    void RemoveChildAxis(DeviceAxis* axis) {
        if (childAxes.size())
            childAxes.removeOne(axis);
    }

    void CheckAxesStatus();
    void CheckReferenceStatus();

signals:
    //! emituje se pokud vsechny motory stoji
    void AllAxesStoped();
    //! emituje se pokud jsou vsechny motory referencovany
    void AllAxesReferenced();

    void logMessage(LIBS::messageType mType, QString str);

protected:
    DevicePort* port;
    Config config;

    QList<DeviceAxis*> childAxes;
};

//!  Trida kontroleru krokovych motoru.
/*!
 * \ingroup hardware
 */
class MotorController : public DeviceController {
    Q_OBJECT

public:
    MotorController(Config _config, QObject* parent = nullptr) : DeviceController(_config, parent) {
    }
    ~MotorController() {
    }
};

//!  Trida osy krokoveho motoru.
/*!
 * \ingroup hardware
 */
class MotorAxis : public DeviceAxis {
    Q_OBJECT
public:
    MotorAxis(unsigned char _axisIndex, MotorController* _driver, QObject* parent = nullptr)
        : DeviceAxis(_axisIndex, _driver, parent) {
    }
    ~MotorAxis() {
    }
};

#endif
