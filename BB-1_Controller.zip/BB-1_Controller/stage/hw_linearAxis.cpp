#include "hw_linearAxis.h"

LinearAxis::LinearAxis(unsigned char _motorIndex, TrinamicController* _driver, QObject* parent)
    : TMCM610Motor(_motorIndex, _driver, parent) {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    referenceSwitchOffset = settings.value(tmp + "switchOffset", 3).toDouble();
    startPosition         = settings.value(tmp + "startPositionMm", 5).toDouble();
    stopPosition          = settings.value(tmp + "stopPositionMm", -5).toDouble();
    gearRatio             = settings.value(tmp + "gearRatio", 1).toDouble();
    boltMmPerRot          = settings.value(tmp + "boltMmPerRot", 0.5).toDouble();

    lastPosition        = 0;
    escaped             = false;
    escapePosition      = stopPosition;
    realPosition        = 0;
    lastPositionChanged = false;
}

LinearAxis::~LinearAxis() {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    settings.setValue(tmp + "switchOffset", referenceSwitchOffset);
    settings.setValue(tmp + "startPositionMm", startPosition);
    settings.setValue(tmp + "stopPositionMm", stopPosition);
    settings.setValue(tmp + "gearRatio", gearRatio);
    settings.setValue(tmp + "boltMmPerRot", boltMmPerRot);
}

void LinearAxis::SetupConfigGui(QWidget* _toSet) {
    TMCM610Motor::SetupConfigGui(_toSet);

    QGroupBox* groupBox;
    QGridLayout* gridLayout;
    QLabel* label;
    QDoubleSpinBox* doubleSpinBox;
    // QSpinBox *spinBox;

    groupBox = new QGroupBox(_toSet);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    groupBox->setTitle(QApplication::translate("groupBox", "axis settings", 0));

    gridLayout = new QGridLayout(groupBox);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "reference offset", 0));

    gridLayout->addWidget(label, 0, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxRefOffset"));
    doubleSpinBox->setMaximum(100);
    doubleSpinBox->setMinimum(-100);
    doubleSpinBox->setValue(referenceSwitchOffset);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetReferenceSwitchOffset(double)));
    connect(this, SIGNAL(ReferenceSwitchOffsetChanged(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 0, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "gear ratio", 0));

    gridLayout->addWidget(label, 1, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxGearRatio"));
    doubleSpinBox->setMaximum(1000);
    doubleSpinBox->setValue(gearRatio);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", ":1", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetGearRatio(double)));

    gridLayout->addWidget(doubleSpinBox, 1, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "thread pitch", 0));

    gridLayout->addWidget(label, 2, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxBolt"));
    doubleSpinBox->setMaximum(1000);
    doubleSpinBox->setValue(boltMmPerRot);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetBoltMmPerRot(double)));

    gridLayout->addWidget(doubleSpinBox, 2, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "upper limit", 0));

    gridLayout->addWidget(label, 3, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxStart"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(startPosition);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetStartPosition(double)));

    gridLayout->addWidget(doubleSpinBox, 3, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "lower limit", 0));

    gridLayout->addWidget(label, 4, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxStop"));
    doubleSpinBox->setMaximum(200);
    doubleSpinBox->setMinimum(-200);
    doubleSpinBox->setValue(stopPosition);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(SetStopPosition(double)));

    gridLayout->addWidget(doubleSpinBox, 4, 1, 1, 1);

    ui.verticalLayout->addWidget(groupBox);

    groupBox = new QGroupBox(_toSet);
    groupBox->setObjectName(QString::fromUtf8("groupBox_calib"));
    groupBox->setTitle(QApplication::translate("groupBox_calib", "calibration control", 0));

    gridLayout = new QGridLayout(groupBox);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout_calib"));

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "target position", 0));
    gridLayout->addWidget(label, 1, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBoxTargetPos"));
    doubleSpinBox->setMaximum(this->StartPosition());
    doubleSpinBox->setMinimum(this->StopPosition());
    doubleSpinBox->setValue(this->GetRealPosition());
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);
    doubleSpinBox->setKeyboardTracking(false);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox:focus{color:red;}"));

    connect(doubleSpinBox, SIGNAL(valueChanged(double)), SLOT(MoveToPosition(double)));

    gridLayout->addWidget(doubleSpinBox, 1, 1, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "relative movement", 0));
    gridLayout->addWidget(label, 2, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinRelativePos"));
    doubleSpinBox->setMaximum(5.0);
    doubleSpinBox->setMinimum(-5.0);
    doubleSpinBox->setValue(0);
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox:focus{color:red;}"));
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    gridLayout->addWidget(doubleSpinBox, 2, 1, 1, 1);

    QDoubleSpinBox* relSpinBox = doubleSpinBox;

    QPushButton* button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("relativePlus"));
    button->setText(QString(""));
    button->setIcon(QIcon(":/list-add.png"));

    connect(button, &QPushButton::clicked, [=](bool enable) {
        Q_UNUSED(enable) QMetaObject::invokeMethod(this, "MoveRelative", Q_ARG(double, relSpinBox->value()));
    });
    gridLayout->addWidget(button, 2, 3, 1, 1);

    button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("relativeMinus"));
    button->setText(QString(""));
    button->setIcon(QIcon(":/list-remove.png"));

    connect(button, &QPushButton::clicked, [=](bool enable) {
        Q_UNUSED(enable) QMetaObject::invokeMethod(this, "MoveRelative", Q_ARG(double, -relSpinBox->value()));
    });

    gridLayout->addWidget(button, 2, 2, 1, 1);

    label = new QLabel(groupBox);
    label->setObjectName(QString::fromUtf8("label"));
    label->setText(QApplication::translate("groupBox", "current position", 0));
    gridLayout->addWidget(label, 3, 0, 1, 1);

    doubleSpinBox = new QDoubleSpinBox(groupBox);
    doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinCurrentPos"));
    doubleSpinBox->setMaximum(this->StartPosition());
    doubleSpinBox->setMinimum(this->StopPosition());
    doubleSpinBox->setValue(this->GetRealPosition());
    doubleSpinBox->setReadOnly(true);
    doubleSpinBox->setDecimals(3);
    doubleSpinBox->setButtonSymbols(QDoubleSpinBox::NoButtons);
    doubleSpinBox->setStyleSheet(QString("QDoubleSpinBox{background-color:#f0f0f0;}"));
    doubleSpinBox->setFrame(false);
    doubleSpinBox->setSuffix(QApplication::translate("groupBox", " mm", 0));
    doubleSpinBox->setLocale(QLocale::English);

    connect(this, SIGNAL(RealPosition(double)), doubleSpinBox, SLOT(setValue(double)));

    gridLayout->addWidget(doubleSpinBox, 3, 1, 1, 1);

    button = new QPushButton(groupBox);
    button->setObjectName(QString::fromUtf8("doubleSpinBoxStop"));
    button->setText(QApplication::translate("groupBox", "Tare", 0));
    button->setIcon(QIcon(":/applications-accessories.png"));

    connect(button, SIGNAL(clicked()), this, SLOT(TareReferenceSwitchOffset()));

    gridLayout->addWidget(button, 3, 2, 1, 2);
    gridLayout->setColumnStretch(0, 1);

    ui.verticalLayout->addWidget(groupBox);
    ui.verticalLayout->addSpacerItem(new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding));

    emit LimitsChanged(stopPosition, startPosition);
}

void LinearAxis::MoveToPosition(double _posMm) {
    int microsteps = DesignedPositionToUSteps(_posMm);

    int start = DesignedPositionToUSteps(startPosition);
    int stop  = DesignedPositionToUSteps(stopPosition);

    if (microsteps >= stop && microsteps <= start) {
        escaped = false;
        /*        LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
                LARGE_INTEGER Frequency;
                QueryPerformanceFrequency(&Frequency);
                QueryPerformanceCounter(&StartingTime);
        */

        TMCM610Motor::MoveToPosition(MVP_ABS, microsteps);

        /*
                QueryPerformanceCounter(&EndingTime);
                ElapsedMicroseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
                ElapsedMicroseconds.QuadPart *= 1000000;
                ElapsedMicroseconds.QuadPart /= Frequency.QuadPart;
                qDebug() << "Query time in microseconds MoveToPosition motor #"<< this->axisIndex <<": " <<
           ElapsedMicroseconds.QuadPart;*/
    } else {
        TMCM610Motor::MotorStop();
    }
}

void LinearAxis::RotateRight(int _velocity) {
    // int start = pocet_mikrokroku_na_mm * startPosition + offset - 2 * GetUstepsToStop(_velocity);
    int stop = UStepsPerMM() * stopPosition + UStepsOffset() + 2 * UStepsToStop(_velocity);

    // if(microsteps <= start && CurrentPosition() >= stop)
    if (CurrentPosition() >= stop) {
        escaped = false;
        TMCM610Motor::RotateRight(_velocity);
    } else
        MoveToPosition(stopPosition);
}

void LinearAxis::RotateLeft(int _velocity) {
    int start = UStepsPerMM() * startPosition + UStepsOffset() - 2 * UStepsToStop(_velocity);
    // int stop  = pocet_mikrokroku_na_mm * stopPosition + offset + 2 * GetUstepsToStop(_velocity);

    if (CurrentPosition() <= start) //&& CurrentPosition() >= stop)
    {
        escaped = false;
        TMCM610Motor::RotateLeft(_velocity);
    } else
        MoveToPosition(startPosition);
}

bool LinearAxis::IsInLimits(double _posMm) {
    int uSteps    = UStepsPerMM();
    int uStepsPos = uSteps * _posMm;
    int start     = uSteps * startPosition;
    int stop      = uSteps * stopPosition;

    return (uStepsPos >= stop && uStepsPos <= start);
}

void LinearAxis::Escape() {
    if (!escaped)
        lastPosition = CurrentPosition();

    MoveToPosition(escapePosition);
    escaped = true;
}

void LinearAxis::SetFocusPosition(double _value_mm) {
    int newpos = (_value_mm * UStepsPerMM()) + UStepsOffset();

    if (newpos != lastPosition) {
        lastPosition        = newpos;
        lastPositionChanged = true;
    }
}

void LinearAxis::ReFocus() {
    if (escaped || lastPositionChanged) {
        TMCM610Motor::MoveToPosition(MVP_ABS, lastPosition);
        escaped             = false;
        lastPositionChanged = false;
    }
}

void LinearAxis::saveSettings() {
    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    settings.setValue(tmp + "switchOffset", referenceSwitchOffset);
    settings.setValue(tmp + "startPositionMm", startPosition);
    settings.setValue(tmp + "stopPositionMm", stopPosition);
    settings.setValue(tmp + "gearRatio", gearRatio);
    settings.setValue(tmp + "boltMmPerRot", boltMmPerRot);
}

void LinearAxis::receiveMovement(double d) {
    const int minMovement = 50;
    const int maxMovement = 2000;
    if (!referenceSearch && isReferenced) {
        if (std::abs(d) < 0.0001) {
            if (IsMoving())
                MotorStop();
            return;
        }

        int speed = minMovement + std::abs(d * (maxMovement - minMovement));
        maxSpeed  = speed;
        SetAxisParameter(MAX_SPEED, speed);
        SetMaxSpeed(speed);

        double distance = qMin(10.0, std::abs(GetRealPosition() - (d > 0 ? StopPosition() : StartPosition())));
        MoveRelative(std::copysign(distance, d));
        //        fprintf(stderr,"LinearAxis::receiveMovement() at %d",QDateTime::currentMSecsSinceEpoch());
        //        qDebug() << QString("LinearAxis::receiveMovement() at %1").arg(QDateTime::currentMSecsSinceEpoch());
    } else {
        emit logMessage(LIBS::Warning, QString("Unable to handle joystick movement due to calibration, ignoring."));
    }
    // qDebug() << "Speed is " << speed << " d(" << std::copysign(10, d) << ")";
}
