#ifndef LINEARAXIS_H
#define LINEARAXIS_H

#include "hw_trinamic.h"

//!  Obecna linearni osa.
/*!
 * \ingroup hardware
 */
class LinearAxis : public TMCM610Motor {
    Q_OBJECT

public:
    LinearAxis(unsigned char _motorIndex, TrinamicController* _driver, QObject* parent = nullptr);
    ~LinearAxis();

    //! pocatecni souradnice osy = limitni souradnice
    double StartPosition() {
        return startPosition;
    }
    //! koncova souradnice osy = limitni souradnice
    double StopPosition() {
        return stopPosition;
    }
    //! offset referencniho spinace = pokud je 0 pak na referenci je pocatek SS
    double ReferenceSwitchOffset() {
        return referenceSwitchOffset;
    }
    //! prevodovy pomer - prevod sroub motor
    double GearRatio() {
        return gearRatio;
    }
    //! stoupani vodiciho sroubu posuvu
    double BoltMmPerRot() {
        return boltMmPerRot;
    }
    //! aktualni souradnice
    double GetRealPosition() {
        return realPosition;
    }
    //! nastaveni bezpecne polohy osy
    void SetEscapePosition(double _value_mm) {
        escapePosition = _value_mm;
    }
    //! nastaveni pracovni polohy osy
    void SetFocusPosition(double _value_mm);
    //! aktualni pracovni popoha = je vzdy posledni poloha ve ktere byla osa
    double FocusPosition() {
        return (lastPosition - UStepsOffset()) / UStepsPerMM();
    }
    //! otestuje hodnotu jestli je v mezich posuvu = tru - OK
    bool IsInLimits(double _posMm);
    //! true = osa je v bezpecne poloze
    bool IsEscaped() {
        return escaped;
    }
    //!  MmSpeedFactor() * velocity = speed in real units mm per Second
    double MmSpeedFactor() {
        return RotationFactor() * boltMmPerRot / gearRatio;
    }
    //! pocet uSteps na mm
    double UStepsPerMM() {
        return UStepsPerRot() * gearRatio / boltMmPerRot;
    }
    //! offset v uStepech
    double UStepsOffset() {
        return UStepsPerMM() * referenceSwitchOffset;
    }
    //! naplni widget _toSet pro nastavovani parametru motoru, pro kazdy motor je treba novy widget, pouzivame tabwidget
    virtual void SetupConfigGui(QWidget* _toSet);
    //! prevod hodnoty _value v mm na uSteps
    virtual int DesignedPositionToUSteps(double _value) {
        return UStepsPerMM() * _value + UStepsOffset();
    }

signals:
    //! emise pri zmene polohy motoru
    void RealPosition(double _mm);
    //! emise pri zmene polohy motoru
    void RealPosition(QString mm);

    //! emise pri zmene limitu osy
    void LimitsChanged(double _mim, double _max);

    void startPositionChanged(double pos);
    void stopPositionChanged(double pos);
    void ReferenceSwitchOffsetChanged(double ref);

public slots:
    void SetStartPosition(double _value) {
        startPosition = _value;
        emit LimitsChanged(stopPosition, startPosition);
        emit startPositionChanged(startPosition);
    }
    void SetStopPosition(double _value) {
        stopPosition = _value;
        emit LimitsChanged(stopPosition, startPosition);
        emit stopPositionChanged(stopPosition);
    }
    virtual void SetReferenceSwitchOffset(double _value) {
        referenceSwitchOffset = _value;
        emit ReferenceSwitchOffsetChanged(referenceSwitchOffset);
        this->CalculateRealPosition();
    }
    void SetGearRatio(double _value) {
        gearRatio = _value;
    }
    void SetBoltMmPerRot(double _value) {
        boltMmPerRot = _value;
    }

    void MoveToPosition(double _posMm);
    void MoveRelative(double _deltaMm) {
        MoveToPosition(realPosition + _deltaMm);
    }
    void receiveMovement(double); // receives directly from joystick <-1,1>

    void Escape();
    void ReFocus();

    void RotateRight(int _velocity);
    void RotateLeft(int _velocity);

    void CalculateRealPosition() {
        realPosition = (CurrentPosition() - UStepsOffset()) / UStepsPerMM();
        emit RealPosition(realPosition);
        emit RealPosition(QString("%1").arg(realPosition, 5, 'f', 3));
    }

    virtual void TareReferenceSwitchOffset() {
        LinearAxis::SetReferenceSwitchOffset(this->ReferenceSwitchOffset() + this->GetRealPosition());
    }
    virtual void saveSettings();

private:
    double referenceSwitchOffset;
    double startPosition, stopPosition;
    //! hodnota posuvu v mm
    double realPosition;
    //! prevod od motoru ke sroubu
    double gearRatio;
    //! stoupani sroubu
    double boltMmPerRot;

    //! posledni poloha pred provedenim escape - pro escape, refocus v uSteps
    int lastPosition;
    //! nastavit na true, pokud byla poloha maualne upravena a ma se provest refocus
    bool lastPositionChanged;
    //! escape poloha v mm
    double escapePosition;
    //! true pokud jsme v escape pozici
    bool escaped;
};

#endif // LINEARAXIS_H
