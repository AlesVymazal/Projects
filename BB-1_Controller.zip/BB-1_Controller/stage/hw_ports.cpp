#include "hw_ports.h"

QMutex commMutex; // Mutex pro komunikaci

PortSelectDialog::PortSelectDialog(QWidget* parent, Qt::WindowFlags flags) : QDialog(parent, flags) {

    setObjectName(QString::fromUtf8("Port_Selector"));
    resize(301, 223);
    verticalLayout = new QVBoxLayout(this);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    listWidget = new QListWidget(this);
    listWidget->setObjectName(QString::fromUtf8("listWidget"));

    verticalLayout->addWidget(listWidget);

    hboxLayout = new QHBoxLayout();
    hboxLayout->setContentsMargins(0, 0, 0, 0);
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    spacerItem = new QSpacerItem(131, 31, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout->addItem(spacerItem);

    okButton = new QPushButton(this);
    okButton->setObjectName(QString::fromUtf8("okButton"));
    okButton->setDisabled(true);

    hboxLayout->addWidget(okButton);

    cancelButton = new QPushButton(this);
    cancelButton->setObjectName(QString::fromUtf8("cancelButton"));

    hboxLayout->addWidget(cancelButton);

    verticalLayout->addLayout(hboxLayout);

    setWindowTitle(QApplication::translate("Port_Selector", "Port select dialog", nullptr));
    okButton->setText(QApplication::translate("Port_Selector", "OK", nullptr));
    cancelButton->setText(QApplication::translate("Port_Selector", "Cancel", nullptr));

    QObject::connect(okButton, SIGNAL(clicked()), this, SLOT(accept()));
    QObject::connect(cancelButton, SIGNAL(clicked()), this, SLOT(reject()));

    QMetaObject::connectSlotsByName(this);
}

PortSelectDialog::~PortSelectDialog() {
}

void PortSelectDialog::accept() {
    okButton->setDisabled(true);
    this->hide();
}

void PortSelectDialog::reject() {
    this->hide();
}

FTDIPortSelectDialog::FTDIPortSelectDialog(QWidget* parent, Qt::WindowFlags flags) : PortSelectDialog(parent, flags) {
}

void FTDIPortSelectDialog::SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO> _DevInfoList) {
    SerianNumbers.clear();
    for (int i = 0; i < _DevInfoList.size(); ++i) {
        listWidget->addItem(QString("%1 %2 %3 %4")
                                .arg(QString::number(i),
                                     _DevInfoList[i].Description,
                                     _DevInfoList[i].SerialNumber,
                                     QString::number(_DevInfoList[i].ChipID)));
        SerianNumbers.append(_DevInfoList[i].SerialNumber);
    }
}

void FTDIPortSelectDialog::accept() {
    PortSelectDialog::accept();

    if (listWidget->selectionModel()->hasSelection()) {
        SelectedSN = SerianNumbers.at(listWidget->selectionModel()->selectedRows().at(0).row()).toLatin1();
        emit NewPortSelected(SelectedSN);
    }
}

//* FTDI serial port implementation *//

FTDIinterface::FTDIinterface(QObject* parent) : DevicePort(parent) {
    cfgd     = NULL;
    ftHandle = NULL;
    ftStatus = FT_OK;
    numDevs  = 0;
    rx_packet.clear();
    TimeOutFlag = false;
    initialized = false;

    SerialNumber[0] = 0;
    Description[0]  = 0;

    SN.clear();
    descriptor.clear();

    qRegisterMetaType<QVector<MY_FT_DEVICE_LIST_INFO>>("QVector<MY_FT_DEVICE_LIST_INFO>");

    readTimeout  = 100;
    writeTimeout = 100;
    baudRate     = 115200;
    wordLength   = FT_BITS_8;
    stopBits     = FT_STOP_BITS_1;
    parity       = FT_PARITY_NONE;
}

PortSelectDialog* FTDIinterface::CreatePortSelectDlg(QWidget* parent) {
    if (!cfgd) {
        cfgd = new FTDIPortSelectDialog(parent);
        SetPortDialog(cfgd);

        connect(this,
                SIGNAL(FillDialog(QVector<MY_FT_DEVICE_LIST_INFO>)),
                cfgd,
                SLOT(SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO>)));
        connect(cfgd, SIGNAL(NewPortSelected(QByteArray)), this, SLOT(CloseDevice()));
        connect(cfgd, SIGNAL(NewPortSelected(QByteArray)), this, SLOT(OpenDeviceSN(QByteArray)));
    }

    return cfgd;
}

void FTDIinterface::FillSelectDialog() {
    CheckForDevices(true);
    emit FillDialog(DevInfoList());
    // cfgd->SetFTDIList(DevInfoList());
}

FT_STATUS FTDIinterface::CheckForDevices(bool internally) {
    QMutexLocker guard(&commMutex);

    if (DevInfoList().size() && !internally) {
        // qDebug() << "information - FTDI detection skipped";
        // emit GetDeviceList(DevInfoList());
        return ftStatus;
    }
    // qDebug() << "information - FTDI detecting";

    ftStatus = FT_CreateDeviceInfoList(&numDevs);
    if (ftStatus != FT_OK) {
        qWarning() << "No devices detected: " << Error(ftStatus);
        emit logMessage(LIBS::Warning, QString("FTDIinterface: No devices detected: %1").arg(Error(ftStatus)));
        return ftStatus;
    }

    QVector<FT_DEVICE_LIST_INFO_NODE> DInf;

    DInf.resize(numDevs);
    DevInfoList().resize(numDevs);
    ftStatus = FT_GetDeviceInfoList(DInf.data(), &numDevs);
    for (int i = 0; i < DevInfoList().size(); ++i) {
        memcpy(&DevInfoList()[i], &DInf[i], sizeof(DInf[0]));

        if (DevInfoList()[i].ftHandle) {
            if (FTID_GetChipIDFromHandle(DevInfoList()[i].ftHandle, &DevInfoList()[i].ChipID))
                DevInfoList()[i].ChipID = 0;
        } else {
            if (FTID_GetDeviceChipID(i, &DevInfoList()[i].ChipID))
                DevInfoList()[i].ChipID = 0;
        }

        //        qDebug() << "chip Id: " << DevInfoList()[i].SerialNumber << DevInfoList()[i].ChipID
        //                 << DevInfoList()[i].Description;
    }

    if (ftStatus != FT_OK) {
        qWarning() << "Devices info error:" << Error(ftStatus);
        emit logMessage(LIBS::Warning, QString("FTDIinterface: Devices info error: %1").arg(Error(ftStatus)));
        return ftStatus;
    }
    // emit GetDeviceList(DevInfoList());
    // qDebug() << QString("Number of detected devices is %1").arg(QString::number(numDevs));

    return ftStatus;
}

FT_STATUS FTDIinterface::OpenDevice() {
    if (SN.size())
        return OpenDeviceSN(SN);

    if (descriptor.size())
        return OpenDevice(descriptor);

    qWarning() << "FTDI open error";
    emit logMessage(LIBS::Warning, QString("FTDIinterface: FTDI open error."));

    return FT_INVALID_PARAMETER;
}

FT_STATUS FTDIinterface::OpenDevice(QByteArray arg, DWORD flangs) {
    if (!initialized) {
        if (CheckForDevices(false) == FT_OK) {
            {
                QMutexLocker guard(&commMutex);
                ftStatus = FT_OpenEx(arg.data(), flangs, &ftHandle);
            }
            if (ftStatus != FT_OK) {
                qWarning() << arg << "open failed " << Error(ftStatus);
                emit logMessage(LIBS::Warning, QString("FTDIinterface: Open failed: %1").arg(Error(ftStatus)));
                emit PortDescriptorChanged("Open failed");
                return ftStatus;
            }

            ftStatus = FT_GetDeviceInfo(ftHandle, &ftDevice, &deviceID, SerialNumber, Description, NULL);

            // emit GetStatus(QString("Device %1\nID %2\nSN %3\nDescriptor %4\n").arg(QString::number(ftDevice),
            // QString::number(deviceID), QString(SerialNumber), QString(Description)));
            //            qDebug() << QString("Device %1\nID %2\nSN %3\nDescriptor %4\n")
            //                            .arg(QString::number(ftDevice),
            //                                 QString::number(deviceID),
            //                                 QString(SerialNumber),
            //                                 QString(Description));
        }
        initialized = (ftStatus == FT_OK);

        if (initialized) {
            SetBaudRate(baudRate);
            SetDataCharacteristics(wordLength, stopBits, parity);
            SetTimeouts(readTimeout, writeTimeout);
            //            FT_SetDeadmanTimeout(ftHandle,5);
            emit PortDescriptorChanged(QString("%1 SN: %2").arg(QString(Description), QString(SerialNumber)));

            AfterInitialization();
        }
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::OpenDevice(QByteArray _descriptor) {
    descriptor = _descriptor;
    return OpenDevice(_descriptor, FT_OPEN_BY_DESCRIPTION);
}

FT_STATUS FTDIinterface::OpenDeviceSN(QByteArray _SN) {
    SN = _SN;
    return OpenDevice(_SN, FT_OPEN_BY_SERIAL_NUMBER);
}

unsigned long FTDIinterface::SN2ChipID(QByteArray _SN) {
    if (!initialized && !DevInfoList().size())
        CheckForDevices();

    foreach (MY_FT_DEVICE_LIST_INFO tmp, DevInfoList())
        if (QString(tmp.SerialNumber) == QString(_SN))
            return tmp.ChipID;

    return 0;
}

unsigned long FTDIinterface::Descriptor2ChipID(QByteArray _descriptor) {
    if (!initialized && !DevInfoList().size())
        CheckForDevices();

    foreach (MY_FT_DEVICE_LIST_INFO tmp, DevInfoList())
        if (QString(tmp.Description) == QString(_descriptor))
            return tmp.ChipID;

    return 0;
}

QByteArray FTDIinterface::ChipID2SN(unsigned long ChipID) {
    if (!initialized && !DevInfoList().size())
        CheckForDevices();

    foreach (MY_FT_DEVICE_LIST_INFO tmp, DevInfoList())
        if (tmp.ChipID == ChipID)
            return tmp.SerialNumber;

    qWarning() << "Serial number from ChipID not found";
    emit logMessage(LIBS::Warning, QString("FTDIinterface: Serial number from ChipID not found."));

    return "";
}

QByteArray FTDIinterface::ChipID2Descriptor(unsigned long ChipID) {
    if (!initialized && !DevInfoList().size())
        CheckForDevices();

    foreach (MY_FT_DEVICE_LIST_INFO tmp, DevInfoList())
        if (tmp.ChipID == ChipID)
            return tmp.Description;

    qWarning() << "Descriptor from ChipID not found";
    emit logMessage(LIBS::Warning, QString("FTDIinterface: Descriptor from ChipID not found"));
    return "";
}

FT_STATUS FTDIinterface::CloseDevice() {
    if (initialized) {
        ftStatus    = FT_Close(ftHandle);
        ftHandle    = NULL;
        initialized = false;
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::SetTimeouts(unsigned long _ReadTimeout, unsigned long _WriteTimeout) {
    readTimeout  = _ReadTimeout;
    writeTimeout = _WriteTimeout;

    if (initialized) {
        ftStatus = FT_SetTimeouts(ftHandle, 100, 100);
        if (ftStatus != FT_OK) {
            qWarning() << "Set timeouts error:" << Error(ftStatus);
            emit logMessage(LIBS::Warning, QString("FTDIinterface: Set timeouts failed: %1.").arg(Error(ftStatus)));
        }
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::SetBaudRate(unsigned long _BaudRate) {
    baudRate = _BaudRate;
    if (initialized) {
        ftStatus = FT_SetBaudRate(ftHandle, baudRate);
        if (ftStatus != FT_OK) {
            qWarning() << "Set baudrate error: " << Error(ftStatus);
            emit logMessage(LIBS::Warning, QString("FTDIinterface: Set baudrate error: %1.").arg(Error(ftStatus)));
        }
        QSettings settings;
        settings.setValue("private/ftdiPort/BaudRate", (long)_BaudRate);
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::SetDataCharacteristics(unsigned char _WordLength,
                                                unsigned char _StopBits,
                                                unsigned char _Parity) {
    wordLength = _WordLength;
    stopBits   = _StopBits;
    parity     = _Parity;

    if (initialized) {
        ftStatus = FT_SetDataCharacteristics(ftHandle, FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
        if (ftStatus != FT_OK) {
            qWarning() << "Set data characteristic error:" << Error(ftStatus);
            emit logMessage(LIBS::Warning,
                            QString("FTDIinterface: Set data characteristics failed: %1.").arg(Error(ftStatus)));
        }
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::TxPacket(QByteArray _packet) {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "FTDI port not initialised";
        emit logMessage(LIBS::Error, QString("FTDIinterface: FTDI port not initialized."));
        return FT_DEVICE_NOT_OPENED;
    }
    ftStatus = FT_Purge(ftHandle, FT_PURGE_TX | FT_PURGE_RX); // Purge both Rx and Tx buffers
    emit logMessage(LIBS::Debug, QString("Writing ... mutex successuflly locked"));
    unsigned long written;
    ftStatus = FT_Write(ftHandle, _packet.data(), _packet.size(), &written);

    //    qDebug() << "Written "  << written << " bytes" << _packet;
    if (ftStatus != FT_OK) {
        qCritical() << "Transmit data error:" << Error(ftStatus);
        emit logMessage(LIBS::Error, QString("FTDIinterface: Transmit data error: %1.").arg(Error(ftStatus)));
    }
    return ftStatus;
}

FT_STATUS FTDIinterface::RxByte() {
    if (!initialized) {
        qCritical() << "FTDI port not initialised";
        emit logMessage(LIBS::Error, QString("FTDIinterface: FTDI port not initialized."));
        return FT_DEVICE_NOT_OPENED;
    }

    TimeOutFlag = false;
    unsigned long read_bytes;

    ftStatus = FT_Read(ftHandle, &rx_byte, 1, &read_bytes);
    if (ftStatus != FT_OK) {
        qCritical() << "Receive data error:" << Error(ftStatus);
        emit logMessage(LIBS::Error, QString("FTDIinterface: Receive data error: %1.").arg(Error(ftStatus)));
    }

    if (!read_bytes) {
        qCritical() << "Rx byte timeout";
        emit logMessage(LIBS::Error, QString("FTDIinterface: RX byte timeout: %1.").arg(Error(ftStatus)));
        TimeOutFlag = true;
        ftStatus    = FT_IO_ERROR;
    }

    return ftStatus;
}

FT_STATUS FTDIinterface::RxPacket() {
    QMutexLocker guard(&commMutex);

    if (!initialized) {
        qCritical() << "FTDI port not initialised";
        emit logMessage(LIBS::Error, QString("FTDIinterface: FTDI port not initialized."));
        return FT_DEVICE_NOT_OPENED;
    }

    unsigned long read_bytes, bytes_to_read;
    ftStatus = FT_GetQueueStatus(ftHandle, &bytes_to_read);
    if (ftStatus != FT_OK) {
        qCritical() << "Queue status error:" << Error(ftStatus);
        emit logMessage(LIBS::Error, QString("FTDIinterface: Queue status error: %1.").arg(Error(ftStatus)));
        return ftStatus;
    }

    if (bytes_to_read > 0) {
        QByteArray buffer(bytes_to_read, 32);

        ftStatus = FT_Read(ftHandle, buffer.data(), bytes_to_read, &read_bytes);
        if (ftStatus != FT_OK) {
            qCritical() << "Receive data error:" << Error(ftStatus);
            emit logMessage(LIBS::Error, QString("FTDIinterface: Receive data error: %1.").arg(Error(ftStatus)));
        }

        rx_packet = buffer;
    } else
        rx_packet.clear();

    emit DevicePort::PacketReceived(rx_packet);
    return ftStatus;
}

FT_STATUS FTDIinterface::RxPacketLength(int wait_for_number_of_bytes) {
    QMutexLocker guard(&commMutex);
    FT_STATUS _ftStatus = FT_IO_ERROR;
    if (!initialized) {
        qCritical() << "FTDI port not initialised";
        emit logMessage(LIBS::Error, QString("FTDIinterface: FTDI port not initialized."));
        return FT_DEVICE_NOT_OPENED;
    }

    TimeOutFlag = false;
    unsigned long read_bytes, bytes_to_read = wait_for_number_of_bytes;
    QByteArray buffer(bytes_to_read, 0);

    _ftStatus = FT_Read(ftHandle, buffer.data(), bytes_to_read, &read_bytes);
    if (_ftStatus != FT_OK) {
        qCritical() << "Receive data error:" << Error(_ftStatus);
        emit logMessage(LIBS::Error, QString("FTDIinterface: Receive data error: %1.").arg(Error(_ftStatus)));
    }

    if (bytes_to_read != read_bytes) {
        // buffer.resize(read_bytes);
        qCritical() << QString("RX %1 bytes timeout %2 ").arg(wait_for_number_of_bytes).arg(read_bytes);
        emit logMessage(LIBS::Error, QString("FTDIinterface: RX %1 bytes timeout.").arg(wait_for_number_of_bytes));
        TimeOutFlag = true;
        _ftStatus   = FT_IO_ERROR;
        //        emit logMessage(LIBS::Debug,QString("FTDIinterface: trying to restart port."));
        //        this->CloseDevice();
        //        this->OpenDevice();
    }

    rx_packet = buffer;
    emit DevicePort::PacketReceived(buffer);
    //    FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX); // Purge both Rx and Tx buffers
    ftStatus = _ftStatus;
    return _ftStatus;
}

FT_STATUS FTDIinterface::RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character) {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "FTDI port not initialised";
        emit logMessage(LIBS::Error, QString("FTDIinterface: FTDI port not initialized."));
        return FT_DEVICE_NOT_OPENED;
    }

    rx_packet.clear();
    do {
        ftStatus = RxByte();
        rx_packet.append(rx_byte);
    } while (rx_byte != wait_for_last_character && ftStatus == FT_OK && !TimeOutFlag);

    if (!retrieve_last_character)
        rx_packet.remove(rx_packet.size() - 1, 1);

    return ftStatus;
}

QString FTDIinterface::Error(FT_STATUS error) {
    switch (error) {
        case FT_OK:
            return "FT_OK";
        case FT_INVALID_HANDLE:
            return "FT_INVALID_HANDLE";
        case FT_DEVICE_NOT_FOUND:
            return "FT_DEVICE_NOT_FOUND";
        case FT_DEVICE_NOT_OPENED:
            return "FT_DEVICE_NOT_OPENED";
        case FT_IO_ERROR:
            return "FT_IO_ERROR";
        case FT_INSUFFICIENT_RESOURCES:
            return "FT_INSUFFICIENT_RESOURCES";
        case FT_INVALID_PARAMETER:
            return "FT_INVALID_PARAMETER";
        case FT_INVALID_BAUD_RATE:
            return "FT_INVALID_BAUD_RATE";
        case FT_DEVICE_NOT_OPENED_FOR_ERASE:
            return "FT_DEVICE_NOT_OPENED_FOR_ERASE";
        case FT_DEVICE_NOT_OPENED_FOR_WRITE:
            return "FT_DEVICE_NOT_OPENED_FOR_WRITE";
        case FT_FAILED_TO_WRITE_DEVICE:
            return "FT_FAILED_TO_WRITE_DEVICE";
        case FT_EEPROM_READ_FAILED:
            return "FT_EEPROM_READ_FAILED";
        case FT_EEPROM_WRITE_FAILED:
            return "FT_EEPROM_WRITE_FAILED";
        case FT_EEPROM_ERASE_FAILED:
            return "FT_EEPROM_ERASE_FAILED";
        case FT_EEPROM_NOT_PRESENT:
            return "FT_EEPROM_NOT_PRESENT";
        case FT_EEPROM_NOT_PROGRAMMED:
            return "FT_EEPROM_NOT_PROGRAMMED";
        case FT_INVALID_ARGS:
            return "FT_INVALID_ARGS";
        case FT_NOT_SUPPORTED:
            return "FT_NOT_SUPPORTED";
        case FT_DEVICE_LIST_NOT_READY:
            return "FT_DEVICE_LIST_NOT_READY";
        default:
        case FT_OTHER_ERROR:
            return "FT_OTHER_ERROR";
    }
}

///////*************** com port ***********/////

ComPortSelectDialog::ComPortSelectDialog(QWidget* parent, Qt::WindowFlags flags) : PortSelectDialog(parent, flags) {
}

void ComPortSelectDialog::SetComList(QStringList _ports, QStringList _descriptors) {
    ports       = _ports;
    descriptors = _descriptors;

    for (int i = 0; i < ports.size(); ++i) {
        listWidget->addItem(QString("%1 %2").arg(ports.at(i), descriptors.at(i)));
    }
}

void ComPortSelectDialog::accept() {
    PortSelectDialog::accept();

    if (listWidget->selectionModel()->hasSelection()) {
        selectedPort = ports.at(listWidget->selectionModel()->selectedRows().at(0).row()).toLatin1();
        emit NewPortSelected(selectedPort);
    }
}

PortSelectDialog* SerialPort::CreatePortSelectDlg(QWidget* parent) {
    if (!cfgd) {
        cfgd = new ComPortSelectDialog(parent);
        SetPortDialog(cfgd);

        connect(this, SIGNAL(FillDialog(QStringList, QStringList)), cfgd, SLOT(SetComList(QStringList, QStringList)));
        connect(cfgd, SIGNAL(NewPortSelected(QByteArray)), this, SLOT(CloseDevice()));
        connect(cfgd, SIGNAL(NewPortSelected(QByteArray)), this, SLOT(OpenDevice(QByteArray)));
    }

    return cfgd;
}

void SerialPort::FillSelectDialog() {
    QStringList ports, descriptors;
    QList<QSerialPortInfo> serialPortInfoList = QSerialPortInfo::availablePorts();
    foreach (const QSerialPortInfo& serialPortInfo, serialPortInfoList) {
        // if(!serialPortInfo.manufacturer().contains("FTDI"))
        //	coms.append(QString("%1 %2 %3").arg(serialPortInfo.portName(), serialPortInfo.description(),
        // serialPortInfo.manufacturer()));

        ports.append(serialPortInfo.portName());
        descriptors.append(serialPortInfo.manufacturer());
    }
    emit FillDialog(ports, descriptors);
    // cfgd->SetComList(ports, descriptors);
}

SerialPort::SerialPort(QObject* parent) : DevicePort(parent) {
    rxPacket.clear();
    cfgd         = NULL;
    readTimeout  = 10;
    writeTimeout = 20;

    serial.setParent(this);

    SetBaudRate();
    SetDataCharacteristics();
}

void SerialPort::SetTimeouts(unsigned long _ReadTimeout, unsigned long _WriteTimeout) {
    readTimeout  = _ReadTimeout;
    writeTimeout = _WriteTimeout;
}

void SerialPort::SetBaudRate(unsigned long _BaudRate) {
    serial.setBaudRate(_BaudRate);
}

void SerialPort::SetDataCharacteristics(QSerialPort::DataBits _WordLength,
                                        QSerialPort::StopBits _StopBits,
                                        QSerialPort::Parity _Parity) {
    serial.setDataBits(_WordLength);
    serial.setStopBits(_StopBits);
    serial.setParity(_Parity);
}

FT_STATUS SerialPort::OpenDevice(QByteArray _portName) {
    if (!initialized) {
        portName = _portName;
        serial.setPortName(portName);
        if (serial.open(QIODevice::ReadWrite)) {
            initialized = true;

            serial.clear();

            // qDebug() << "Serial port " << portName << " opened";
            emit PortDescriptorChanged(QString("Serial port %1").arg(QString(portName)));
            AfterInitialization();

            return FT_OK;
        }

        initialized = false;
        qWarning() << "Serial port " << portName << " open error";
        emit logMessage(LIBS::Warning, QString("SerialPort: Serial port %1 open error.").arg(QString(portName)));
        emit PortDescriptorChanged("Open failed");
        return FT_DEVICE_NOT_OPENED;
    }

    return FT_OK;
}

FT_STATUS SerialPort::OpenDevice() {
    if (portName.size())
        return OpenDevice(portName);

    qWarning() << "Serial port open error";
    emit logMessage(LIBS::Warning, QString("SerialPort: Serial port %1 open error.").arg(QString(portName)));
    return FT_DEVICE_NOT_OPENED;
}

FT_STATUS SerialPort::CloseDevice() {
    if (initialized) {
        serial.close();
        initialized = false;
        // qDebug() << "Serial port closed";
    }

    return FT_OK;
}

FT_STATUS SerialPort::TxPacket(QByteArray _packet) {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "Serial port " << portName << " not initialised" << endl;
        emit logMessage(LIBS::Error, QString("SerialPort: Serial port %1 not initialized.").arg(QString(portName)));
        return FT_DEVICE_NOT_OPENED;
    }

    if (serial.write(_packet) == _packet.size()) {
        // serial.waitForBytesWritten(writeTimeout);
        return FT_OK;
    }

    qCritical() << "Serial port write error" << endl;
    emit logMessage(LIBS::Warning, QString("SerialPort: Serial port write error."));
    return FT_FAILED_TO_WRITE_DEVICE;
}

FT_STATUS SerialPort::RxPacket() {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "Serial port " << portName << " not initialised" << endl;
        emit logMessage(LIBS::Error, QString("SerialPort: Serial port %1 not initialized.").arg(QString(portName)));
        return FT_DEVICE_NOT_OPENED;
    }

    serial.waitForReadyRead(readTimeout);
    rxPacket = serial.readAll();
    emit DevicePort::PacketReceived(rxPacket);
    return FT_OK;
}

FT_STATUS SerialPort::RxPacketLength(int wait_for_number_of_bytes) {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "Serial port " << portName << " not initialised" << endl;
        emit logMessage(LIBS::Error, QString("SerialPort: Serial port %1 not initialized.").arg(QString(portName)));
        return FT_DEVICE_NOT_OPENED;
    }

    // unsigned long bytes_to_read = wait_for_number_of_bytes;

    // char ch; //int read_bytes = 0;

    if (serial.waitForReadyRead(readTimeout)) {
        rxPacket = serial.read(wait_for_number_of_bytes);

        if (rxPacket.size() < wait_for_number_of_bytes)
            while (rxPacket.size() < wait_for_number_of_bytes && serial.waitForReadyRead(readTimeout)) {
                rxPacket.append(serial.read(wait_for_number_of_bytes - rxPacket.size()));
            }
    } else {
        qCritical() << "serial port timeout";
        emit logMessage(LIBS::Error, QString("SerialPort: Serial port timeout."));
    }

    bool ok = (rxPacket.size() == wait_for_number_of_bytes);

    if (!ok) {
        qCritical() << "error packet sync error " << rxPacket.size() << " instead of " << wait_for_number_of_bytes
                    << rxPacket.toHex();
        emit logMessage(LIBS::Error,
                        QString("SerialPort: error packet sync (%1 instead of %2 [%3]).")
                            .arg((int)rxPacket.size())
                            .arg((int)wait_for_number_of_bytes)
                            .arg(QString(rxPacket.toHex())));
    }

    return ok ? FT_OK : FT_IO_ERROR;
}

FT_STATUS SerialPort::RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character) {
    QMutexLocker guard(&commMutex);
    if (!initialized) {
        qCritical() << "Serial port " << portName << " not initialised" << endl;
        emit logMessage(LIBS::Error, QString("SerialPort: Serial port %1 not initialized.").arg(QString(portName)));
        return FT_DEVICE_NOT_OPENED;
    }

    char ch;
    int r;
    rxPacket.clear();

    if (serial.waitForReadyRead(readTimeout))
        do {
            do {
                r = serial.read(&ch, 1);

                if (r == 1)
                    rxPacket.append(ch);

                if (r == 0 && ch != wait_for_last_character)
                    serial.waitForReadyRead(readTimeout);
            } while (serial.bytesAvailable() && ch != wait_for_last_character);

        } while (ch != wait_for_last_character && r == 1 && serial.waitForReadyRead(readTimeout));

    if (!retrieve_last_character)
        rxPacket.remove(rxPacket.size() - 1, 1);

    return FT_OK;
}

///////*************** RS485 port ***********/////

RS485PortSelectDialog::RS485PortSelectDialog(QWidget* parent, Qt::WindowFlags flags) : PortSelectDialog(parent, flags) {
    hboxLayout2 = new QHBoxLayout();
    hboxLayout2->setContentsMargins(0, 0, 0, 0);
    hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));

    label = new QLabel(this);
    label->setObjectName(QString::fromUtf8("deviceId"));
    label->setText(QApplication::translate("Port_Selector", "RS485 device ID", 0));

    hboxLayout2->addWidget(label);

    id = new QSpinBox(this);
    id->setObjectName(QString::fromUtf8("spinBox"));
    id->setRange(0, 255);

    hboxLayout2->addWidget(id);

    verticalLayout->insertLayout(1, hboxLayout2);
}

void RS485PortSelectDialog::SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO> _DevInfoList) {
    SerianNumbers.clear();
    for (int i = 0; i < _DevInfoList.size(); ++i) {
        listWidget->addItem(QString("%1 %2 %3 %4")
                                .arg(QString::number(i),
                                     _DevInfoList[i].Description,
                                     _DevInfoList[i].SerialNumber,
                                     QString::number(_DevInfoList[i].ChipID)));
        SerianNumbers.append(_DevInfoList[i].SerialNumber);
    }
}

void RS485PortSelectDialog::accept() {
    PortSelectDialog::accept();

    if (listWidget->selectionModel()->hasSelection()) {
        SelectedSN = SerianNumbers.at(listWidget->selectionModel()->selectedRows().at(0).row()).toLatin1();
        emit NewDeviceIdSelected(id->value());
        emit NewPortSelected(SelectedSN);
    }
}

D485List RS485Port::openedPorts;

RS485Port::RS485Port(QObject* parent) : DevicePort(parent), cfgd(NULL), id(-1), port(NULL) {
    SetTimeouts();
    SetBaudRate();
    SetDataCharacteristics();
}

PortSelectDialog* RS485Port::CreatePortSelectDlg(QWidget* parent) {
    if (!cfgd) {
        cfgd = new RS485PortSelectDialog(parent);
        SetPortDialog(cfgd);

        connect(this,
                SIGNAL(FillDialog(QVector<MY_FT_DEVICE_LIST_INFO>)),
                cfgd,
                SLOT(SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO>)));
        connect(cfgd, SIGNAL(NewDeviceIdSelected(int)), this, SLOT(CloseDevice()));
        connect(cfgd, SIGNAL(NewDeviceIdSelected(int)), this, SLOT(SetDeviceID(int)));
        connect(cfgd, SIGNAL(NewPortSelected(QByteArray)), this, SLOT(OpenDeviceSN(QByteArray)));
    }

    return cfgd;
}

void RS485Port::FillSelectDialog() {
    FTDIinterface dev;
    emit FillDialog(dev.DeviceList(true));
}

FT_STATUS RS485Port::OpenDeviceSN(QByteArray _SN) {
    // qDebug() << "NewPort";
    if (id == -1) {
        qWarning() << "RS485 incorect or once opened device ID";
        emit logMessage(LIBS::Warning, QString("RS485Port: Incorrect or once opened device ID."));
        return FT_DEVICE_NOT_OPENED;
    }

    bool opened = false, idfound = false;
    int e = 0;
    for (int i = 0; i < openedPorts.size(); ++i) {
        if (openedPorts.at(i)->SerialNo() == _SN) {
            opened = true;
            e      = i;

            if (openedPorts.at(i)->DeviceID() == id) {
                idfound = true;
                break;
            }
        }
    }

    if (idfound) {
        emit logMessage(LIBS::Warning, QString("RS485Port: Once opened device ID."));
        return FT_DEVICE_NOT_OPENED;
    }

    sn = _SN;

    if (opened) {
        // FTDI je otevreno
        port = openedPorts.at(e)->FTDIport();
        openedPorts.append(this);
    } else {
        port = new FTDIinterface();
        port->moveToThread(this->thread());

        port->SetTimeouts(readTimeout, writeTimeout);
        port->SetBaudRate(baudRate);
        port->SetDataCharacteristics(wordLength, stopBits, parity);

        FT_STATUS op = port->OpenDeviceSN(_SN);
        if (op == FT_OK) {
            openedPorts.append(this);
        } else
            return op;
    }

    initialized = port->IsInitialised();

    AfterInitialization();

    emit DeviceIDChanged(id);
    emit PortDescriptorChanged(
        QString("%1 SN: %2 RS458id: %3").arg(port->Descriptor(), port->SerialNo(), QString::number(id)));

    // qDebug() << "RS485 device ID " << id << " opened";
    return FT_OK;
}

FT_STATUS RS485Port::CloseDevice() {
    if (openedPorts.contains(this)) {
        openedPorts.removeOne(this);
    }

    bool opened = false;
    for (int i = 0; i < openedPorts.size(); ++i) {
        if (openedPorts.at(i)->SerialNo() == sn) {
            opened = true;
            break;
        }
    }

    if (!opened && port) {
        port->CloseDevice();
        delete port;
        port = NULL;
    }

    return FT_OK;
}
