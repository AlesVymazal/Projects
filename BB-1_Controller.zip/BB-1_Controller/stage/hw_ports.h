#ifndef HWPORTS_H
#define HWPORTS_H

#include <QApplication>
#include <QDebug>
#include <QDialog>
#include <QLabel>
#include <QListWidgetItem>
#include <QMutex>
#include <QObject>
#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>
#include <QtSerialPort/QSerialPortInfo>
#include <QtSerialPort/QtSerialPort>

#include "ftd2xx.h"

#include "FTChipID.h"

#include <qt_windows.h>

#include "LIBS.h"
#include "config.h"

struct MY_FT_DEVICE_LIST_INFO {
    ULONG Flags;
    ULONG Type;
    ULONG ID;
    DWORD LocId;
    char SerialNumber[16];
    char Description[64];
    FT_HANDLE ftHandle;
    ULONG ChipID;
};

//!  Zakladni Dialog pro volbu portu.
/*!
 * \ingroup guis
 */
class PortSelectDialog : public QDialog {
    Q_OBJECT
public:
    PortSelectDialog(QWidget* parent = 0, Qt::WindowFlags flags = 0);
    virtual ~PortSelectDialog();

protected slots:
    virtual void accept();
    void reject();
    void on_listWidget_itemClicked(QListWidgetItem*) {
        okButton->setEnabled(true);
    }

signals:
    void Showing();

protected:
    QVBoxLayout* verticalLayout;
    QListWidget* listWidget;
    QHBoxLayout* hboxLayout;
    QSpacerItem* spacerItem;
    QPushButton* okButton;
    QPushButton* cancelButton;

    void showEvent(QShowEvent* e) {
        listWidget->clear();
        emit Showing();
        QDialog::showEvent(e);
    }
};

//!  Zakladni trida reprezentujici komunikacni port pro kontrolery
/*!
 * \ingroup hardware
 */
class DevicePort : public QObject {
    Q_OBJECT
public:
    DevicePort(QObject* parent = nullptr) : QObject(parent) {
        initialized = false;
    }
    virtual ~DevicePort() {
    }

    void SetPortDialog(PortSelectDialog* _dlg) {
        dlg = _dlg;
        connect(dlg, SIGNAL(Showing()), SLOT(FillSelectDialog()));
    }

    virtual PortSelectDialog* CreatePortSelectDlg(QWidget* parent) = 0;

public slots:
    virtual FT_STATUS OpenDevice()  = 0;
    virtual FT_STATUS CloseDevice() = 0;

    virtual FT_STATUS TxPacket(QByteArray _packet) = 0;

    virtual FT_STATUS RxPacket()                                                                                = 0;
    virtual FT_STATUS RxPacketLength(int wait_for_number_of_bytes)                                              = 0;
    virtual FT_STATUS RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character = false) = 0;

    virtual QByteArray GetRxPacket() = 0;

    bool IsInitialised() {
        return initialized;
    }

    virtual void FillSelectDialog() = 0;

signals:
    void PacketReceived(QByteArray _packet);
    void PortDescriptorChanged(QString _value);
    void logMessage(LIBS::messageType mType, QString str);

protected:
    bool initialized;

    //! provede pripadne specificke akce v potomcich
    virtual void AfterInitialization() {
    }
    PortSelectDialog* dlg;
};

//!  Dialog pro volbu portu v FTDIinterface.
/*!
 * \ingroup guis
 */
class FTDIPortSelectDialog : public PortSelectDialog {
    Q_OBJECT
public:
    FTDIPortSelectDialog(QWidget* parent = 0, Qt::WindowFlags flags = 0);
    ~FTDIPortSelectDialog() {
    }

public slots:
    void SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO> _DevInfoList);

protected slots:
    void accept() override;

signals:
    void NewPortSelected(QByteArray SN);

protected:
    QStringList SerianNumbers;
    QByteArray SelectedSN;
};

//!  Trida obsluhy USB FTDI serial port interface.
/*!
 * \ingroup hardware
 */
class FTDIinterface : public DevicePort {
    Q_OBJECT

public:
    FTDIinterface(QObject* parent = nullptr);
    ~FTDIinterface() override {
        FTDIinterface::CloseDevice();
    } // neni vhodne volat virtualni funkci v destruktoru

    QVector<MY_FT_DEVICE_LIST_INFO> DeviceList(bool forceDetection = false) {
        CheckForDevices(forceDetection);
        return DevInfoList();
    }

    unsigned long SN2ChipID(QByteArray _SN);
    QByteArray ChipID2SN(unsigned long ChipID);
    unsigned long Descriptor2ChipID(QByteArray _descriptor);
    QByteArray ChipID2Descriptor(unsigned long ChipID);

    QByteArray SerialNo() {
        return SN;
    }
    QByteArray Descriptor() {
        return QByteArray(Description);
    }

    PortSelectDialog* CreatePortSelectDlg(QWidget* parent) override;

    static QString Error(FT_STATUS error);

    unsigned long getBaudRate() {
        return baudRate;
    }

public slots:
    void SetSN(QByteArray _SN) {
        SN = _SN;
    }
    void SetDescriptor(QByteArray _descriptor) {
        descriptor = _descriptor;
    }

    FT_STATUS OpenDevice() override;

    FT_STATUS OpenDevice(QByteArray _descriptor);
    virtual FT_STATUS OpenDeviceSN(QByteArray _SN);

    FT_STATUS CloseDevice() override;

    FT_STATUS SetTimeouts(unsigned long _ReadTimeout = 5000, unsigned long _WriteTimeout = 1000);
    FT_STATUS SetBaudRate(unsigned long _BaudRate = 115200);
    FT_STATUS SetBaudRateINT(int _BaudRate = 115200) {
        return SetBaudRate(_BaudRate);
    }
    FT_STATUS SetDataCharacteristics(unsigned char _WordLength = FT_BITS_8,
                                     unsigned char _StopBits   = FT_STOP_BITS_2,
                                     unsigned char _Parity     = FT_PARITY_NONE);

    FT_STATUS TxPacket(QByteArray _packet) override;

    FT_STATUS RxPacket() override;
    FT_STATUS RxPacketLength(int wait_for_number_of_bytes) override;
    FT_STATUS RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character = false) override;
    QByteArray GetRxPacket() override {
        return rx_packet;
    }

    FT_STATUS CheckForDevices(bool internally = true);

    void FillSelectDialog() override;

signals:
    void FillDialog(QVector<MY_FT_DEVICE_LIST_INFO> _value);

protected:
    FT_STATUS OpenDevice(QByteArray arg, DWORD flangs);
    //! promenne pro otervreni pomoci opendevice() bez parametru;
    QByteArray SN, descriptor;

    ////! provede pripadne specificke akce v potomcich
    // virtual void AfterInitialization(){};

    QVector<MY_FT_DEVICE_LIST_INFO>& DevInfoList() {
        static QVector<MY_FT_DEVICE_LIST_INFO> devInfoList;
        return devInfoList;
    }

    FT_HANDLE ftHandle;
    FT_STATUS ftStatus;
    DWORD numDevs;
    bool TimeOutFlag;

    FT_DEVICE ftDevice;
    DWORD deviceID;
    char SerialNumber[16];
    char Description[64];
    QByteArray rx_packet;
    char rx_byte;

    FT_STATUS RxByte();

    //! parametry portu
    unsigned long readTimeout, writeTimeout, baudRate;
    unsigned char wordLength, stopBits, parity;

    FTDIPortSelectDialog* cfgd;
};

//!  Dialog pro volbu com portu v SerialPort.
/*!
 * \ingroup guis
 */
class ComPortSelectDialog : public PortSelectDialog {
    Q_OBJECT
public:
    ComPortSelectDialog(QWidget* parent = 0, Qt::WindowFlags flags = 0);
    ~ComPortSelectDialog() {
    }

public slots:
    void SetComList(QStringList _ports, QStringList _descriptors);

protected slots:
    void accept() override;

signals:
    void NewPortSelected(QByteArray portName);

protected:
    QStringList ports, descriptors;
    QByteArray selectedPort;
};

//!  Trida obsluhy serial port interface.
/*!
 * \ingroup hardware
 */
class SerialPort : public DevicePort {
    Q_OBJECT
public:
    SerialPort(QObject* parent = nullptr);
    ~SerialPort() {
    }

    virtual PortSelectDialog* CreatePortSelectDlg(QWidget* parent) override;

    void SetTimeouts(unsigned long _ReadTimeout = 5000, unsigned long _WriteTimeout = 1000);
    void SetBaudRate(unsigned long _BaudRate = 115200);
    void SetDataCharacteristics(QSerialPort::DataBits _WordLength = QSerialPort::Data8,
                                QSerialPort::StopBits _StopBits   = QSerialPort::TwoStop,
                                QSerialPort::Parity _Parity       = QSerialPort::NoParity);

signals:
    void FillDialog(QStringList _ports, QStringList _descriptors);

public slots:
    FT_STATUS OpenDevice(QByteArray _portName);
    FT_STATUS OpenDevice() override;
    FT_STATUS CloseDevice() override;

    FT_STATUS TxPacket(QByteArray _packet) override;

    FT_STATUS RxPacket() override;
    FT_STATUS RxPacketLength(int wait_for_number_of_bytes) override;
    FT_STATUS RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character = false) override;

    QByteArray GetRxPacket() override {
        return rxPacket;
    }

    void SetPortName(QByteArray _portName) {
        portName = _portName;
    }
    QByteArray PortName() {
        return portName;
    }

    void FillSelectDialog() override;

private:
    QSerialPort serial;
    QByteArray portName;
    QByteArray rxPacket;

    unsigned long readTimeout, writeTimeout;

    ComPortSelectDialog* cfgd;
};

//!  Dialog pro volbu portu a ID pro RS485 .
/*!
 * \ingroup guis
 */
class RS485PortSelectDialog : public PortSelectDialog {
    Q_OBJECT
public:
    RS485PortSelectDialog(QWidget* parent = 0, Qt::WindowFlags flags = 0);
    ~RS485PortSelectDialog() {
    }

public slots:
    void SetFTDIList(QVector<MY_FT_DEVICE_LIST_INFO> _DevInfoList);

protected slots:
    void accept() override;

signals:
    void NewDeviceIdSelected(int deviceId);
    void NewPortSelected(QByteArray SN);

protected:
    QStringList SerianNumbers;
    QByteArray SelectedSN;

    QSpinBox* id;
    QLabel* label;
    QHBoxLayout* hboxLayout2;
};

class RS485Port;

typedef QList<RS485Port*> D485List;

class RS485Port : public DevicePort {
    Q_OBJECT
public:
    RS485Port(QObject* parent = nullptr);
    ~RS485Port() {
        RS485Port::CloseDevice();
    }

    PortSelectDialog* CreatePortSelectDlg(QWidget* parent) override;

public slots:
    FT_STATUS OpenDeviceSN(QByteArray _SN);
    FT_STATUS OpenDevice() override {
        return OpenDeviceSN(sn);
    }
    FT_STATUS CloseDevice() override;

    FT_STATUS TxPacket(QByteArray _packet) override {
        if (port)
            return port->TxPacket(_packet);
        return FT_INVALID_HANDLE;
    }

    FT_STATUS RxPacket() override {
        if (port)
            return port->RxPacket();
        return FT_INVALID_HANDLE;
    }
    FT_STATUS RxPacketLength(int wait_for_number_of_bytes) override {
        if (port)
            return port->RxPacketLength(wait_for_number_of_bytes);
        return FT_INVALID_HANDLE;
    }
    FT_STATUS RxPacketLastCharacter(char wait_for_last_character, bool retrieve_last_character = false) override {
        if (port)
            return port->RxPacketLastCharacter(wait_for_last_character, retrieve_last_character);
        return FT_INVALID_HANDLE;
    }

    QByteArray GetRxPacket() override {
        if (port)
            return port->GetRxPacket();
        return QByteArray();
    }

    void SetTimeouts(unsigned long _ReadTimeout = 1000, unsigned long _WriteTimeout = 500) {
        readTimeout  = _ReadTimeout;
        writeTimeout = _WriteTimeout;
    }
    void SetBaudRate(unsigned long _BaudRate = 115200) {
        baudRate = _BaudRate;
    }
    void SetDataCharacteristics(unsigned char _WordLength = FT_BITS_8,
                                unsigned char _StopBits   = FT_STOP_BITS_1,
                                unsigned char _Parity     = FT_PARITY_NONE) {
        wordLength = _WordLength;
        stopBits   = _StopBits;
        parity     = _Parity;
    }

    void SetSN(QByteArray _SN) {
        sn = _SN;
    }
    //! RS485 device Id
    int DeviceID() {
        return id;
    }
    //! FTDI Serial number
    QByteArray SerialNo() {
        return sn;
    }
    //! FTDI port
    FTDIinterface* FTDIport() {
        return port;
    }

signals:
    void DeviceIDChanged(int id);
    void FillDialog(QVector<MY_FT_DEVICE_LIST_INFO> info);

public slots:
    void SetDeviceID(int deviceId) {
        id = deviceId;
    }
    void FillSelectDialog() override;

protected:
    RS485PortSelectDialog* cfgd;
    static D485List openedPorts;
    int id;
    QByteArray sn;

    FTDIinterface* port;
    unsigned long readTimeout, writeTimeout;
    unsigned long baudRate;
    unsigned char wordLength;
    unsigned char stopBits;
    unsigned char parity;
};

#endif
