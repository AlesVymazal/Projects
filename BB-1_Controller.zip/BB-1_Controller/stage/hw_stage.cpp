#include "hw_stage.h"

XYStage::XYStage(unsigned char X_motorIndex,
                 unsigned char Y_motorIndex,
                 unsigned char Z_motorIndex,
                 TrinamicController* _driver,
                 QObject* parent)
    : QObject(parent) {
    driver = _driver;

    manipulatorX = new LinearAxis(X_motorIndex, _driver, this); // manipulatory vzorku
    connect(manipulatorX, SIGNAL(Status(QString)), SIGNAL(Status(QString)));
    connect(manipulatorX, SIGNAL(RealPosition(QString)), SIGNAL(ManXStatus(QString)));
    //	connect(manipulatorX, SIGNAL(MicroStepsPosition(int)), SIGNAL(ManXStatus(int)));
    connect(manipulatorX, SIGNAL(RealPosition(double)), SIGNAL(ManXStatus(double)));
    connect(manipulatorX, SIGNAL(RealPosition(double)), SLOT(UpdateCurrentManX(double)));
    connect(manipulatorX, SIGNAL(LimitsChanged(double, double)), SIGNAL(ManXLimitsChanged(double, double)));

    connect(manipulatorX, SIGNAL(AxisStoped()), SIGNAL(ManXStoped()));
    connect(manipulatorX, SIGNAL(AxisReferenced()), SIGNAL(ManXReferenced()));

    manipulatorY = new LinearAxis(Y_motorIndex, _driver);
    connect(manipulatorY, SIGNAL(Status(QString)), SIGNAL(Status(QString)));
    connect(manipulatorY, SIGNAL(RealPosition(QString)), SIGNAL(ManYStatus(QString)));
    //	connect(manipulatorY, SIGNAL(MicroStepsPosition(int)), SIGNAL(ManYStatus(int)));
    connect(manipulatorY, SIGNAL(RealPosition(double)), SIGNAL(ManYStatus(double)));
    connect(manipulatorY, SIGNAL(RealPosition(double)), SLOT(UpdateCurrentManY(double)));
    connect(manipulatorY, SIGNAL(LimitsChanged(double, double)), SIGNAL(ManYLimitsChanged(double, double)));

    connect(manipulatorY, SIGNAL(AxisStoped()), SIGNAL(ManYStoped()));
    connect(manipulatorY, SIGNAL(AxisReferenced()), SIGNAL(ManYReferenced()));

    manipulatorZ = new LinearAxis(Z_motorIndex, _driver);
    connect(manipulatorZ, SIGNAL(Status(QString)), SIGNAL(Status(QString)));
    connect(manipulatorZ, SIGNAL(RealPosition(QString)), SIGNAL(ManZStatus(QString)));
    //	connect(manipulatorZ, SIGNAL(MicroStepsPosition(int)), SIGNAL(ManZStatus(int)));
    connect(manipulatorZ, SIGNAL(RealPosition(double)), SIGNAL(ManZStatus(double)));
    connect(manipulatorZ, SIGNAL(RealPosition(double)), SLOT(UpdateCurrentManZ(double)));
    connect(manipulatorZ, SIGNAL(LimitsChanged(double, double)), SIGNAL(ManZLimitsChanged(double, double)));

    connect(manipulatorZ, SIGNAL(AxisStoped()), SIGNAL(ManZStoped()));
    connect(manipulatorZ, SIGNAL(AxisReferenced()), SIGNAL(ManZReferenced()));

    connect(manipulatorX, SIGNAL(AxisStoped()), SLOT(StopCheck()));
    connect(manipulatorY, SIGNAL(AxisStoped()), SLOT(StopCheck()));
    connect(manipulatorZ, SIGNAL(AxisStoped()), SLOT(StopCheck()));

    connect(manipulatorX, SIGNAL(AxisReferenced()), SLOT(ReferenceCheck()));
    connect(manipulatorY, SIGNAL(AxisReferenced()), SLOT(ReferenceCheck()));
    connect(manipulatorZ, SIGNAL(AxisReferenced()), SLOT(ReferenceCheck()));

    connect(manipulatorX,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(logMessage(LIBS::messageType, QString)));
    connect(manipulatorY,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(logMessage(LIBS::messageType, QString)));
    connect(manipulatorZ,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(logMessage(LIBS::messageType, QString)));

    manStep = 1;
    manX    = 0;
    manY    = 0;
    manZ    = 0;

    fov = QSizeF(0., 0.);
}

XYStage::~XYStage() {
}

void XYStage::SetupConfigGui(QTabWidget* _toSet) {
    QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
    QWidget* NewTab = new QWidget(_toSet);
    manipulatorX->SetupConfigGui(NewTab);
    QWidget* axisNum = new QWidget(NewTab);
    QVBoxLayout* lay = new QVBoxLayout(axisNum);
    QSpinBox* spin   = new QSpinBox(axisNum);
    QLabel* lab      = new QLabel(QString("Axis number:"), axisNum);
    lay->addWidget(lab);
    lay->addWidget(spin);
    spin->setMaximum(5);
    spin->setValue(stg.value(QString("private/stage/xAxis"), 1).toInt());
    axisNum->setLayout(lay);
    NewTab->layout()->addWidget(axisNum);
    _toSet->addTab(NewTab, trUtf8("Manipulator X"));
    connect(spin, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int val) {
        QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
        stg.setValue(QString("private/stage/xAxis"), val);
    });

    NewTab = new QWidget(_toSet);
    manipulatorY->SetupConfigGui(NewTab);
    axisNum = new QWidget(NewTab);
    lay     = new QVBoxLayout(axisNum);
    spin    = new QSpinBox(axisNum);
    lab     = new QLabel(QString("Axis number:"), axisNum);
    lay->addWidget(lab);
    lay->addWidget(spin);
    spin->setMaximum(5);
    spin->setValue(stg.value(QString("private/stage/yAxis"), 0).toInt());
    axisNum->setLayout(lay);
    NewTab->layout()->addWidget(axisNum);
    _toSet->addTab(NewTab, trUtf8("Manipulator Y"));
    connect(spin, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int val) {
        QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
        stg.setValue(QString("private/stage/yAxis"), val);
    });

    NewTab = new QWidget(_toSet);
    manipulatorZ->SetupConfigGui(NewTab);
    axisNum = new QWidget(NewTab);
    lay     = new QVBoxLayout(axisNum);
    spin    = new QSpinBox(axisNum);
    lab     = new QLabel(QString("Axis number:"), axisNum);
    lay->addWidget(lab);
    lay->addWidget(spin);
    spin->setMaximum(5);
    spin->setValue(stg.value(QString("private/stage/zAxis"), 2).toInt());
    axisNum->setLayout(lay);
    NewTab->layout()->addWidget(axisNum);
    _toSet->addTab(NewTab, trUtf8("Manipulator Z"));
    connect(spin, static_cast<void (QSpinBox::*)(int)>(&QSpinBox::valueChanged), [=](int val) {
        QSettings stg(Config("trinamic").Default(), QSettings::defaultFormat());
        stg.setValue(QString("private/stage/zAxis"), val);
    });
}

void XYStage::saveSettings() {
    manipulatorX->saveSettings();
    manipulatorY->saveSettings();
    manipulatorZ->saveSettings();
}

void XYStage::ReferenceSearch() {
    if (manipulatorX->AutoReference())
        manipulatorX->ReferenceSearch();
    if (manipulatorY->AutoReference())
        manipulatorY->ReferenceSearch();
    if (manipulatorZ->AutoReference())
        manipulatorZ->ReferenceSearch();
}

void XYStage::forceReferenceSearch() {
    if (manipulatorX->AutoReference())
        manipulatorX->ReferenceSearch(true);
    if (manipulatorY->AutoReference())
        manipulatorY->ReferenceSearch(true);
    if (manipulatorZ->AutoReference())
        manipulatorZ->ReferenceSearch(true);
}
