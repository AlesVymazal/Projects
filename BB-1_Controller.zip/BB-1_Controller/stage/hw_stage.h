#ifndef HSTAGE_H
#define HSTAGE_H

#include "hw_linearAxis.h"

//!  Trida ovladani motorizovaneho posuvu manipulatoru vzorku.
/*!
 * \ingroup hardware
 */
class XYStage : public QObject {
    Q_OBJECT
public:
    XYStage(unsigned char X_motorIndex,
            unsigned char Y_motorIndex,
            unsigned char Z_motorIndex,
            TrinamicController* _driver,
            QObject* parent = nullptr);
    ~XYStage();

    void SetupConfigGui(QTabWidget* _toSet);

    //! objekt osy X
    LinearAxis* XAxis() {
        return manipulatorX;
    }

    //! objekt osy Y
    LinearAxis* YAxis() {
        return manipulatorY;
    }

    //! objekt osy Z
    LinearAxis* ZAxis() {
        return manipulatorZ;
    }

    //! objekt radice
    TrinamicController* Driver() {
        return driver;
    }

    double ManStep() {
        return manStep;
    }

public slots:
    void InitMotorParameters() {
        manipulatorX->InitMotorParameters();
        manipulatorY->InitMotorParameters();
        manipulatorZ->InitMotorParameters();
    }

    void SetManStep(double _step_mm) {
        if (manStep != _step_mm) {
            manStep = _step_mm;
            emit ManStepChanged(manStep);
        };
    }

    void SetFieldOfView(QSizeF _FOV) {
        fov = _FOV;
    }

    //! hledani reference os X a Y soucasne
    void ReferenceSearch();
    void forceReferenceSearch();
    //! zastaveni X a Y motoru stage
    void MotorStop() {
        manipulatorX->MotorStop();
        manipulatorY->MotorStop();
        manipulatorZ->MotorStop();
    }

    //! posun na souradnice 0,0
    void ManipulatorToOrigin() {
        manipulatorX->MoveToPosition(0);
        manipulatorY->MoveToPosition(0);
        manipulatorZ->MoveToPosition(0);
    }
    //! posun na souradnice x,y,z
    void MoveToPos(double x_mm, double y_mm, double z_mm) {
        manipulatorX->MoveToPosition(x_mm);
        manipulatorY->MoveToPosition(y_mm);
        manipulatorZ->MoveToPosition(z_mm);
    }
    //! posun na souradnice pos QPointF mm
    void MoveToPos(QPointF pos) {
        // qDebug() << QString("Moving manipulator to position: ") << pos;
        manipulatorX->MoveToPosition(pos.x());
        manipulatorY->MoveToPosition(pos.y());
    }

    //! uklada aktualni souradnici manipulatoru
    void UpdateCurrentManX(double _pos_mm) {
        manX = _pos_mm;
    }
    //! uklada aktualni souradnici manipulatoru
    void UpdateCurrentManY(double _pos_mm) {
        manY = _pos_mm;
    }
    //! uklada aktualni souradnici manipulatoru
    void UpdateCurrentManZ(double _pos_mm) {
        manZ = _pos_mm;
    }

    void ManipulatorXReferenceSearch() {
        manipulatorX->ReferenceSearch();
    }
    void ManipulatorXUp() {
        manipulatorX->MoveToPosition(manX + manStep);
    }
    void ManipulatorXDown() {
        manipulatorX->MoveToPosition(manX - manStep);
    }
    void ManipulatorXStop() {
        manipulatorX->MotorStop();
    }
    void ManipulatorXRor(int _speed) {
        manipulatorX->RotateRight(_speed);
    }
    void ManipulatorXRol(int _speed) {
        manipulatorX->RotateLeft(_speed);
    }
    void ManipulatorXMoveTo(double _position_mm) {
        manipulatorX->MoveToPosition(_position_mm);
    }
    void ManipulatorXMoveRelative(double _delta_mm) {
        manipulatorX->MoveRelative(_delta_mm);
    }
    void MoveManXToOrigin() {
        manipulatorX->MoveToPosition(0);
    }
    void ManipulatorXUpHalfFov() {
        manipulatorX->MoveToPosition(manX + fov.width() / 2000.);
    }
    void ManipulatorXDownHalfFov() {
        manipulatorX->MoveToPosition(manX - fov.width() / 2000.);
    }

    void ManipulatorYReferenceSearch() {
        manipulatorY->ReferenceSearch();
    }
    void ManipulatorYUp() {
        manipulatorY->MoveToPosition(manY + manStep);
    }
    void ManipulatorYDown() {
        manipulatorY->MoveToPosition(manY - manStep);
    }
    void ManipulatorYStop() {
        manipulatorY->MotorStop();
    }
    void ManipulatorYRor(int _speed) {
        manipulatorY->RotateRight(_speed);
    }
    void ManipulatorYRol(int _speed) {
        manipulatorY->RotateLeft(_speed);
    }
    void ManipulatorYMoveTo(double _position_mm) {
        manipulatorY->MoveToPosition(_position_mm);
    }
    void ManipulatorYMoveRelative(double _delta_mm) {
        manipulatorY->MoveRelative(_delta_mm);
    }
    void MoveManYToOrigin() {
        manipulatorY->MoveToPosition(0);
    }
    void ManipulatorYUpHalfFov() {
        manipulatorY->MoveToPosition(manY + fov.height() / 2000.);
    }
    void ManipulatorYDownHalfFov() {
        manipulatorY->MoveToPosition(manY - fov.height() / 2000.);
    }

    void ManipulatorZReferenceSearch() {
        manipulatorZ->ReferenceSearch();
    }
    void ManipulatorZUp() {
        manipulatorZ->MoveToPosition(manZ + manStep);
    }
    void ManipulatorZDown() {
        manipulatorZ->MoveToPosition(manZ - manStep);
    }
    void ManipulatorZStop() {
        manipulatorZ->MotorStop();
    }
    void ManipulatorZRor(int _speed) {
        manipulatorZ->RotateRight(_speed);
    }
    void ManipulatorZRol(int _speed) {
        manipulatorZ->RotateLeft(_speed);
    }
    void ManipulatorZMoveTo(double _position_mm) {
        manipulatorZ->MoveToPosition(_position_mm);
    }
    void ManipulatorZMoveRelative(double _delta_mm) {
        manipulatorZ->MoveRelative(_delta_mm);
    }
    void MoveManZToOrigin() {
        manipulatorZ->MoveToPosition(0);
    }
    void ManipulatorZUpHalfFov() {
        manipulatorZ->MoveToPosition(manY + fov.height() / 2000.);
    }
    void ManipulatorZDownHalfFov() {
        manipulatorZ->MoveToPosition(manY - fov.height() / 2000.);
    }

    void saveSettings();

signals:
    //! status x a y
    void Status(QString value);

    void ManXStatus(QString value);
    void ManXStatus(double _value_mm);
    void ManXStatus(int _value_steps);
    void ManXLimitsChanged(double _min, double _max);
    //! emise po zastaveni motoru X
    void ManXStoped();
    //! emise po referencivani motoru X
    void ManXReferenced();

    void ManYStatus(QString value);
    void ManYStatus(double _value_mm);
    void ManYStatus(int _value_steps);
    void ManYLimitsChanged(double _min, double _max);
    //! emise po zastaveni motoru Y
    void ManYStoped();
    //! emise po referencivani motoru Y
    void ManYReferenced();

    void ManZStatus(QString value);
    void ManZStatus(double _value_mm);
    void ManZStatus(int _value_steps);
    void ManZLimitsChanged(double _min, double _max);
    //! emise po zastaveni motoru Y
    void ManZStoped();
    //! emise po referencivani motoru Y
    void ManZReferenced();

    //! emise po zastaveni motoru x a y
    void Stoped();
    //! emise po referencovani motoru x a y
    void Referenced();

    void ManStepChanged(double _step_mm);

    void logMessage(LIBS::messageType mType, QString str);
private slots:
    void StopCheck() {
        if (!manipulatorX->IsMoving() && !manipulatorY->IsMoving() && !manipulatorZ->IsMoving())
            emit Stoped();
    }
    void ReferenceCheck() {
        if (manipulatorX->IsReferenced() && manipulatorY->IsReferenced() && manipulatorZ->IsReferenced())
            emit Referenced();
    }

private:
    LinearAxis *manipulatorX, *manipulatorY, *manipulatorZ;
    TrinamicController* driver;
    //! krok manipulatoru v mm
    double manStep;
    //! aktualni souradnice manipulatoru
    double manX, manY, manZ;
    //! field of view
    QSizeF fov;
};

#endif // HSTAGE_H
