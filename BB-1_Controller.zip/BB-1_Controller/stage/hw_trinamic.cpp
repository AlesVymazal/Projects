 #include "hw_trinamic.h"

QMutex TMCM6110DriverBase::m_commMutex;

QString baToHex(QByteArray ba) {
    QString str;
    for (int i = 0; i < ba.length(); i++) {
        str.append(QString("0x%1 (%2), ")
                       .arg((char)ba.at(i) & 0xff, (int)2, (int)16, (QChar)'0')
                       .arg((char)ba.at(i) & 0xff, (int)3, (int)10, (QChar)' '));
    }
    str.remove(str.size() - 2, 2);
    return str;
}

TrinamicController* TrinamicController::CreateDriver(QString type, Config _config, QObject* parent) {
    if (type == "TMCM6110") {
        // qDebug() << "information - creating Trinamic TMCM6110";
        return new TMCM6110Driver(_config, parent);
    }
    if (type == "TMCM6110_485") {
        // qDebug() << "information - creating Trinamic TMCM6110 RS485";
        return new TMCM6110Driver485(_config, parent);
    }
    // if(type == "TMCM610")
    //{
    //	qDebug() << "information - creating Trinamic TMCM610";
    //	return new TMCM610Driver(_config);
    //}

    qWarning() << "creating default Trinamic TMCM610 for type" << type;

    return new TMCM6110Driver(_config, parent);
}

//* TMCM-6110 motor driver implementation *//
TMCM6110Driver::TMCM6110Driver(Config _config, QObject* parent) : TMCM6110DriverBase(_config, parent) {
    QSettings settings(config.Default(), QSettings::defaultFormat());
    port = new SerialPort();
    port->setParent(this);
    static_cast<SerialPort*>(port)->SetPortName(
        settings.value(config.ConfigPrefix() + "/mdriver_SN", "COM1").toByteArray());
    static_cast<SerialPort*>(port)->SetBaudRate(9600);
}

TMCM6110Driver::~TMCM6110Driver() {
    QSettings settings(config.Default(), QSettings::defaultFormat());
    settings.setValue(config.ConfigPrefix() + "/mdriver_SN", static_cast<SerialPort*>(port)->PortName());
    delete port;
}

TMCM6110Driver485::TMCM6110Driver485(Config _config, QObject* parent) : TMCM6110DriverBase(_config, parent) {
    QSettings settings(config.Default(), QSettings::defaultFormat());
    RS485Port* ptr;
    port = ptr = new RS485Port();
    port->setParent(this);

    connect(port, SIGNAL(DeviceIDChanged(int)), SLOT(SetModuleAddress(int)));

    ptr->SetSN(settings.value(config.ConfigPrefix() + "/mdriver_SN", "0").toByteArray());
    ptr->SetDeviceID(settings.value(config.ConfigPrefix() + "/mdriver_485id", "1").toInt());
}

TMCM6110Driver485::~TMCM6110Driver485() {
    QSettings settings(config.Default(), QSettings::defaultFormat());
    settings.setValue(config.ConfigPrefix() + "/mdriver_SN", static_cast<RS485Port*>(port)->SerialNo());
    settings.setValue(config.ConfigPrefix() + "/mdriver_485id", static_cast<RS485Port*>(port)->DeviceID());
    delete port;
}

int TMCM6110DriverBase::SendCommand(unsigned char instructionNumber,
                                    unsigned char type,
                                    unsigned char motorBank,
                                    int value) {
    QMutexLocker lock(&m_commMutex);
    FT_STATUS error = 0xfffff;
    if (port->IsInitialised()) {
        for (int i = 0; i < 5; i++) {
            QByteArray packet(9, 0);
            /*        LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
                    LARGE_INTEGER Frequency;
                    QueryPerformanceFrequency(&Frequency);
                    QueryPerformanceCounter(&StartingTime);
            */
            packet[0] = moduleAddress; // module adress
            packet[1] = instructionNumber;
            packet[2] = type;
            packet[3] = motorBank;
            packet[4] = (unsigned char)(value >> 24);
            packet[5] = (unsigned char)(value >> 16);
            packet[6] = (unsigned char)(value >> 8);
            packet[7] = (unsigned char)(value & 0xff);
            packet[8] = CheckSum(packet);

            // qDebug() << QString("Sending to RS485 %1 .").arg(baToHex(packet));

            port->TxPacket(packet);

            if (!(error = port->RxPacketLength(9))) {

                packet = port->GetRxPacket();

                // qDebug() << QString("Received From RS485 %1 .").arg(baToHex(packet));

                // qDebug() << hex << packet.toHex();

                //            for(int i = 0; i < packet.size(); ++i)
                //                    qDebug() << hex << " " << (unsigned char)packet.at(i);

                unsigned char checksum = packet[8];

                packet.remove(packet.size() - 1, 1); // remove checksum

                if (checksum == CheckSum(packet)) {
                    returnStatus[motorBank] = packet[2]; // status
                    returnBank[motorBank]   = packet[3];
                    returnValue[motorBank]  = packet[4];
                    returnValue[motorBank]  = returnValue[motorBank] << 8;
                    returnValue[motorBank] += (unsigned char)packet[5];
                    returnValue[motorBank] = returnValue[motorBank] << 8;
                    returnValue[motorBank] += (unsigned char)packet[6];
                    returnValue[motorBank] = returnValue[motorBank] << 8;
                    returnValue[motorBank] += (unsigned char)packet[7];

                    /*                QueryPerformanceCounter(&EndingTime);
                                    ElapsedMicroseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
                                    ElapsedMicroseconds.QuadPart *= 1000000;
                                    ElapsedMicroseconds.QuadPart /= Frequency.QuadPart;
                                    qDebug() << "Query time in microseconds R/W operation: " <<
                       ElapsedMicroseconds.QuadPart;
                    */
                    return returnStatus[motorBank];
                } else {
                    qCritical() << "checksum error"
                                << "retry " << i + 1 << "/5";
                    emit logMessage(LIBS::Warning,
                                    QString("TMCM6110DriverBase: Checksum error. Retyring %1/3").arg(i + 1));
                }
            } else {
                qCritical() << "command error " << dec << (unsigned char)packet[2] << "retry " << i + 1 << "/5";
                emit logMessage(LIBS::Warning,
                                QString("TMCM6110DriverBase: Command error %1, retrying %2/5.")
                                    .arg((unsigned char)packet[2])
                                    .arg(i + 1));
            }
        }
    } else {
        qCritical() << "Port is not initialized";
        emit logMessage(LIBS::Error, QString("TMCM6110DriverBase: Port is not initialized."));
        return error;
    }
    return error;
}

int TMCM6110DriverBase::SendCommandEx(unsigned char instructionNumber,
                                      unsigned char type,
                                      unsigned char motorBank,
                                      int value) {
    QMutexLocker lock(&m_commMutex);
    FT_STATUS error = 0xfffff;
    if (port->IsInitialised()) {
        for (int i = 0; i < 3; i++) {
            for (int w = 0; w < 3; w++) {
                QByteArray packet(9, 0);
                /*        LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
                        LARGE_INTEGER Frequency;
                        QueryPerformanceFrequency(&Frequency);
                        QueryPerformanceCounter(&StartingTime);
                */
                packet[0] = moduleAddress; // module adress
                packet[1] = instructionNumber;
                packet[2] = type;
                packet[3] = motorBank;
                packet[4] = (unsigned char)(value >> 24);
                packet[5] = (unsigned char)(value >> 16);
                packet[6] = (unsigned char)(value >> 8);
                packet[7] = (unsigned char)(value & 0xff);
                packet[8] = CheckSum(packet);
                //            packet[8] =
                //            (unsignedpacket[0]+packet[1]+packet[2]+packet[3]+packet[4]+packet[5]+packet[6]+packet[7];
                // qDebug() << QString("Sending to RS485 %1 .").arg(baToHex(packet));
                emit logMessage(LIBS::Debug, QString("Sending to RS485 %1 .").arg(baToHex(packet)));

                error = port->TxPacket(packet);
                if (error != FT_OK) {
                    qCritical() << "write error " << error << " " << FTDIinterface::Error(error) << "retry " << w + 1
                                << "/3";
                    emit logMessage(
                        LIBS::Warning,
                        QString("TMCM6110DriverBase: Command write error %1, retrying %2/3.").arg(error).arg(w + 1));
                } else {
                    //                    qDebug() << "write ok";
                    break;
                }
            }
            for (int r = 0; r < 2; r++) {
                QByteArray packet(9, 0);
                if (!(error = port->RxPacketLength(9))) {

                    packet = port->GetRxPacket();
                    // qDebug() << QString("Received From RS485 %1 .").arg(baToHex(packet));
                    emit logMessage(LIBS::Debug, QString("Received From RS485 %1 .").arg(baToHex(packet)));
                    // qDebug() << hex << packet.toHex();

                    //            for(int i = 0; i < packet.size(); ++i)
                    //                    qDebug() << hex << " " << (unsigned char)packet.at(i);

                    unsigned char checksum = packet[8];

                    packet.remove(packet.size() - 1, 1); // remove checksum

                    if (checksum == CheckSum(packet)) {
                        returnStatus[0] = packet[2]; // status
                        returnBank[0]   = packet[3];
                        returnValue[0]  = packet[4];
                        returnValue[0]  = returnValue[0] << 8;
                        returnValue[0] += (unsigned char)packet[5];
                        returnValue[0] = returnValue[0] << 8;
                        returnValue[0] += (unsigned char)packet[6];
                        returnValue[0] = returnValue[0] << 8;
                        returnValue[0] += (unsigned char)packet[7];

                        /*                QueryPerformanceCounter(&EndingTime);
                                        ElapsedMicroseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
                                        ElapsedMicroseconds.QuadPart *= 1000000;
                                        ElapsedMicroseconds.QuadPart /= Frequency.QuadPart;
                                        qDebug() << "Query time in microseconds R/W operation: " <<
                           ElapsedMicroseconds.QuadPart;
                        */
                        return returnStatus[0];
                    } else {
                        qCritical() << "checksum error"
                                    << "retry " << r + 1 << "/3";
                        emit logMessage(LIBS::Warning,
                                        QString("TMCM6110DriverBase: Checksum error. Retyring %1/3").arg(r + 1));
                        break;
                    }
                } else {
                    qCritical() << "read error " << error << " " << FTDIinterface::Error(error) << "retry " << r + 1
                                << "/3";
                    emit logMessage(
                        LIBS::Warning,
                        QString("TMCM6110DriverBase: Command read error %1, retrying %2/3.").arg(error).arg(i + 1));
                }
            }
        }
    } else {
        qCritical() << "Port is not initialized";
        emit logMessage(LIBS::Error, QString("TMCM6110DriverBase: Port is not initialized."));
        return error;
    }
    return error;
}

unsigned char TMCM6110DriverBase::CheckSum(QByteArray _command) {

    unsigned char Checksum = (unsigned char)_command[0];
    for (unsigned char i = 1; i < _command.size(); ++i)
        Checksum += (unsigned char)_command[i];
    return Checksum;
}

//************* trida motoru *************//
TMCM610Motor::TMCM610Motor(unsigned char _axisIndex, TrinamicController* _driver, QObject* parent)
    : MotorAxis(_axisIndex, _driver, parent) {
    driver = _driver;
    timer.setParent(this);

    connect(&timer, SIGNAL(timeout()), SLOT(Checker()));

    referenceSearch  = false;
    referenceStartup = false;
    isMoving         = false;
    isReferenced     = false;
    localReference   = false;

    moveTimeout     = 60000; // timeout 60s
    checkInterval   = 10;    // testovat v intervalu 5 ms
    currentPosition = 0;

    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));

    m_breakTimer.setSingleShot(true);
    m_breakTimer.setInterval(settings.value(tmp + "break_time", 5642).toInt());
    m_breakTimer.stop();
    connect(&m_breakTimer, SIGNAL(timeout()), this, SLOT(holdBreak()), Qt::QueuedConnection);
    m_breakStartMs = settings.value(tmp + "break_start_time", 150).toInt();

    maxAcceleration   = settings.value(tmp + "max_acceleration", 50).toInt();
    maxSpeed          = settings.value(tmp + "max_speed", 500).toInt();
    maxCurrent        = settings.value(tmp + "max_current", 10).toInt();
    standbyCurrent    = settings.value(tmp + "standby_current", 10).toInt();
    referenceType     = settings.value(tmp + "reference_search_type", 1).toInt();
    referenceSpeed_1  = settings.value(tmp + "reference_search_speed_1", 2).toInt();
    referenceSpeed_2  = settings.value(tmp + "reference_search_speed_2", 4).toInt();
    fullStepThreshold = settings.value(tmp + "fullStepThreshold", 0).toInt();
    stepDeg           = settings.value(tmp + "stepDeg", 7.5).toDouble();
    axisDirection     = settings.value(tmp + "direction", false).toBool();
    pulseDivisor      = settings.value(tmp + "pulse_divisor", 3).toInt();
    rampDivisor       = settings.value(tmp + "ramp_divisor", 7).toInt();
    microSteps        = settings.value(tmp + "microsteps", 6).toInt();
    stageName         = settings.value(tmp + "motor_name", "noname").toByteArray();
    m_hasBreak        = settings.value(tmp + "hasBreak", false).toBool();
    m_breakOutput     = settings.value(tmp + "breakOutput", 3).toInt();
    m_breakPolarity =
        (TMCM610Motor::breakPolarity)settings.value(tmp + "breakPolarity", TMCM610Motor::breakedLow).toInt();
    m_autoReference = settings.value(tmp + "autoReference", false).toBool();
    m_swapLimSW     = settings.value(tmp + "swapLimSW", false).toBool();
    errorOccured    = false;
}

TMCM610Motor::~TMCM610Motor() {
    driver->RemoveChildAxis(this);

    Config config = driver->ConfigPrefix();
    QSettings settings(config.Default(), QSettings::defaultFormat());

    QString tmp = QString("%1/mdriver_motor_%2_").arg(config.ConfigPrefix(), QString::number(axisIndex));
    settings.setValue(tmp + "max_acceleration", maxAcceleration);
    settings.setValue(tmp + "max_speed", maxSpeed);
    settings.setValue(tmp + "max_current", maxCurrent);
    settings.setValue(tmp + "standby_current", standbyCurrent);
    settings.setValue(tmp + "reference_search_type", referenceType);
    settings.setValue(tmp + "reference_search_speed_1", referenceSpeed_1);
    settings.setValue(tmp + "reference_search_speed_2", referenceSpeed_2);
    settings.setValue(tmp + "fullStepThreshold", fullStepThreshold);
    settings.setValue(tmp + "stepDeg", stepDeg);
    settings.setValue(tmp + "direction", axisDirection);
    settings.setValue(tmp + "motor_name", stageName);
    settings.setValue(tmp + "pulse_divisor", pulseDivisor);
    settings.setValue(tmp + "ramp_divisor", rampDivisor);
    settings.setValue(tmp + "microsteps", microSteps);
    settings.setValue(tmp + "hasBreak", m_hasBreak);
    settings.setValue(tmp + "breakOutput", m_breakOutput);
    settings.setValue(tmp + "breakPolarity", (int)m_breakPolarity);
    settings.setValue(tmp + "autoReference", m_autoReference);
    settings.setValue(tmp + "swapLimSW", m_swapLimSW);
}

void TMCM610Motor::SetupConfigGui(QWidget* _toSet) {
    ui.setupUi(_toSet);

    ui.spinBoxAccel->setValue(maxAcceleration);
    connect(ui.spinBoxAccel, SIGNAL(valueChanged(int)), SLOT(SetMaxAcceleration(int)));

    ui.checkBox->setChecked(referenceType & (1 << 7));
    connect(ui.checkBox, SIGNAL(toggled(bool)), SLOT(SetReferenceDirection(bool)));

    ui.spinBoxSpeed->setValue(maxSpeed);
    connect(ui.spinBoxSpeed, SIGNAL(valueChanged(int)), SLOT(SetMaxSpeed(int)));

    ui.spinBoxRefSpeed1->setValue(referenceSpeed_1);
    connect(ui.spinBoxRefSpeed1, SIGNAL(valueChanged(int)), SLOT(SetReferenceSpeed1(int)));

    ui.spinBoxCurrent->setValue(maxCurrent);
    connect(ui.spinBoxCurrent, SIGNAL(valueChanged(int)), SLOT(SetMaxCurrent(int)));

    ui.spinBoxRefSpeed2->setValue(referenceSpeed_2);
    connect(ui.spinBoxRefSpeed2, SIGNAL(valueChanged(int)), SLOT(SetReferenceSpeed2(int)));

    ui.spinBoxStandByCurrent->setValue(standbyCurrent);
    connect(ui.spinBoxStandByCurrent, SIGNAL(valueChanged(int)), SLOT(SetStandbyCurrent(int)));

    ui.doubleSpinBoxMotorStep->setValue(stepDeg);
    connect(ui.doubleSpinBoxMotorStep, SIGNAL(valueChanged(double)), SLOT(SetMotorStep(double)));

    ui.spinBoxSteps->setValue(360. / stepDeg);
    connect(ui.spinBoxSteps, SIGNAL(valueChanged(int)), SLOT(SetMotorStepsPerRot(int)));

    //    ui.spinBoxFullSteps->setValue(fullStepThreshold);
    //    connect(ui.spinBoxFullSteps, SIGNAL(valueChanged(int)), SLOT(SetFullStepThreshold(int)));

    ui.checkBoxSwapLimSW->setChecked(m_swapLimSW);
    connect(ui.checkBoxSwapLimSW, SIGNAL(clicked(bool)), this, SLOT(setSwapLimSW(bool)));

    ui.checkBox_2->setChecked(axisDirection);
    connect(ui.checkBox_2, SIGNAL(toggled(bool)), SLOT(SetDirection(bool)));

    //    ui.spinBoxDivisor->setValue(pulseDivisor);
    //    connect(ui.spinBoxDivisor, SIGNAL(valueChanged(int)), SLOT(SetPulseDivisor(int)));

    //    ui.spinBoxRamp->setValue(rampDivisor);
    //    connect(ui.spinBoxRamp, SIGNAL(valueChanged(int)), SLOT(SetRampDivisor(int)));

    ui.checkBoxAutoReference->setChecked(m_autoReference);
    connect(ui.checkBoxAutoReference, SIGNAL(clicked(bool)), this, SLOT(SetAutoReference(bool)));

    connect(ui.toolButtonRef, SIGNAL(clicked()), SLOT(FindLocalReference()));

    //    ui.checkBoxHasBreak->setChecked(m_hasBreak);
    //    connect(ui.checkBoxHasBreak, SIGNAL(clicked(bool)), this, SLOT(SetHasBreak(bool)));

    //    ui.spinBoxBreakOutput->setValue(m_breakOutput);
    //    connect(ui.spinBoxBreakOutput, SIGNAL(valueChanged(int)), this, SLOT(SetBreakOutput(int)));

    //    ui.comboBoxBreakPolarity->setCurrentIndex(m_breakPolarity);
    //    connect(ui.comboBoxBreakPolarity, SIGNAL(currentIndexChanged(int)), this, SLOT(SetBreakPolarity(int)));

    ui.comboboxMicrostepping->setCurrentIndex(microSteps);
    connect(ui.comboboxMicrostepping, SIGNAL(currentIndexChanged(int)), this, SLOT(SetMicroSteps(int)));
}

void TMCM610Motor::RotateRight(int _velocity) {
    if (!referenceSearch && isReferenced) {
        st = 0;
        if (!this->IsBreakReleased()) {
            releaseBreak();
            QTimer::singleShot(m_breakStartMs, [=]() { this->RotateRight(_velocity); });
        }
        if (axisDirection)
            st = driver->SendCommand(TMCL_ROR, 0, axisIndex, _velocity);
        else
            st = driver->SendCommand(TMCL_ROL, 0, axisIndex, _velocity);

        if (st == STAT_OK) {
            WhenOK(driver->ReturnValue(axisIndex));
            isMoving = true;
            driver->CheckAxesStatus();
            StartChecker();
        } else
            WhenErrorOccurs(st);
    }
}

void TMCM610Motor::RotateLeft(int _velocity) {
    if (!referenceSearch && isReferenced) {
        st = 0;
        if (!this->IsBreakReleased()) {
            releaseBreak();
            QTimer::singleShot(m_breakStartMs, [=]() { this->RotateLeft(_velocity); });
        }
        if (axisDirection)
            st = driver->SendCommand(TMCL_ROL, 0, axisIndex, _velocity);
        else
            st = driver->SendCommand(TMCL_ROR, 0, axisIndex, _velocity);

        if (st == STAT_OK) {
            WhenOK(driver->ReturnValue(axisIndex));
            isMoving = true;
            driver->CheckAxesStatus();
            StartChecker();
        } else
            WhenErrorOccurs(st);
    }
}

void TMCM610Motor::FindLocalReference() {
    InitMotorParameters();
    localReference = true;
    ReferenceSearch();
    localReference = true;
}

void TMCM610Motor::MoveToPosition(unsigned char _type, int _position) {
    if (!referenceSearch && isReferenced) {
        if (_position == currentPosition)
            return;
        if (!this->IsBreakReleased()) {
            releaseBreak();
            QTimer::singleShot(m_breakStartMs, [=]() { this->MoveToPosition(_type, _position); });
        }
        if (axisDirection)
            _position *= -1;
        st = driver->SendCommand(TMCL_MVP, _type, axisIndex, _position);
        if (st == STAT_OK) {
            WhenOK(driver->ReturnValue(axisIndex));
            isMoving = true;
            driver->CheckAxesStatus();
            StartChecker();
        } else
            WhenErrorOccurs(st);
    }
}

bool TMCM610Motor::ReadReferenceStatus() {
    unsigned char globalUserBank = 2;
    st                           = driver->SendCommand(TMCL_GGP, axisIndex, globalUserBank, 0);
    if (st == STAT_OK) {
        //        qDebug() << "read referenc state is " << axisIndex << driver->ReturnValue(globalUserBank);
        return (driver->ReturnValue(globalUserBank) == 165);
    } else
        return false;
}

void TMCM610Motor::WriteReferenceStatus() {
    unsigned char globalUserBank = 2;
    st                           = driver->SendCommand(TMCL_SGP, axisIndex, globalUserBank, 165);
    if (st != STAT_OK) {
        qCritical() << "store reference flag int controller failed";
        emit logMessage(LIBS::Error, QString("TMCM6110Motor: Store reference flag int controller failed."));
    }
}

void TMCM610Motor::ReferenceSearch(bool overrideReferenceStatus) {
    // Enable limit switches only on expander axis
    if (m_expanderAxis == axisIndex) {
        SetAxisParameter(RIGHT_LIM_SW_DISABLE, 0); // disable right limit switch
        SetAxisParameter(LEFT_LIM_SW_DISABLE, 0);  // disable left limit switch
    }

    if (overrideReferenceStatus || !ReadReferenceStatus() || localReference || referenceStartup) {
        referenceStartup = CheckReferenceSwitch();
        // qDebug() << axisIndex << referenceStartup;
        if (!this->IsBreakReleased()) {
            releaseBreak();
            QTimer::singleShot(m_breakStartMs, [=]() { this->ReferenceSearch(overrideReferenceStatus); });
        }
        if (referenceStartup) {
            int t = referenceType & (1 << 7);
            if (t)
                st = driver->SendCommand(TMCL_ROL, 0, axisIndex, referenceSpeed_1);
            else
                st = driver->SendCommand(TMCL_ROR, 0, axisIndex, referenceSpeed_1);
        } else
            st = driver->SendCommand(TMCL_RFS, RFS_START, axisIndex, 0);

        if (st == STAT_OK) {
            WhenOK(driver->ReturnValue(axisIndex));
            isMoving     = true;
            isReferenced = false;
            driver->CheckAxesStatus();
            referenceSearch = true;
            localReference  = false;
            StartChecker();
        } else
            WhenErrorOccurs(st);
    } else {
        qWarning() << "Trinamic axis " << axisIndex << " referenced before";
        emit logMessage(LIBS::Warning, QString("TMCM6110Motor: Trinamic axis %1 referenced before.").arg(axisIndex));
        isMoving        = false;
        isReferenced    = true;
        referenceSearch = false;
        // if(localReference)
        //	localReference = false;
        // else
        //{
        emit AxisReferenced();
        driver->CheckReferenceStatus();
        //}
        ReferenceMotorStoped();

        // nacteni polohy z registru trinamicu
        AxisParameter(1);

        if (axisDirection)
            currentPosition = -driver->ReturnValue(axisIndex);
        else
            currentPosition = driver->ReturnValue(axisIndex);

        emit MicroStepsPosition(currentPosition);

        CalculateRealPosition();
    }

    // Disable limit switches only on expander axis
    if (m_expanderAxis == axisIndex) {
        SetAxisParameter(RIGHT_LIM_SW_DISABLE, 1); // disable right limit switch
        SetAxisParameter(LEFT_LIM_SW_DISABLE, 1);  // disable left limit switch
    }
}

void TMCM610Motor::ReferenceStop() {
    st = driver->SendCommand(TMCL_RFS, RFS_STOP, axisIndex, 0);
    if (st == STAT_OK) {
        WhenOK(driver->ReturnValue(axisIndex));
        updateBreak();
    } else
        WhenErrorOccurs(st);
}

void TMCM610Motor::ReferenceStatus() {
    st = driver->SendCommand(TMCL_RFS, RFS_STATUS, axisIndex, 0);
    if (st == STAT_OK)
        WhenOK(driver->ReturnValue(axisIndex));
    else
        WhenErrorOccurs(st);
}

void TMCM610Motor::MotorStop() {
    st = 0;
    if (referenceSearch)
        st = driver->SendCommand(TMCL_RFS, RFS_STOP, axisIndex, 0);
    else
        st = driver->SendCommand(TMCL_MST, 0, axisIndex, 0);

    if (st == STAT_OK) {
        WhenOK(driver->ReturnValue(axisIndex));
        updateBreak();
        if (referenceSearch) {
            referenceSearch = false;
            isReferenced    = false; // reference nenalezena
                                     // emit MotorsReferenced();
        } else {
            emit AxisStoped();
        }

        isMoving = false;
        driver->CheckAxesStatus();
    } else
        WhenErrorOccurs(st);
}

void TMCM610Motor::SetAxisParameter(unsigned char _type, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_SAP, _type, axisIndex, _value));
}

void TMCM610Motor::AxisParameter(unsigned char _type) {
    ReturnValueHelper(driver->SendCommand(TMCL_GAP, _type, axisIndex, 0));
}

void TMCM610Motor::StoreAxisParameter(unsigned char _type) {
    ReturnValueHelper(driver->SendCommand(TMCL_STAP, _type, axisIndex, 0));
}

void TMCM610Motor::RestoreAxisParameter(unsigned char _type) {
    ReturnValueHelper(driver->SendCommand(TMCL_RSAP, _type, axisIndex, 0));
}

void TMCM610Motor::SetGlobalParameter(unsigned char _type, unsigned char _bank, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_SGP, _type, _bank, _value));
}

void TMCM610Motor::GlobalParameter(unsigned char _type, unsigned char _bank) {
    ReturnValueHelper(driver->SendCommand(TMCL_GGP, _type, _bank, 0));
}

void TMCM610Motor::StoreGlobalParameter(unsigned char _type, unsigned char _bank) {
    Q_UNUSED(_bank)
    ReturnValueHelper(driver->SendCommand(TMCL_STGP, _type, axisIndex, 0));
}

void TMCM610Motor::RestoreGlobalParameter(unsigned char _type, unsigned char _bank) {
    ReturnValueHelper(driver->SendCommand(TMCL_RSGP, _type, _bank, 0));
}

void TMCM610Motor::SetOutput(unsigned char _port_number, unsigned char _bank, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_SIO, _port_number, _bank, _value));
}

void TMCM610Motor::Input(unsigned char _port_number, unsigned char _bank) {
    ReturnValueHelper(driver->SendCommand(TMCL_GIO, _port_number, _bank, 0));
}

void TMCM610Motor::SetCoordinate(unsigned char _index, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_SCO, _index, axisIndex, _value));
}

void TMCM610Motor::Coordinate(unsigned char _index) {
    ReturnValueHelper(driver->SendCommand(TMCL_GCO, _index, axisIndex, 0));
}

void TMCM610Motor::CaptureCoordinate(unsigned char _index, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_CCO, _index, axisIndex, _value));
}

void TMCM610Motor::WhenErrorOccurs(int _status) {
    if (st != _status) {
        st           = _status;
        errorOccured = true;
        qCritical() << QString("motor %1 error %2").arg(QString::number(axisIndex), QString::number(_status));
        emit Status(QString("motor %1 error %2").arg(QString::number(axisIndex), QString::number(_status)));
        emit logMessage(
            LIBS::Error,
            QString("TMCM6110Motor: motor %1 error %2.").arg(QString::number(axisIndex), QString::number(_status)));
    }
}

void TMCM610Motor::WhenOK(int _returnValue) {
    if (st != _returnValue) {
        st           = _returnValue;
        errorOccured = false;
        emit Status(QString("motor %1 return %2").arg(QString::number(axisIndex), QString::number(_returnValue)));
    }
}

void TMCM610Motor::StartChecker() {
    timerCounter = moveTimeout / checkInterval;
    timer.setSingleShot(true);
    timer.setInterval(checkInterval);
    QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
    updateBreak();
}

void TMCM610Motor::StopChecker() {
    QMetaObject::invokeMethod(&timer, "stop", Qt::QueuedConnection);
    // timer.stop();
    updateBreak();
}

int TMCM610Motor::CheckPosition() {
    AxisParameter(1);
    if (axisDirection)
        currentPosition = -driver->ReturnValue(axisIndex);
    else
        currentPosition = driver->ReturnValue(axisIndex);
    return currentPosition;
}

void TMCM610Motor::Checker() {
    updateBreak();
    --timerCounter;
    int tmpReturnValue = -1;

    if (!timerCounter) {
        qCritical() << QString("motor %1 timeout").arg(axisIndex);
        emit logMessage(LIBS::Error, QString("TMCM6110Motor: motor %1 timeouted.").arg(QString::number(axisIndex)));
        StopChecker();
        return;
    }

    if (referenceSearch) {
        if (referenceStartup) {
            ReferenceSearch();
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
            return;
        }

        ReferenceStatus();
        tmpReturnValue = driver->ReturnValue(axisIndex);
        // nacteni polohy z registru trinamicu
        AxisParameter(1);
        if (errorOccured) {
            emit logMessage(LIBS::FatalError,
                            QString("TMCM: motor %1 error %2 Communication did not worked, relaunching checker.")
                                .arg(QString::number(axisIndex), QString::number(st)));
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
            return;
        }

        if (axisDirection)
            currentPosition = -driver->ReturnValue(axisIndex);
        else
            currentPosition = driver->ReturnValue(axisIndex);

        emit MicroStepsPosition(currentPosition);

        CalculateRealPosition();

        if (!tmpReturnValue) {
            isMoving        = false;
            isReferenced    = true;
            referenceSearch = false;
            StopChecker();
            if (localReference)
                localReference = false;
            else {
                emit AxisReferenced();
                driver->CheckReferenceStatus();
            }
            WriteReferenceStatus();
            ReferenceMotorStoped();
        } else {
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
        }
    } else {
        AxisParameter(3); // zjisteni stavu motoru (je v pohybu?)
        if (errorOccured) {
            emit logMessage(LIBS::FatalError,
                            QString("TMCM: motor %1 error %2 Communication did not worked, relaunching checker.")
                                .arg(QString::number(axisIndex), QString::number(st)));
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
            return;
        }

        tmpReturnValue = driver->ReturnValue(axisIndex);
        AxisParameter(1);
        if (errorOccured) {
            emit logMessage(LIBS::FatalError,
                            QString("TMCM: motor %1 error %2 Communication did not worked, relaunching checker.")
                                .arg(QString::number(axisIndex), QString::number(st)));
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
            return;
        }
        if (currentPosition == 0) {
            emit logMessage(
                LIBS::Warning,
                QString("TMCM: motor %1 claims to be on 0 position, rechecking.").arg(QString::number(axisIndex)));
            AxisParameter(3); // zjisteni stavu motoru (je v pohybu?)
            if (errorOccured) {
                emit logMessage(LIBS::FatalError,
                                QString("TMCM: motor %1 error %2 Communication did not worked, relaunching checker.")
                                    .arg(QString::number(axisIndex), QString::number(st)));
                QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
                // timer.start();
                return;
            }
            tmpReturnValue = driver->ReturnValue(axisIndex);
            AxisParameter(1);
            if (errorOccured) {
                emit logMessage(LIBS::FatalError,
                                QString("TMCM: motor %1 error %2 Communication did not worked, relaunching checker.")
                                    .arg(QString::number(axisIndex), QString::number(st)));
                QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
                // timer.start();
                return;
            }
            emit logMessage(LIBS::Warning,
                            QString("TMCM: motor %1 claims to be on %2 position, now %3.")
                                .arg(QString::number(axisIndex))
                                .arg(driver->ReturnValue(axisIndex))
                                .arg(tmpReturnValue));
        }

        if (axisDirection)
            currentPosition = -driver->ReturnValue(axisIndex);
        else
            currentPosition = driver->ReturnValue(axisIndex);

        emit MicroStepsPosition(currentPosition);

        CalculateRealPosition();
        // AxisParameter(8);
        if (!tmpReturnValue)
        // if(driver->ReturnValue(axisIndex))
        {
            isMoving = false; //??
            driver->CheckAxesStatus();
            //            Sleep(50);
            emit AxisStoped();
            StopChecker();
        } else {
            QMetaObject::invokeMethod(&timer, "start", Qt::QueuedConnection);
            // timer.start();
        }
    }
}

void TMCM610Motor::InitMotorParameters() {
    InitTCM3230();
    /*if (qobject_cast<TMCM6110DriverBase*>(driver))
        InitTCM6110();
    else
        InitTCM3230();
    // InitTCM610();*/

    InitOthers();
}

void TMCM610Motor::InitTCM610() {
    SetAxisParameter(MICROSTEPS_SRESOLUTION, microSteps); // set 64 usteps
    //< nutne nastavit nejprve divisory v tomto poradi, jinak dojde k oscilacim
    // SetAxisParameter(RAMP_DIVISOR, rampDivisor);   // nastaveni Pulse Divisor -- zvetsuje rychlost posuvu
    // SetAxisParameter(PULSE_DIVISOR, pulseDivisor); // nastaveni ramp Divisor

    SetAxisParameter(MAX_SPEED, maxSpeed);               // maximum positioning speed
    SetAxisParameter(MAX_ACCELERATION, maxAcceleration); // max acceleration
    SetAxisParameter(MAX_CURRENT, maxCurrent);           // max current mA
    SetAxisParameter(STANDBY_CURRENT, standbyCurrent);   // stand by current mA 0..1500
    //	SetAxisParameter(REFERENCE_TYPE, referenceType); //reference search type
    SetAxisParameter(REFERENCE_SPEED1, referenceSpeed_1);     // reference search speed 1
    SetAxisParameter(REFERENCE_SPEED2, referenceSpeed_2);     // reference search speed 2
    SetAxisParameter(FULL_STEP_THRESHOLD, fullStepThreshold); // full step speed threshold
}

void TMCM610Motor::InitTCM6110() {
    SetAxisParameter(MICROSTEPS_SRESOLUTION, microSteps); // set 64 usteps
    //< nutne nastavit nejprve divisory v tomto poradi, jinak dojde k oscilacim
    // SetAxisParameter(RAMP_DIVISOR, rampDivisor);   // nastaveni Pulse Divisor -- zvetsuje rychlost posuvu
    // SetAxisParameter(PULSE_DIVISOR, pulseDivisor); // nastaveni ramp Divisor

    SetAxisParameter(MAX_SPEED, maxSpeed);               // maximum positioning speed
    SetAxisParameter(MAX_ACCELERATION, maxAcceleration); // max acceleration

    int cur = maxCurrent * 255 / 1100.;
    if (cur > 255)
        cur = 255;
    SetAxisParameter(MAX_CURRENT, cur);                              // max current mA
    SetAxisParameter(STANDBY_CURRENT, standbyCurrent * 255 / 1100.); // stand by current mA 0..1500

    //	SetAxisParameter(REFERENCE_TYPE, 1); //reference search type
    if (referenceType > 128) {
        SetAxisParameter(REFERENCE_SPEED1, -maxSpeed / (pow(2., referenceSpeed_1))); // reference search speed 1
        SetAxisParameter(REFERENCE_SPEED2, -maxSpeed / (pow(2., referenceSpeed_2))); // reference search speed 2
    } else {
        SetAxisParameter(REFERENCE_SPEED1, maxSpeed / (pow(2., referenceSpeed_1))); // reference search speed 1
        SetAxisParameter(REFERENCE_SPEED2, maxSpeed / (pow(2., referenceSpeed_2))); // reference search speed 2
    }
}

void TMCM610Motor::InitTCM3230() {
    QSettings stageSettings(Config("trinamic").Default(), QSettings::defaultFormat());
    m_expanderAxis = stageSettings.value("private/stage/attAxis", -1).toInt();
    m_focuserAxis  = stageSettings.value("private/stage/focusAxis", -1).toInt();

    SetAxisParameter(MICROSTEPS_SRESOLUTION, microSteps); // set 64 usteps
    SetAxisParameter(MAX_SPEED, maxSpeed);                // maximum positioning speed
    SetAxisParameter(MAX_ACCELERATION, maxAcceleration);  // max acceleration
    SetAxisParameter(MAX_CURRENT, maxCurrent);            // max current mA
    SetAxisParameter(STANDBY_CURRENT, standbyCurrent);    // stand by current mA 0..1500
    SetAxisParameter(REFERENCE_SPEED1, referenceSpeed_1); // reference search speed 1
    SetAxisParameter(REFERENCE_SPEED2, referenceSpeed_2); // reference search speed 2
    SetAxisParameter(RIGHT_LIM_SW_POL, 1);                // invert logic state of the right limit switch
    SetAxisParameter(LEFT_LIM_SW_POL, 1);                 // invert logic state of the left limit switch
    SetAxisParameter(SWAP_LIM_SW, m_swapLimSW);           // swap limit switches

    // Disable limit switches only on expander axis
    if (m_expanderAxis != axisIndex) {
        SetAxisParameter(RIGHT_LIM_SW_DISABLE, 0); // disable right limit switch
        SetAxisParameter(LEFT_LIM_SW_DISABLE, 0);  // disable left limit switch
    }

    if (m_focuserAxis == axisIndex)
        SetAxisParameter(REFERENCE_TYPE, 2); // reference search type for focuser
    else
        SetAxisParameter(REFERENCE_TYPE, 1); // reference search type for other motors
}

bool TMCM610Motor::CheckReferenceSwitch() {
    AxisParameter(9);
    return driver->ReturnValue(axisIndex);
}

void TMCM610Motor::ReturnValueHelper(int r) {
    st = r;
    if (st == STAT_OK)
        WhenOK(driver->ReturnValue(axisIndex));
    else
        WhenErrorOccurs(st);
}

void TMCM610Motor::holdBreak() {
    if (m_hasBreak) {
        // m_breakTimer.stop();
        QMetaObject::invokeMethod(&m_breakTimer, "stop", Qt::QueuedConnection);
        switch (m_breakPolarity) {
            case breakedHigh:
                SetOutput(m_breakOutput, 2, 1);
                break;
            case breakedLow:
                SetOutput(m_breakOutput, 2, 0);
                break;
        }
        m_breakIsReleased = false;
    }
}

void TMCM610Motor::releaseBreak() {
    if (m_hasBreak) {
        QMetaObject::invokeMethod(&m_breakTimer, "start", Qt::QueuedConnection);
        // m_breakTimer.start();
        switch (m_breakPolarity) {
            case breakedHigh:
                SetOutput(m_breakOutput, 2, 0);
                break;
            case breakedLow:
                SetOutput(m_breakOutput, 2, 1);
                break;
        }
        m_breakIsReleased = true;
    }
}

void TMCM610Motor::updateBreak() {
    if (m_hasBreak) {
        QMetaObject::invokeMethod(&m_breakTimer, "start", Qt::QueuedConnection);
        // m_breakTimer.start();
    }
}

TMCMGPIO::TMCMGPIO(unsigned char _axisIndex, TrinamicController* _driver, QObject* parent)
    : MotorAxis(_axisIndex, _driver, parent) {
    driver = _driver;
}

TMCMGPIO::~TMCMGPIO() {
}

void TMCMGPIO::SetOutput(unsigned char _port_number, unsigned char _bank, int _value) {
    ReturnValueHelper(driver->SendCommand(TMCL_SIO, _port_number, _bank, _value));
}

void TMCMGPIO::Input(unsigned char _port_number, unsigned char _bank) {
    ReturnValueHelper(driver->SendCommand(TMCL_GIO, _port_number, _bank, 0));
}

void TMCMGPIO::ReturnValueHelper(int r) {
    st = r;
    if (st == STAT_OK)
        WhenOK(driver->ReturnValue(axisIndex));
    else
        WhenErrorOccurs(st);
}

void TMCMGPIO::WhenErrorOccurs(int _status) {
    if (st != _status) {
        st = _status;
        qCritical() << QString("motor %1 error %2").arg(QString::number(axisIndex), QString::number(_status));
        emit Status(QString("motor %1 error %2").arg(QString::number(axisIndex), QString::number(_status)));
        emit logMessage(
            LIBS::Error,
            QString("TMCMGPIO: motor %1 error %2.").arg(QString::number(axisIndex), QString::number(_status)));
    }
}

void TMCMGPIO::WhenOK(int _returnValue) {
    if (st != _returnValue) {
        st = _returnValue;
        emit Status(QString("motor %1 return %2").arg(QString::number(axisIndex), QString::number(_returnValue)));
    }
}
