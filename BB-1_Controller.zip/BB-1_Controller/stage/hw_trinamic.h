#ifndef HW_TRINAMIC_H
#define HW_TRINAMIC_H

#include "hw_general_axis.h"

#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QTimer>
#include <QToolButton>
#include <QVBoxLayout>

#define DRV_MOTORCOUNT 6

class TMCM610Motor;
class TMCM6110Driver;
class TMCM6110Driver485;

//!  Trida radice trinamic.
/*!
 * Reprezentuje samotny radic a obsahuje tridy vsech motoru.
 * \ingroup hardware
 */
class TrinamicController : public MotorController {
    Q_OBJECT

public:
    TrinamicController(Config _config, QObject* parent = nullptr) : MotorController(_config, parent) {
    }
    ~TrinamicController() {
    }

    // vytvori controler podle typu
    static TrinamicController* CreateDriver(QString type, Config _config, QObject* parent);

    //! navratova hodnota je status STAT_OK nebo chyba
    virtual int SendCommand(unsigned char instructionNumber,
                            unsigned char type,
                            unsigned char motorBank,
                            int value) = 0;
    //! navratove hodnoty se vraci vzdy v bank 0
    virtual int SendCommandEx(unsigned char instructionNumber,
                              unsigned char type,
                              unsigned char motorBank,
                              int value) = 0;
    //! odpoved na prikaz
    int ReturnValue(unsigned char motorBank) {
        return returnValue[motorBank];
    }
    //! posledni return bank
    int ReturnBank(unsigned char motorBank) {
        return returnBank[motorBank];
    }
    //! posledni navratova hodnota
    int ReturnStatus(unsigned char motorBank) {
        return returnStatus[motorBank];
    }

    virtual QMutex* CommMutex() = 0;

protected:
    int returnValue[DRV_MOTORCOUNT];
    unsigned char returnStatus[DRV_MOTORCOUNT];
    unsigned char returnBank[DRV_MOTORCOUNT];
};

//!  GUI nastaveni zkladnich parametru motoru trinamic.
/*!
 * \ingroup guis
 */
class Ui_MotorSettings {
public:
    QVBoxLayout* verticalLayout;
    QGroupBox* groupBox;
    QGridLayout* gridLayout;
    QLabel* label;
    QSpinBox* spinBoxAccel;
    QLabel* label_5;
    QCheckBox* checkBox;
    QLabel* label_11;
    QCheckBox* checkBox_2;
    QLabel* label_2;
    QSpinBox* spinBoxSpeed;
    QLabel* label_6;
    QSpinBox* spinBoxRefSpeed1;
    QLabel* label_3;
    QSpinBox* spinBoxCurrent;
    QLabel* label_7;
    QSpinBox* spinBoxRefSpeed2;
    QLabel* label_4;
    QSpinBox* spinBoxStandByCurrent;
    QFrame* line;
    QLabel* label_8;
    QDoubleSpinBox* doubleSpinBoxMotorStep;
    QLabel* label_9;
    QSpinBox* spinBoxSteps;
    QLabel* label_10;
    QCheckBox* checkBoxSwapLimSW;
    // QSpinBox* spinBoxFullSteps;
    // QLabel* label_13;
    // QSpinBox* spinBoxDivisor;
    // QLabel* label_12;
    // QSpinBox* spinBoxRamp;
    QToolButton* toolButtonRef;
    QCheckBox* checkBoxAutoReference;
    // QGroupBox* groupBoxBreakSettings;
    // QGridLayout* gridLayoutBreakSettings;
    // QSpinBox* spinBoxBreakOutput;
    // QLabel* labelBreakOutput;
    // QComboBox* comboBoxBreakPolarity;
    // QLabel* labelBreakPolarity;
    // QCheckBox* checkBoxHasBreak;
    QLabel* labelMicrostepping;
    QComboBox* comboboxMicrostepping;

    void setupUi(QWidget* Form) {
        verticalLayout = new QVBoxLayout(Form);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox = new QGroupBox(Form);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        spinBoxAccel = new QSpinBox(groupBox);
        spinBoxAccel->setObjectName(QString::fromUtf8("spinBoxAccel"));
        spinBoxAccel->setMaximum(2047);
        spinBoxAccel->setValue(50);

        gridLayout->addWidget(spinBoxAccel, 0, 1, 1, 1);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 0, 3, 1, 1);

        checkBox = new QCheckBox(groupBox);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 0, 4, 1, 1);

        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 1, 3, 1, 1);

        checkBox_2 = new QCheckBox(groupBox);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));

        gridLayout->addWidget(checkBox_2, 1, 4, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        spinBoxSpeed = new QSpinBox(groupBox);
        spinBoxSpeed->setObjectName(QString::fromUtf8("spinBoxSpeed"));
        spinBoxSpeed->setMinimum(0);
        spinBoxSpeed->setMaximum(100000);
        spinBoxSpeed->setValue(500);

        gridLayout->addWidget(spinBoxSpeed, 1, 1, 1, 1);

        labelMicrostepping = new QLabel(groupBox);
        labelMicrostepping->setObjectName(QString::fromUtf8("labelMicrostepping"));

        gridLayout->addWidget(labelMicrostepping, 2, 0, 1, 1);

        comboboxMicrostepping = new QComboBox(groupBox);
        comboboxMicrostepping->setObjectName(QString::fromUtf8("comboboxMicrostepping"));
        comboboxMicrostepping->clear();
        comboboxMicrostepping->insertItems(
            0, QString("1x (0);2x (1);4x (2);8x (3);16x (4);32x (5);64x (6);128x (7);256x (8)").split(";"));

        gridLayout->addWidget(comboboxMicrostepping, 2, 1, 1, 1);

        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 2, 3, 1, 1);

        spinBoxRefSpeed1 = new QSpinBox(groupBox);
        spinBoxRefSpeed1->setObjectName(QString::fromUtf8("spinBoxRefSpeed1"));
        spinBoxRefSpeed1->setMaximum(100000);
        spinBoxRefSpeed1->setValue(2);

        gridLayout->addWidget(spinBoxRefSpeed1, 2, 4, 1, 1);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 3, 0, 1, 1);

        spinBoxCurrent = new QSpinBox(groupBox);
        spinBoxCurrent->setObjectName(QString::fromUtf8("spinBoxCurrent"));
        spinBoxCurrent->setMaximum(1500);
        spinBoxCurrent->setValue(240);

        gridLayout->addWidget(spinBoxCurrent, 3, 1, 1, 1);

        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 3, 3, 1, 1);

        spinBoxRefSpeed2 = new QSpinBox(groupBox);
        spinBoxRefSpeed2->setObjectName(QString::fromUtf8("spinBoxRefSpeed2"));
        spinBoxRefSpeed2->setMaximum(100000);
        spinBoxRefSpeed2->setValue(4);

        gridLayout->addWidget(spinBoxRefSpeed2, 3, 4, 1, 1);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 4, 0, 1, 1);

        spinBoxStandByCurrent = new QSpinBox(groupBox);
        spinBoxStandByCurrent->setObjectName(QString::fromUtf8("spinBoxStandByCurrent"));
        spinBoxStandByCurrent->setMaximum(1500);
        spinBoxStandByCurrent->setValue(10);

        gridLayout->addWidget(spinBoxStandByCurrent, 4, 1, 1, 1);

        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        gridLayout->addWidget(label_10, 5, 0, 1, 1);

        checkBoxSwapLimSW = new QCheckBox(groupBox);
        checkBoxSwapLimSW->setObjectName(QString::fromUtf8("checkBoxSwapLimSW"));
        gridLayout->addWidget(checkBoxSwapLimSW, 5, 1, 1, 1);
        //        spinBoxFullSteps = new QSpinBox(groupBox);
        //        spinBoxFullSteps->setObjectName(QString::fromUtf8("spinBoxFullSteps"));
        //        spinBoxFullSteps->setMaximum(2048);
        //        spinBoxFullSteps->setValue(0);
        // gridLayout->addWidget(spinBoxFullSteps, 5, 1, 1, 1);

        line = new QFrame(groupBox);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line, 0, 2, 7, 1);

        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 4, 3, 1, 1);

        doubleSpinBoxMotorStep = new QDoubleSpinBox(groupBox);
        doubleSpinBoxMotorStep->setObjectName(QString::fromUtf8("doubleSpinBoxMotorStep"));
        doubleSpinBoxMotorStep->setMinimum(0);
        doubleSpinBoxMotorStep->setMaximum(180);
        doubleSpinBoxMotorStep->setValue(7.5);
        doubleSpinBoxMotorStep->setLocale(QLocale::English);

        gridLayout->addWidget(doubleSpinBoxMotorStep, 4, 4, 1, 1);

        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 5, 3, 1, 1);

        spinBoxSteps = new QSpinBox(groupBox);
        spinBoxSteps->setObjectName(QString::fromUtf8("SpinBoxMotorSteps"));
        spinBoxSteps->setMinimum(10);
        spinBoxSteps->setMaximum(1000);
        spinBoxSteps->setValue(200);

        gridLayout->addWidget(spinBoxSteps, 5, 4, 1, 1);

        //        label_13 = new QLabel(groupBox);
        //        label_13->setObjectName(QString::fromUtf8("label_13"));

        //        gridLayout->addWidget(label_13, 6, 0, 1, 1);

        //        spinBoxDivisor = new QSpinBox(groupBox);
        //        spinBoxDivisor->setObjectName(QString::fromUtf8("SpinBoxMotorDivisor"));
        //        spinBoxDivisor->setMinimum(0);
        //        spinBoxDivisor->setMaximum(13);
        //        spinBoxDivisor->setValue(3);

        //        gridLayout->addWidget(spinBoxDivisor, 6, 1, 1, 1);

        //        label_12 = new QLabel(groupBox);
        //        label_12->setObjectName(QString::fromUtf8("label_12"));

        //        gridLayout->addWidget(label_12, 7, 0, 1, 1);

        //        spinBoxRamp = new QSpinBox(groupBox);
        //        spinBoxRamp->setObjectName(QString::fromUtf8("SpinBoxMotorRamp"));
        //        spinBoxRamp->setMinimum(0);
        //        spinBoxRamp->setMaximum(13);
        //        spinBoxRamp->setValue(3);

        //        gridLayout->addWidget(spinBoxRamp, 7, 1, 1, 1);

        checkBoxAutoReference = new QCheckBox(groupBox);
        checkBoxAutoReference->setObjectName(QString::fromUtf8("checkBoxAutoReference"));
        gridLayout->addWidget(checkBoxAutoReference, 6, 3, 1, 1);

        toolButtonRef = new QToolButton(groupBox);
        toolButtonRef->setObjectName(QString::fromUtf8("toolButtonRef"));
        gridLayout->addWidget(toolButtonRef, 6, 4, 1, 1);

        verticalLayout->addWidget(groupBox);

        //        groupBoxBreakSettings = new QGroupBox(Form);
        //        groupBoxBreakSettings->setObjectName(QString::fromUtf8("groupBoxBreakSettings"));
        //        gridLayoutBreakSettings = new QGridLayout(groupBoxBreakSettings);
        //        gridLayoutBreakSettings->setObjectName(QString::fromUtf8("gridLayoutBreakSettings"));

        //        checkBoxHasBreak = new QCheckBox(groupBoxBreakSettings);
        //        checkBoxHasBreak->setObjectName(QString::fromUtf8("checkBoxHasBreak"));
        //        gridLayoutBreakSettings->addWidget(checkBoxHasBreak, 0, 0, 1, 2);

        //        labelBreakOutput = new QLabel(groupBoxBreakSettings);
        //        labelBreakOutput->setObjectName(QString::fromUtf8("labelBreakOutput"));
        //        gridLayoutBreakSettings->addWidget(labelBreakOutput, 1, 0, 1, 1);

        //        spinBoxBreakOutput = new QSpinBox(groupBoxBreakSettings);
        //        spinBoxBreakOutput->setObjectName(QString::fromUtf8("spinBoxBreakOutput"));
        //        spinBoxBreakOutput->setMaximum(8);
        //        spinBoxBreakOutput->setValue(3);
        //        gridLayoutBreakSettings->addWidget(spinBoxBreakOutput, 1, 1, 1, 1);

        //        labelBreakPolarity = new QLabel(groupBoxBreakSettings);
        //        labelBreakPolarity->setObjectName(QString::fromUtf8("labelBreakPolarity"));
        //        gridLayoutBreakSettings->addWidget(labelBreakPolarity, 2, 0, 1, 1);

        //        comboBoxBreakPolarity = new QComboBox(groupBoxBreakSettings);
        //        comboBoxBreakPolarity->setObjectName(QString::fromUtf8("comboBoxBreakPolarity"));
        //        comboBoxBreakPolarity->addItem(QApplication::translate("Form", "Active high"));
        //        comboBoxBreakPolarity->addItem(QApplication::translate("Form", "Active low"));
        //        gridLayoutBreakSettings->addWidget(comboBoxBreakPolarity, 2, 1, 1, 1);

        //        verticalLayout->addWidget(groupBoxBreakSettings);

        retranslateUi(Form);

    } // setupUi

    void retranslateUi(QWidget* Form) {
        Form->setWindowTitle(QApplication::translate("Form", "Form", nullptr));
        groupBox->setTitle(QApplication::translate("Form", "motor settings", nullptr));
        label->setText(QApplication::translate("Form", "acceleration", nullptr));
        label_5->setText(QApplication::translate("Form", "RFS direction", nullptr));
        label_11->setText(QApplication::translate("Form", "axis direction", nullptr));
        checkBox->setText(QApplication::translate("Form", "+/-", nullptr));
        checkBox_2->setText(QApplication::translate("Form", "+/-", nullptr));
        label_2->setText(QApplication::translate("Form", "speed", nullptr));
        label_6->setText(QApplication::translate("Form", "RFS speed 1", nullptr));
        label_3->setText(QApplication::translate("Form", "current", nullptr));
        spinBoxCurrent->setSuffix(QApplication::translate("Form", " mA", nullptr));
        label_7->setText(QApplication::translate("Form", "RFS speed 2", nullptr));
        label_4->setText(QApplication::translate("Form", "standby current", nullptr));
        spinBoxStandByCurrent->setSuffix(QApplication::translate("Form", " mA", nullptr));
        label_8->setText(QApplication::translate("Form", "motor step", nullptr));
        doubleSpinBoxMotorStep->setSuffix(QApplication::translate("Form", "\302\260", nullptr));
        label_9->setText(QApplication::translate("Form", "steps per revolution", nullptr));
        label_10->setText(QApplication::translate("Form", "swap limit switches", nullptr));
        checkBoxSwapLimSW->setText(QApplication::translate("Form", "swap", nullptr));
        // label_10->setText(QApplication::translate("Form", "full step speed threshold", nullptr));
        // label_13->setText(QApplication::translate("Form", "pulse divisor", 0));
        // label_12->setText(QApplication::translate("Form", "ramp divisor", 0));
        checkBoxAutoReference->setText(QApplication::translate("Form", "Reference on startup", nullptr));
        toolButtonRef->setText(QApplication::translate("Form", "Reference Search", nullptr));
        // groupBoxBreakSettings->setTitle(QApplication::translate("Form", "Break settings", 0));
        // labelBreakOutput->setText(QApplication::translate("Form", "Break output:", 0));
        // labelBreakPolarity->setText(QApplication::translate("Form", "Break polarity", 0));
        // checkBoxHasBreak->setText(QApplication::translate("Form", "Has break", 0));
        labelMicrostepping->setText(QApplication::translate("Form", "microstepping", nullptr));
    } // retranslateUi
};

//!  Trida ovladani jednoho motoru na karte trinamic 610 i 6110.
/*!
 * \ingroup hardware
 */
class TMCMGPIO : public MotorAxis {
    Q_OBJECT

public:
    TMCMGPIO(unsigned char _axisIndex, TrinamicController* _driver, QObject* parent = nullptr);
    ~TMCMGPIO();

    //! Generuje ovladaci GUI
    void SetupConfigGui(QWidget* _toSet) override {
        Q_UNUSED(_toSet);
        return;
    }

    TrinamicController* Driver() {
        return driver;
    }

    void SetOutput(unsigned char _port_number, unsigned char _bank, int _value);
    void Input(unsigned char _port_number, unsigned char _bank);

    //! vraci aktualni stav navratove hodoty funkci
    int LastError() {
        return st;
    }

signals:
    void Status(QString _value);

protected:
    //! dojde k ni pri chybe pri odelani packetu
    virtual void WhenErrorOccurs(int _status);
    //! pokud odeslani probehne v poradku
    virtual void WhenOK(int _returnValue);

    //! trida reprezentuje radic motoru trinamic
    TrinamicController* driver;

    //! status operaci, navratova hodnota low level funkci
    int st;

    enum COMMANDS {
        // Opcodes of all TMCL commands that can be used in direct mode
        TMCL_ROR  = 1,
        TMCL_ROL  = 2,
        TMCL_MST  = 3,
        TMCL_MVP  = 4,
        TMCL_SAP  = 5,
        TMCL_GAP  = 6,
        TMCL_STAP = 7,
        TMCL_RSAP = 8,
        TMCL_SGP  = 9,
        TMCL_GGP  = 10,
        TMCL_STGP = 11,
        TMCL_RSGP = 12,
        TMCL_RFS  = 13,
        TMCL_SIO  = 14,
        TMCL_GIO  = 15,
        TMCL_SCO  = 30,
        TMCL_GCO  = 31,
        TMCL_CCO  = 32
    };

    enum STATS {
        STAT_OK = 100,
    };

private:
    virtual bool IsReferenced() override {
        return true;
    }
    virtual bool IsMoving() override {
        return false;
    }

    void ReturnValueHelper(int r);
};

//!  Trida ovladani jednoho motoru na karte trinamic 610 i 6110.
/*!
 * \ingroup hardware
 */
class TMCM610Motor : public MotorAxis {
    Q_OBJECT

public:
    TMCM610Motor(unsigned char _axisIndex, TrinamicController* _driver, QObject* parent = nullptr);
    ~TMCM610Motor();

    //! Generuje ovladaci GUI
    void SetupConfigGui(QWidget* _toSet) override;

    //! vraci true pokud je motor referencovany
    bool IsReferenced() override {
        return isReferenced;
    }

    //! nacte informaci zregistru radice a vrati true, jestli byl motor referencovany pri predchozim spusteni
    bool ReadReferenceStatus();

    //! ulozi informaci do zregistru radice o stavu reference
    void WriteReferenceStatus();

    //! true pokud je motor v pohybu
    bool IsMoving() override {
        return isMoving;
    }

    //! spousti rotaci vpravo danou rychlosti
    void RotateRight(int _velocity);
    //! spousti rotaci vlevo danou rychlosti
    void RotateLeft(int _velocity);
    //! posune motor na polohu _position v uStepech a typ MVP_ABS, nebo MVP_REL
    void MoveToPosition(unsigned char _type, int _position);

    //! Zastavi hledani reference
    void ReferenceStop();
    //! Dotaz na stav reference
    void ReferenceStatus();

    //! soucasna poloha v uSteps
    int CurrentPosition() {
        return currentPosition;
    }

    //! nacte aktualni polohu
    int CheckPosition();

    //! pocet usteps nutnych k zastaveni pohybu
    int UStepsToStop(int _velocity) {
        return _velocity * _velocity * (1 << rampDivisor) / ((1 << pulseDivisor) * maxAcceleration * 16);
    }

    //!  SpeedFactor() * velocity = speed in real units "uSteps per Second"
    double SpeedFactor() {
        return 16e6 / (1 << (pulseDivisor + 16));
    }

    //! RotationFactor() * velocity = speed in real units "rot per second"
    double RotationFactor() {
        return SpeedFactor() / UStepsPerRot();
    }

    //! prevod polohy v potomcich na usteps
    virtual int DesignedPositionToUSteps(double _value) = NULL;

    //! nastavuje parametr motoru
    void SetAxisParameter(unsigned char _type, int _value);

    //! vraci hodnotu paraqmetru motoru
    void AxisParameter(unsigned char _type);
    void StoreAxisParameter(unsigned char _type);
    void RestoreAxisParameter(unsigned char _type);
    void SetGlobalParameter(unsigned char _type, unsigned char _bank, int _value);
    void GlobalParameter(unsigned char _type, unsigned char _bank);
    void StoreGlobalParameter(unsigned char _type, unsigned char _bank);
    void RestoreGlobalParameter(unsigned char _type, unsigned char _bank);

    void SetOutput(unsigned char _port_number, unsigned char _bank, int _value);
    void Input(unsigned char _port_number, unsigned char _bank);
    void SetCoordinate(unsigned char _index, int _value);
    void Coordinate(unsigned char _index);
    void CaptureCoordinate(unsigned char _index, int _value);

    int MaxAcceleration() {
        return maxAcceleration;
    }
    int MaxSpeed() {
        return maxSpeed;
    }
    int MaxCurrent() {
        return maxCurrent;
    }
    int StandbyCurrent() {
        return standbyCurrent;
    }
    int ReferenceType() {
        return referenceType;
    }
    int ReferenceSpeed1() {
        return referenceSpeed_1;
    }
    int ReferenceSpeed2() {
        return referenceSpeed_2;
    }
    //! velikost kroku motoru
    double StepDegrees() {
        return stepDeg;
    }
    //! pocet kroku na otacku
    double StepsPerRot() {
        return 360. / stepDeg;
    }
    //! pocet mikro kroku na otacku
    double UStepsPerRot() {
        return StepsPerRot() * UStepsPerStep();
    }

    //! smer osy
    bool Direction() {
        return axisDirection;
    }
    int PulseDivisor() {
        return pulseDivisor;
    }
    int RampDivisor() {
        return rampDivisor;
    }
    double UStepsPerStep() {
        return exp2(microSteps);
    }

    //! vraci aktualni stav navratove hodoty funkci
    int LastError() {
        return st;
    }

    //! jmeno motoru
    QByteArray Name() {
        return stageName;
    }

    bool AutoReference() {
        return m_autoReference;
    }

    bool getSwapLimSW() {
        return m_swapLimSW;
    }

    enum MVP {
        // Options for MVP commandds
        MVP_ABS   = 0,
        MVP_REL   = 1,
        MVP_COORD = 2
    };

    enum breakPolarity {
        breakedHigh,
        breakedLow,
    };

public slots:
    //! odesle nastaveni do ridici jednotky
    void InitMotorParameters();
    //! spusti hledani reference
    void ReferenceSearch(bool overrideReferenceStatus = false);
    //! zastavi motor
    void MotorStop();

    void holdBreak();
    void updateBreak();
    void releaseBreak();

    void SetMaxAcceleration(int _value) {
        maxAcceleration = _value;
    }
    void SetMaxAccelerationHard(int _value) {
        maxAcceleration = _value;
        SetAxisParameter(TMCM610Motor::MAX_ACCELERATION, maxAcceleration);
    }
    void SetMaxSpeed(int _value) {
        maxSpeed = _value;
    }
    void SetMaxSpeedHard(int _value) {
        maxSpeed = _value;
        SetAxisParameter(TMCM610Motor::MAX_SPEED, maxSpeed);
    }
    void SetMaxCurrent(int _value) {
        maxCurrent = _value;
    }
    void SetStandbyCurrent(int _value) {
        standbyCurrent = _value;
    }
    void SetReferenceType(int _value) {
        referenceType = _value;
    }
    void SetReferenceDirection(bool _value) {
        if (_value)
            referenceType |= (1 << 7);
        else
            referenceType &= ~(1 << 7);
    }
    void SetReferenceSpeed1(int _value) {
        referenceSpeed_1 = _value;
    }
    void SetReferenceSpeed2(int _value) {
        referenceSpeed_2 = _value;
    }
    void SetFullStepThreshold(int _value) {
        fullStepThreshold = _value;
    }
    void SetMotorStep(double _value) {
        stepDeg = _value;
        ui.spinBoxSteps->setValue(360. / stepDeg);
    }
    void SetMotorStepsPerRot(int _value) {
        stepDeg = 360. / _value;
        ui.doubleSpinBoxMotorStep->setValue(stepDeg);
    }
    void SetName(QByteArray _name) {
        stageName = _name;
    }
    void SetDirection(bool _value) {
        axisDirection = _value;
    }
    void SetPulseDivisor(int _value) {
        pulseDivisor = _value;
    }
    void SetPulseDivisorHard(int _value) {
        pulseDivisor = _value;
        SetAxisParameter(TMCM610Motor::PULSE_DIVISOR, pulseDivisor);
    }
    void SetRampDivisor(int _value) {
        rampDivisor = _value;
    }
    void SetRampDivisorHard(int _value) {
        rampDivisor = _value;
        SetAxisParameter(TMCM610Motor::RAMP_DIVISOR, rampDivisor);
    }
    void SetMicroSteps(int _value) {
        microSteps = _value;
    }

    void SetHasBreak(bool has) {
        m_hasBreak = has;
    }

    bool IsBreakReleased() {
        if (m_hasBreak)
            return m_breakIsReleased;
        return true;
    }

    void SetBreakOutput(int output) {
        m_breakOutput = output;
    }

    void SetBreakPolarity(int pol) {
        switch (pol) {
            case 0:
                m_breakPolarity = breakedHigh;
                break;
            case 1:
                m_breakPolarity = breakedLow;
                break;
        }
    }

    void SetAutoReference(bool autoRef) {
        m_autoReference = autoRef;
    }

    void setSwapLimSW(bool swap) {
        m_swapLimSW = swap;
    }

signals:
    void Status(QString _value);
    //! aktualni poloha v usteps
    void MicroStepsPosition(int _usteps);

protected:
    //! dojde k ni pri chybe pri odelani packetu
    virtual void WhenErrorOccurs(int _status);
    //! pokud odeslani probehne v poradku
    virtual void WhenOK(int _returnValue);
    //! pri ukonceni hledani reference
    virtual void ReferenceMotorStoped() {
    }
    //! vola se v InitMotorParameters pro nastaveni spoecifickych parametru
    virtual void InitOthers() {
    }
    //! nastavuje defaultni parametry v InitMotorParameters(), lze pretizit v pripade  jinych typu kontroleru
    void InitTCM610();
    void InitTCM6110();
    void InitTCM3230();
    //! vypocte realnou polohu z usteps napriklad mm v nekterem potomkovi
    virtual void CalculateRealPosition() {
    }

    int maxAcceleration;
    int maxSpeed;
    int maxCurrent;
    int standbyCurrent;
    int referenceType;
    int referenceSpeed_1;
    int referenceSpeed_2;
    int fullStepThreshold;
    //! krok motoru ve stupnich
    double stepDeg;
    int microSteps;
    bool axisDirection;
    int pulseDivisor;
    int rampDivisor;
    //! implementace brzdy
    bool m_hasBreak;
    //! polarita zavreni brzdy
    breakPolarity m_breakPolarity;
    //! cislo vystupniho portu brzdy
    char m_breakOutput;
    //! stav brzdy
    bool m_breakIsReleased = {false};
    //! bezpecny cas pro brzdu
    int m_breakStartMs = {150};
    QTimer m_breakTimer;

    //! automaticke hledani reference
    bool m_autoReference;

    bool m_swapLimSW;

    QByteArray stageName;

    //! index motoru ktery trida obsluhuje
    // unsigned char axisIndex;
    //! trida reprezentuje radic motoru trinamic
    TrinamicController* driver;

    Ui_MotorSettings ui;

    bool isMoving, isReferenced;
    //! true pokud se hleda reference
    bool referenceSearch;
    //! true pokud je treba nejdrive prejet na spinac pred hledanim reference
    bool referenceStartup;
    //! timeout pro cekani na nalezeni reference nebo ukonceni pohybu
    int moveTimeout;
    //! ms po kterych se testuje zastaveni motoru
    int checkInterval;
    //! = moveTimeout / checkInterval pocitadlo pro timer
    int timerCounter;

    QTimer timer;
    //! zapne testovani stavu motoru
    void StartChecker();
    //! vypne testovani stavu motoru
    void StopChecker();

    //! poloha v usteps nactena z trinamicu
    int currentPosition;
    //! status operaci, navratova hodnota low level funkci
    int st;
    bool errorOccured;
    //! true pri heldani reference pres konfiguraci, zabrani emisi signalu referenced
    bool localReference;

    //! vrati stav referencniho spinace
    bool CheckReferenceSwitch();

public:
    enum REGS {
        MAX_SPEED            = 4,
        MAX_ACCELERATION     = 5,
        MAX_CURRENT          = 6,
        STANDBY_CURRENT      = 7,
        RIGHT_LIM_SW_DISABLE = 12,
        LEFT_LIM_SW_DISABLE  = 13,
        SWAP_LIM_SW          = 14,
        RIGHT_LIM_SW_POL     = 24,
        LEFT_LIM_SW_POL      = 25,

        REFERENCE_TYPE         = 193,
        REFERENCE_SPEED1       = 194,
        REFERENCE_SPEED2       = 195,
        FULL_STEP_THRESHOLD    = 211,
        RAMP_DIVISOR           = 153,
        PULSE_DIVISOR          = 154,
        MICROSTEPS_SRESOLUTION = 140
    };

protected:
    enum COMMANDS {
        // Opcodes of all TMCL commands that can be used in direct mode
        TMCL_ROR  = 1,
        TMCL_ROL  = 2,
        TMCL_MST  = 3,
        TMCL_MVP  = 4,
        TMCL_SAP  = 5,
        TMCL_GAP  = 6,
        TMCL_STAP = 7,
        TMCL_RSAP = 8,
        TMCL_SGP  = 9,
        TMCL_GGP  = 10,
        TMCL_STGP = 11,
        TMCL_RSGP = 12,
        TMCL_RFS  = 13,
        TMCL_SIO  = 14,
        TMCL_GIO  = 15,
        TMCL_SCO  = 30,
        TMCL_GCO  = 31,
        TMCL_CCO  = 32
    };

    enum CTRL {
        // Opcodes of TMCL control functions (to be used to run or abort a TMCL program in the module)
        TMCL_APPL_STOP  = 128,
        TMCL_APPL_RUN   = 129,
        TMCL_APPL_RESET = 131
    };

    enum RFS {
        // Options for RFS command
        RFS_START  = 0,
        RFS_STOP   = 1,
        RFS_STATUS = 2
    };

    enum STATS {
        STAT_OK = 100,
    };

private:
    void ReturnValueHelper(int r);

private:
    int m_expanderAxis = -1;
    int m_focuserAxis  = -1;

private slots:
    //! provede testovani stavu motoru
    void Checker();
    //! reference pouze tohoto motoru
    void FindLocalReference();
};

class TMCM6110DriverBase : public TrinamicController {
    Q_OBJECT

public:
    TMCM6110DriverBase(Config _config, QObject* parent = nullptr)
        : TrinamicController(_config, parent), moduleAddress(1) {
    }
    ~TMCM6110DriverBase() {
    }

    int ModuleAddress() {
        return moduleAddress;
    }

    //! navratova hodnota je status STAT_OK nebo chyba
    int SendCommand(unsigned char instructionNumber, unsigned char type, unsigned char motorBank, int value) override;
    int SendCommandEx(unsigned char instructionNumber, unsigned char type, unsigned char motorBank, int value) override;

    QMutex* CommMutex() {
        return &m_commMutex;
    }
public slots:
    void SetModuleAddress(int address) {
        moduleAddress = address;
    }

private:
    unsigned char CheckSum(QByteArray _command);
    unsigned char moduleAddress;
    static QMutex m_commMutex;
};

//!  Trida radice TMCM-6110 COMport.
/*!
 * \ingroup hardware
 */
class TMCM6110Driver : public TMCM6110DriverBase {
    Q_OBJECT

public:
    TMCM6110Driver(Config _config, QObject* parent);
    ~TMCM6110Driver();

    SerialPort* Port() {
        return (SerialPort*)port;
    }
};

class TMCM6110Driver485 : public TMCM6110DriverBase {
    Q_OBJECT

public:
    TMCM6110Driver485(Config _config, QObject* parent);
    ~TMCM6110Driver485();

    RS485Port* Port() {
        return (RS485Port*)port;
    }
};

#endif
