#ifndef LIBSATTENUATOR_H
#define LIBSATTENUATOR_H

#include "hw_linearAxis.h"
#include <QObject>

class LibsAttenuator : public LinearAxis {
    Q_OBJECT
public:
    explicit LibsAttenuator(unsigned char _motorIndex, TrinamicController* _driver, QObject* parent);
    ~LibsAttenuator();
    void SetupConfigGui(QWidget* _toSet);
signals:

public slots:
};

#endif // LIBSATTENUATOR_H
