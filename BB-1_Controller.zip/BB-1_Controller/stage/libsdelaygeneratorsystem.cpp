#include "libsdelaygeneratorsystem.h"
#include <QDebug>

LibsDelayGeneratorSystem::LibsDelayGeneratorSystem(TrinamicController* tmcmController,
                                                   unsigned char address,
                                                   QObject* parent)
    : TMCMGPIO(address, tmcmController, parent) {
    m_address    = address;
    m_controller = tmcmController;
    QSettings settings(m_controller->ConfigPrefix().Default(), QSettings::defaultFormat());
    m_address      = settings.value(m_controller->ConfigPrefix().ConfigPrefix() + "/mdriver_485id", address).toInt();
    m_deviceName   = settings.value(QString("customDeviceName"), QString()).toString();
    m_chanNames[0] = settings.value(QString("customChan1Name"), QString("Channel A")).toString();
    m_chanNames[1] = settings.value(QString("customChan2Name"), QString("Channel B")).toString();
    m_chanNames[2] = settings.value(QString("customChan3Name"), QString("Channel C")).toString();
    m_chanNames[3] = settings.value(QString("customChan4Name"), QString("Channel D")).toString();
    m_autoInit     = settings.value(QString("AutoStart"), false).toBool();
}

LibsDelayGeneratorSystem::~LibsDelayGeneratorSystem() {
}

QString LibsDelayGeneratorSystem::baToHex(QByteArray ba) {
    QString str;
    for (int i = 0; i < ba.length(); i++) {
        //        if(QChar::fromLatin1(ba.at(i)).isPrint()){
        //            str.append(QString("'%1', ").arg((QChar)ba.at(i)));
        //        }else{
        str.append(QString("0x%1, ").arg((char)ba.at(i) & 0xff, (int)2, (int)16, (QChar)'0'));
        //        }
    }
    str.remove(str.size() - 2, 2);
    return str;
}

unsigned char LibsDelayGeneratorSystem::calculateCheckSum(QByteArray command) {
    unsigned char check = 0;
    for (int i = 0; i < 8; i++)
        check += (unsigned char)command.at(i);
    return check;
}

QByteArray LibsDelayGeneratorSystem::sendSCPICommand(QByteArray command) {
    QMutexLocker guard(m_controller->CommMutex());
    FT_STATUS error = 0xfffff;
    /*    if(!m_controller->Port()->IsInitialised()){
            emit sendDebugMessage(LIBS::Error,QString("%1: Port is not initialized").arg(getDeviceName()));
            return QByteArray();
        }
    */
    if (command.isEmpty() || command.length() <= 0) {
        emit updateSCPIsendingProgress(QString("Invalid SCPI command request"));
        return QByteArray();
    }
    emit updateSCPIsendingProgress(QString("Sending SCPI command \"%1\"").arg(QString::fromLocal8Bit(command)));
    if (command.size() <= 12) {
        //        emit updateSCPIsendingProgress(QString("Command is short (%1)<=12, appending zeroes to 12 byte
        //        fill.").arg(command.size()));
        while (command.size() < 12)
            command.append('\0');
        //        emit updateSCPIsendingProgress(QString("Refined command is \"%1\".").arg(baToHex(command)));
        for (int i = 0; i < 5; i++) {
            QByteArray packet(9, 0);
            packet[0] = m_address; // module adress
            packet[1] = 0x43;
            packet.replace(2, 6, command.mid(0, 6), 6);
            packet[8] = calculateCheckSum(packet);
            emit updateSCPIsendingProgress(QString("Sending init TRINAMIC packet: %1.").arg(baToHex(packet)));
            /*        if(!m_controller->Port()->IsInitialised()){
                        emit sendDebugMessage(LIBS::Error,QString("%1: Port is not initialized").arg(getDeviceName()));
                        return QByteArray();
                    }
            */
            error = m_controller->Port()->TxPacket(packet);
            if (error != FT_OK) {
                //                emit updateSCPIsendingProgress(QString("Sending init TRINAMIC packet failed with code
                //                %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Writing to 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(i + 1));
                //                continue;
                //                return QByteArray();
            }
            if ((error = m_controller->Port()->RxPacketLength(9)) == FT_OK) {
                packet = m_controller->Port()->GetRxPacket();
                //                emit updateSCPIsendingProgress(QString("Init TRINAMIC packet returned
                //                %1.").arg(baToHex(packet)));
                break;
            } else {
                //                emit updateSCPIsendingProgress(QString("Response for first TRINAMIC packet failed with
                //                code %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Reading from 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(i + 1));
                //                continue;
                //                return QByteArray();
            }
        }
        //            emit updateSCPIsendingProgress(QString("Sending init TRINAMIC packet ok (%1).").arg(error));

        for (int i = 0; i < 5; i++) {
            QByteArray packet(9, 0);
            packet[0] = m_address; // module adress
            packet[1] = 0x45;
            packet.replace(2, 6, command.mid(6, 6), 6);
            packet[8] = calculateCheckSum(packet);
            //            emit updateSCPIsendingProgress(QString("Sending finish TRINAMIC packet:
            //            %1.").arg(baToHex(packet)));
            error = m_controller->Port()->TxPacket(packet);
            if (error != FT_OK) {
                //                emit updateSCPIsendingProgress(QString("Sending finish TRINAMIC packet failed with
                //                code %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Writing to 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(i + 1));
                //                continue;
                //              return QByteArray();

            } else {
                break;
            }
        }
    } else {
        emit updateSCPIsendingProgress(QString("Command is long (%1)>12, appending zeroes to nearest 6 multiple (%2)")
                                           .arg(command.size())
                                           .arg((command.size() / 6 + 1) * 6));
        while (command.size() % 6)
            command.append('\0');
        emit updateSCPIsendingProgress(QString("Refined command is \"%1\".").arg(baToHex(command)));
        for (int e = 0; e < 5; e++) {
            QByteArray packet(9, 0);
            packet[0] = m_address; // module adress
            packet[1] = 0x43;
            packet.replace(2, 6, command.mid(0, 6), 6);
            packet[8] = calculateCheckSum(packet);
            //            emit updateSCPIsendingProgress(QString("Sending init TRINAMIC packet:
            //            %1.").arg(baToHex(packet)));
            if (!m_controller->Port()->IsInitialised()) {
                emit sendDebugMessage(LIBS::Error, QString("%1: Port is not initialized").arg(getDeviceName()));
                return QByteArray();
            }
            error = m_controller->Port()->TxPacket(packet);
            if (error != FT_OK) {
                //                emit updateSCPIsendingProgress(QString("Sending init TRINAMIC packet failed with code
                //                %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Writing to 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(e + 1));
                continue;
                //              return QByteArray();
            }
            if ((error = m_controller->Port()->RxPacketLength(9)) == FT_OK) {
                packet = m_controller->Port()->GetRxPacket();
                //                emit updateSCPIsendingProgress(QString("Init TRINAMIC packet returned
                //                %1.").arg(baToHex(packet)));
            } else {
                //                emit updateSCPIsendingProgress(QString("Response for first TRINAMIC packet failed with
                //                code %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Reading from 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(e + 1));
                continue;
                //              return QByteArray();
            }
            bool failed = false;
            for (int i = 6; i < command.size() - 6; i += 6) {
                packet    = QByteArray(9, 0);
                packet[0] = m_address; // module adress
                packet[1] = 0x44;
                packet.replace(2, 6, command.mid(i, 6), 6);
                packet[8] = calculateCheckSum(packet);
                //                emit updateSCPIsendingProgress(QString("Sending middle TRINAMIC packet:
                //                %1.").arg(baToHex(packet)));
                error = m_controller->Port()->TxPacket(packet);
                if (error != FT_OK) {
                    //                    emit updateSCPIsendingProgress(QString("Sending middle TRINAMIC packet failed
                    //                    with code %1.").arg(error));
                    emit sendDebugMessage(LIBS::Error, QString("%1: Writing to 485 failed.").arg(getDeviceName()));
                    //                    emit sendDebugMessage(LIBS::Warning,QString("Sending DDG packet failed,
                    //                    retrying, attemp %1/5").arg(e+1));
                    failed = true;
                    break;
                    //              return QByteArray();
                }
                if ((error = m_controller->Port()->RxPacketLength(9)) == FT_OK) {
                    packet = m_controller->Port()->GetRxPacket();
                    emit updateSCPIsendingProgress(QString("Middle TRINAMIC packet returned %1.").arg(baToHex(packet)));
                } else {
                    emit updateSCPIsendingProgress(
                        QString("Response for middle TRINAMIC packet failed with code %1.").arg(error));
                    emit sendDebugMessage(LIBS::Error, QString("%1: Reading from 485 failed.").arg(getDeviceName()));
                    //                    emit sendDebugMessage(LIBS::Warning,QString("Sending DDG packet failed,
                    //                    retrying, attemp %1/5").arg(e+1));
                    failed = true;
                    break;
                    //              return QByteArray();
                }
            }
            if (failed)
                continue;
            packet    = QByteArray(9, 0);
            packet[0] = m_address; // module adress
            packet[1] = 0x45;
            packet.replace(2, 6, command.mid(command.size() - 6, 6), 6);
            packet[8] = calculateCheckSum(packet);
            emit updateSCPIsendingProgress(QString("Sending finish TRINAMIC packet: %1.").arg(baToHex(packet)));
            error = m_controller->Port()->TxPacket(packet);
            if (error != FT_OK) {
                emit updateSCPIsendingProgress(
                    QString("Sending finish TRINAMIC packet failed with code %1.").arg(error));
                emit sendDebugMessage(LIBS::Error, QString("%1: Writing to 485 failed.").arg(getDeviceName()));
                emit sendDebugMessage(LIBS::Warning,
                                      QString("Sending DDG packet failed, retrying, attemp %1/5").arg(e + 1));
                continue;
                //              return QByteArray();
            }
            break;
        }
    }

    if ((error = m_controller->Port()->RxPacketLength(9)) == FT_OK) {
        QByteArray packet(9, 0);
        packet = m_controller->Port()->GetRxPacket();
        emit updateSCPIsendingProgress(QString("Finish TRINAMIC packet returned %1.").arg(baToHex(packet)));
        if (packet.at(2) == 1) {
            QByteArray response;
            while (packet.at(2) != 3) {
                emit updateSCPIsendingProgress(QString("Awaiting more TRINAMIC packets."));
                response.append(packet.mid(4, 4));
                if ((error = m_controller->Port()->RxPacketLength(9)) != FT_OK) {
                    emit updateSCPIsendingProgress(
                        QString("Response for finish TRINAMIC packet failed with code %1.").arg(error));
                    emit sendDebugMessage(LIBS::Error, QString("%1: Reading from 485 failed.").arg(getDeviceName()));
                    return QByteArray();
                }
                packet = m_controller->Port()->GetRxPacket();
                emit updateSCPIsendingProgress(QString("Finish TRINAMIC packet returned %1.").arg(baToHex(packet)));
            }
            //            emit updateSCPIsendingProgress(QString("Full SCPI response is %1.").arg(baToHex(response)));
            emit updateSCPIsendingProgress(
                QString("Full SCPI response is \"%1\".").arg(QString::fromLocal8Bit(response)));
            return response;
        } else {
            //            emit updateSCPIsendingProgress(QString("Full SCPI response is
            //            %1.").arg(baToHex(packet.mid(4,4))));
            emit updateSCPIsendingProgress(
                QString("Full SCPI response is \"%1\".").arg(QString::fromLocal8Bit(packet.mid(4, 4))));
            return packet.mid(4, 4);
        }
    } else {
        //        emit updateSCPIsendingProgress(QString("Response for finish TRINAMIC packet failed with code
        //        %1.").arg(error));
        emit sendDebugMessage(LIBS::Error,
                              QString("%1: Reading from 485 failed. Err %2").arg(getDeviceName()).arg(error));
        return QByteArray();
    }

    return QByteArray();
}

bool LibsDelayGeneratorSystem::parseSCPIok(QByteArray response) {
    if (response.isEmpty())
        return false;
    //    qDebug() << "LibsDelayGeneratorSystem::parseSCPIok " << response;
    if (response.lastIndexOf("ok") >= 0) {
        response.clear();
        return true;
    }
    response.clear();
    return false;
}

int LibsDelayGeneratorSystem::parseSCPIint(QByteArray response, bool* ok) {
    QLocale cLoc = QLocale::c();
    int conv     = -1;
    if (!response.isNull() && !response.isEmpty()) {
        conv = cLoc.toInt(QString::fromLocal8Bit(response), ok);
    } else {
        ok[0] = false;
    }
    return conv;
}

int LibsDelayGeneratorSystem::parseSCPIstate(QByteArray response, bool* ok) {
    int conv = -1;
    ok[0]    = false;
    if (!response.isNull() && !response.isEmpty()) {
        QString resp = QString::fromLocal8Bit(response).trimmed();
        if (resp == QString("ON")) {
            ok[0] = true;
            conv  = 1;
        } else if (resp == QString("OFF")) {
            ok[0] = true;
            conv  = 0;
        } else {
            ok[0] = false;
        }
    } else {
        ok[0] = false;
    }
    return conv;
}

double LibsDelayGeneratorSystem::parseSCPIdouble(QByteArray response, bool* ok) {
    QLocale cLoc = QLocale::c();
    double conv  = -1.0;
    if (!response.isNull() && !response.isEmpty()) {
        conv = cLoc.toDouble(QString::fromLocal8Bit(response), ok);
    } else {
        ok[0] = false;
    }
    return conv;
}

void LibsDelayGeneratorSystem::setChannelMode(char chan, int mode) {
    if (chan >= 0 && chan <= 4) {
        if (mode >= 0 && mode <= 3) {
            if (mode != m_chanModes[chan]) {
                setChannelEnabled(0, false);
                bool _ok = false;
                if (chan == 0)
                    _ok = parseSCPIok(
                        sendSCPICommand(QString(":PULSE%1:MODE %2").arg((unsigned int)chan).arg(mode).toLocal8Bit()));
                else
                    _ok = parseSCPIok(
                        sendSCPICommand(QString(":PULSE%1:CMODE %2").arg((unsigned int)chan).arg(mode).toLocal8Bit()));
                if (_ok) {
                    m_chanModes[chan] = mode;
                    m_parameters.insert(QString("Chan%1Mode").arg((unsigned int)chan), (int)mode);
                } else {
                    emit sendDebugMessage(LIBS::Error,
                                          tr("Unable to set channel %1 to mode %2.").arg((unsigned int)chan).arg(mode));
                }
            } else {
                emit sendDebugMessage(LIBS::Info,
                                      tr("Channel %1 already in mode %2, ignoring.").arg((unsigned int)chan).arg(mode));
                return;
            }
        } else {
            emit sendDebugMessage(LIBS::Warning, tr("Invalid pulse mode %1.").arg((unsigned int)mode));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, QString("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelMode(chan);
}

void LibsDelayGeneratorSystem::updateChannelMode(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok  = false;
        int mode = -1;
        if (chan == 0)
            mode = parseSCPIint(sendSCPICommand(QString(":PULSE%1:MODE?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        else
            mode = parseSCPIint(sendSCPICommand(QString(":PULSE%1:CMODE?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            if (mode >= 0 && mode <= 3) {
                m_chanModes[chan] = mode;
                m_parameters.insert(QString("Chan%1Mode").arg((unsigned int)chan), (int)mode);
                emit channelModeChanged(chan, mode);
            } else {
                sendDebugMessage(LIBS::Error, tr("Invalid channel %1 mode %2.").arg((unsigned int)chan).arg(mode));
                emit channelModeChanged(chan, m_chanModes[chan]);
            }
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 mode.").arg((unsigned int)chan));
            emit channelModeChanged(chan, m_chanModes[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelEnabled(char chan, bool enabled) {
    //    emit channelEnabledChanged(chan,enabled);
    //    return;
    if (chan >= 0 && chan < 5) {
        if (m_chanEnabled[chan] == enabled) {
            emit sendDebugMessage(
                LIBS::Warning,
                tr("Channel %1 already %2").arg((unsigned int)chan).arg(enabled ? tr("enabled") : tr("disabled")));
            return;
        }
        bool _ok = false;
        _ok      = parseSCPIok(sendSCPICommand(
            QString(":PULSE%1:STATE %2").arg((unsigned int)chan).arg(enabled ? "1" : "0").toLocal8Bit()));
        if (_ok) {
            //            m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
            m_chanEnabled[chan] = enabled;
            m_parameters.insert(QString("Chan%1Enabled").arg((unsigned int)chan), enabled);
            emit channelEnabledChanged(chan, enabled);
        } else {
            emit sendDebugMessage(
                LIBS::Error,
                tr("Unable to %1 channel %2.").arg(enabled ? tr("enable") : tr("disable")).arg((unsigned int)chan));
        }
        //        updateChannelEnabled(chan);
    }
    /*    else if(chan == 0){
            if(m_chanEnabled[chan]==enabled){
                emit sendDebugMessage(LIBS::Warning,tr("Device already %1").arg(enabled?tr("arned"):tr("disarmed")));
                return;
            }
            bool _ok =false;
            _ok = parseSCPIok(sendSCPICommand(QString("%1").arg(enabled?"*ARM":"*DIS").toLocal8Bit()));
            if(_ok){
                m_chanEnabled[chan] = enabled;
                m_parameters.insert(QString("Chan%1Enabled").arg((unsigned int)chan),enabled);
                emit channelEnabledChanged(chan,enabled);
                return;
            }else{
                emit sendDebugMessage(LIBS::Error,tr("Sending %1 command failed.").arg(enabled?"*ARM":"*DIS"));
                return;
            }
        }
     */
    else {
        emit sendDebugMessage(LIBS::Warning, QString("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::updateChannelEnabled(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok     = false;
        int enabled = -1;
        enabled = parseSCPIint(sendSCPICommand(QString(":PULSE%1:STATE?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            if (enabled >= 0 && enabled < 2) {
                m_chanEnabled[chan] = enabled == 1 ? true : false;
                m_parameters.insert(QString("Chan%1Enabled").arg((unsigned int)chan), enabled);
                emit channelEnabledChanged(chan, enabled == 1 ? true : false);
            } else {
                sendDebugMessage(LIBS::Error, tr("Invalid channel %1 state %2.").arg((unsigned int)chan).arg(enabled));
                emit channelEnabledChanged(chan, m_chanEnabled[chan]);
            }
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 state.").arg((unsigned int)chan));
            emit channelEnabledChanged(chan, m_chanEnabled[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelWidth(char chan, double width) {
    QLocale cloc = QLocale::c();
    cloc.setNumberOptions(QLocale::OmitGroupSeparator);
    if (chan >= 1 && chan < 5) {
        if (width != m_chanWidth[chan]) {
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(
                QString(":PULSE%1:WIDTH %2").arg((unsigned int)chan).arg(cloc.toString(width)).toLocal8Bit()));
            if (_ok) {
                m_parameters.insert(QString("Chan%1Width").arg((unsigned int)chan), width);
                m_chanWidth[chan] = width;
            } else {
                emit sendDebugMessage(
                    LIBS::Error,
                    tr("Unable to set channel %1 width to %2 µs.").arg((unsigned int)chan).arg(width * 1e6));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Info,
                tr("Channel %1 already has width %2 µs, ignoring.").arg((unsigned int)chan).arg(width * 1e6));
            return;
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    /*! BUG in ddg firmware
            updateChannelWidth(chan);
    */
}

void LibsDelayGeneratorSystem::updateChannelWidth(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok      = false;
        double width = -1.0;
        width = parseSCPIdouble(sendSCPICommand(QString(":PULSE%1:WIDTH?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanWidth[chan] = width;
            m_parameters.insert(QString("Chan%1Width").arg((unsigned int)chan), width);
            emit channelWidthChanged(chan, width);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 width.").arg((unsigned int)chan));
            emit channelWidthChanged(chan, m_chanWidth[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelDelay(char chan, double delay) {
    //    emit channelDelayChanged(chan,delay);
    //    return;
    QLocale cloc = QLocale::c();
    cloc.setNumberOptions(QLocale::OmitGroupSeparator);
    if (chan >= 1 && chan < 5) {
        if (delay != m_chanDelay[chan]) {
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(
                QString(":PULSE%1:DELAY %2").arg((unsigned int)chan).arg(cloc.toString(delay)).toLocal8Bit()));
            if (_ok) {
                m_parameters.insert(QString("Chan%1Delay").arg((unsigned int)chan), delay);
                m_chanDelay[chan] = delay;
            } else {
                emit sendDebugMessage(
                    LIBS::Error,
                    tr("Unable to set channel %1 delay to %2 µs.").arg((unsigned int)chan).arg(delay * 1e6));
            }
            //            updateChannelDelay(chan);
        } else {
            emit sendDebugMessage(
                LIBS::Info,
                tr("Channel %1 already has delay %2 µs, ignoring.").arg((unsigned int)chan).arg(delay * 1e6));
            return;
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::updateChannelDelay(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok      = false;
        double delay = -1.0;
        delay = parseSCPIdouble(sendSCPICommand(QString(":PULSE%1:DELAY?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanDelay[chan] = delay;
            m_parameters.insert(QString("Chan%1Delay").arg((unsigned int)chan), delay);
            emit channelDelayChanged(chan, delay);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 delay.").arg((unsigned int)chan));
            emit channelDelayChanged(chan, m_chanDelay[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelSync(char chan, int sync) {
    if (chan >= 1 && chan < 5) {
        if (sync >= 0 && sync < 5 && sync != chan) {
            if (sync != m_chanSync[chan]) {
                bool _ok = false;
                _ok      = parseSCPIok(
                    sendSCPICommand(QString(":PULSE%1:SYNC %2").arg((unsigned int)chan).arg(sync).toLocal8Bit()));
                if (_ok) {
                    //                    m_chanSync[chan] = sync;
                    //                    m_parameters.insert(QString("Chan%1Sync").arg((unsigned int)chan), sync);
                    //                    emit channelSyncChanged(chan,sync);
                } else {
                    emit sendDebugMessage(LIBS::Error,
                                          tr("Unable to set channel %1 sync to %2.").arg((unsigned int)chan).arg(sync));
                }
                //                updateChannelSync(chan);
            } else {
                emit sendDebugMessage(
                    LIBS::Info,
                    tr("Channel %1 already has sync source %2, ignoring.").arg((unsigned int)chan).arg(sync));
                return;
            }
        } else {
            emit sendDebugMessage(
                LIBS::Warning,
                tr("Invalid sync source %1 for channel %2.").arg((unsigned int)sync).arg((unsigned int)chan));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::updateChannelSync(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok  = false;
        int sync = -1;
        sync     = parseSCPIint(sendSCPICommand(QString(":PULSE%1:SYNC?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            if (sync >= 0 && sync <= 4 && sync != chan) {
                m_chanSync[chan] = sync;
                m_parameters.insert(QString("Chan%1Sync").arg((unsigned int)chan), sync);
                emit channelSyncChanged(chan, sync);
            } else {
                emit sendDebugMessage(
                    LIBS::Warning,
                    tr("Invalid sync source %1 for channel %2.").arg((unsigned int)sync).arg((unsigned int)chan));
                emit channelSyncChanged(chan, m_chanSync[chan]);
            }
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 sync.").arg((unsigned int)chan));
            emit channelSyncChanged(chan, m_chanSync[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelMultiplexer(char chan, unsigned char mux) {
    if (chan >= 1 && chan < 5) {
        if (mux != m_chanMux[chan]) {
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(
                QString(":PULSE%1:MUX %2").arg((unsigned int)chan).arg((unsigned int)mux).toLocal8Bit()));
            if (_ok) {
                //                m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                this->setChannelEnabled(0, false);
                m_chanMux[chan] = mux;
                m_parameters.insert(QString("Chan%1Mux").arg((unsigned int)chan), (unsigned int)mux);
            } else {
                emit sendDebugMessage(
                    LIBS::Error,
                    tr("Unable to set channel %1 multiplexor to %2.").arg((unsigned int)chan).arg((unsigned int)mux));
            }
            //            updateChannelMultiplexer(chan);
        } else {
            emit sendDebugMessage(
                LIBS::Info,
                tr("Channel %1 already has multiplexor %2, ignoring.").arg((unsigned int)chan).arg((unsigned int)mux));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelMultiplexer(char chan, bool chanA, bool chanB, bool chanC, bool chanD) {
    unsigned char mux = (chanA ? 1 << 0 : 0) + (chanB ? 1 << 1 : 0) + (chanC ? 1 << 2 : 0) + (chanD ? 1 << 3 : 0);
    setChannelMultiplexer(chan, mux);
}

void LibsDelayGeneratorSystem::updateChannelMultiplexer(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok = false;
        int mux = -1;
        mux     = parseSCPIint(sendSCPICommand(QString(":PULSE%1:MUX?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanMux[chan] = mux;
            m_parameters.insert(QString("Chan%1Mux").arg((unsigned int)chan), (unsigned int)mux);
            emit channelMultiplexerChanged(chan, mux);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 multiplexer.").arg((unsigned int)chan));
            emit channelMultiplexerChanged(chan, m_chanWidth[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelPolarity(char chan, int pol) {
    if (chan >= 1 && chan < 5) {
        if (pol >= 0 && pol < 3) {
            if (pol != m_chanPolarity[chan]) {
                bool _ok = false;
                _ok      = parseSCPIok(
                    sendSCPICommand(QString(":PULSE%1:POLARITY %2").arg((unsigned int)chan).arg(pol).toLocal8Bit()));
                if (_ok) {
                    m_chanPolarity[chan] = pol;
                    m_parameters.insert(QString("Chan%1Polarity").arg((unsigned int)chan), pol);
                } else {
                    emit sendDebugMessage(
                        LIBS::Error, tr("Unable to set channel %1 polarity to %2.").arg((unsigned int)chan).arg(pol));
                }
            } else {
                emit sendDebugMessage(
                    LIBS::Info,
                    tr("Channel %1 already set to polarity %2, ignoring.").arg((unsigned int)chan).arg(pol));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Warning,
                tr("Invalid polarity %1 for channel %2.").arg((unsigned int)pol).arg((unsigned int)chan));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelPolarity(chan);
}

void LibsDelayGeneratorSystem::updateChannelPolarity(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok = false;
        int pol = -1;
        pol = parseSCPIint(sendSCPICommand(QString(":PULSE%1:POLARITY?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            if (pol >= 0 && pol < 3) {
                m_chanPolarity[chan] = pol;
                m_parameters.insert(QString("Chan%1Polarity").arg((unsigned int)chan), pol);
                emit channelPolarityChanged(chan, pol);
            } else {
                emit sendDebugMessage(
                    LIBS::Warning,
                    tr("Invalid polarity %1 for channel %2.").arg((unsigned int)pol).arg((unsigned int)chan));
                emit channelPolarityChanged(chan, m_chanPolarity[chan]);
            }
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 polarity.").arg((unsigned int)chan));
            emit channelPolarityChanged(chan, m_chanPolarity[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelWaitCount(char chan, int wait) {
    if (chan >= 1 && chan < 5) {
        if (wait != m_chanWait[chan]) {
            bool _ok = false;
            _ok      = parseSCPIok(
                sendSCPICommand(QString(":PULSE%1:WCOUNTER %2").arg((unsigned int)chan).arg(wait).toLocal8Bit()));
            if (_ok) {
                m_chanWait[chan] = wait;
                m_parameters.insert(QString("Chan%1WaitCount").arg((unsigned int)chan), wait);
            } else {
                emit sendDebugMessage(
                    LIBS::Error, tr("Unable to set channel %1 wait count to %2.").arg((unsigned int)chan).arg(wait));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Info, tr("Channel %1 already has wait count %2, ignoring.").arg((unsigned int)chan).arg(wait));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelWaitCount(chan);
}

void LibsDelayGeneratorSystem::updateChannelWaitCount(char chan) {
    if (chan >= 1 && chan <= 4) {
        bool ok   = false;
        int count = -1.0;
        count = parseSCPIint(sendSCPICommand(QString(":PULSE%1:WCOUNTER?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanWait[chan] = count;
            m_parameters.insert(QString("Chan%1WaitCount").arg((unsigned int)chan), count);
            emit channelWaitCountChanged(chan, count);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 wait count.").arg((unsigned int)chan));
            emit channelWaitCountChanged(chan, m_chanWait[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelBurstCount(char chan, int count) {
    if (chan >= 0 && chan < 5) {
        if (count != m_chanBurst[chan]) {
            bool _ok = false;
            _ok      = parseSCPIok(
                sendSCPICommand(QString(":PULSE%1:BCOUNTER %2").arg((unsigned int)chan).arg(count).toLocal8Bit()));
            if (_ok) {
                m_parameters.insert(QString("Chan%1BurstCount").arg((unsigned int)chan), count);
                m_chanBurst[chan] = count;
            } else {
                emit sendDebugMessage(
                    LIBS::Error, tr("Unable to set channel %1 burst count to %2.").arg((unsigned int)chan).arg(count));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Info, tr("Channel %1 already has burst count %2, ignoring.").arg((unsigned int)chan).arg(count));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelBurstCount(chan);
}

void LibsDelayGeneratorSystem::updateChannelBurstCount(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok   = false;
        int count = -1.0;
        count = parseSCPIint(sendSCPICommand(QString(":PULSE%1:BCOUNTER?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanBurst[chan] = count;
            m_parameters.insert(QString("Chan%1BurstCount").arg((unsigned int)chan), count);
            emit channelBurstCountChanged(chan, count);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 burst count.").arg((unsigned int)chan));
            emit channelBurstCountChanged(chan, m_chanBurst[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelDutyCycleOnCount(char chan, int count) {
    if (chan >= 0 && chan < 5) {
        if (count != m_chanDutyOn[chan]) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(
                sendSCPICommand(QString(":PULSE%1:PCOUNTER %2").arg((unsigned int)chan).arg(count).toLocal8Bit()));
            if (_ok) {
                m_parameters.insert(QString("Chan%1DutyOnCount").arg((unsigned int)chan), count);
                m_chanDutyOn[chan] = count;
            } else {
                emit sendDebugMessage(
                    LIBS::Error,
                    tr("Unable to set channel %1 duty cycle on count to %2.").arg((unsigned int)chan).arg(count));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Info,
                tr("Channel %1 already has duty cycle on count %2, ignoring.").arg((unsigned int)chan).arg(count));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelDutyCycleOnCount(chan);
}

void LibsDelayGeneratorSystem::updateChannelDutyCycleOnCount(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok   = false;
        int count = -1.0;
        count = parseSCPIint(sendSCPICommand(QString(":PULSE%1:PCOUNTER?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanDutyOn[chan] = count;
            m_parameters.insert(QString("Chan%1DutyOnCount").arg((unsigned int)chan), count);
            emit channelDutyCycleOnCountChanged(chan, count);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 duty cycle on count.").arg((unsigned int)chan));
            emit channelDutyCycleOnCountChanged(chan, m_chanDutyOn[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelDutyCycleOffCount(char chan, int count) {
    if (chan >= 0 && chan < 5) {
        if (count != m_chanDutyOff[chan]) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(
                sendSCPICommand(QString(":PULSE%1:OCOUNTER %2").arg((unsigned int)chan).arg(count).toLocal8Bit()));
            if (_ok) {
                m_chanDutyOff[chan] = count;
                m_parameters.insert(QString("Chan%1DutyOffCount").arg((unsigned int)chan), count);
            } else {
                emit sendDebugMessage(
                    LIBS::Error,
                    tr("Unable to set channel %1 duty cycle off count to %2.").arg((unsigned int)chan).arg(count));
            }
        } else {
            emit sendDebugMessage(
                LIBS::Info,
                tr("Channel %1 already has duty cycle off count %2, ignoring.").arg((unsigned int)chan).arg(count));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelDutyCycleOffCount(chan);
}

void LibsDelayGeneratorSystem::updateChannelDutyCycleOffCount(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok   = false;
        int count = -1.0;
        count = parseSCPIint(sendSCPICommand(QString(":PULSE%1:OCOUNTER?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            m_chanDutyOff[chan] = count;
            m_parameters.insert(QString("Chan%1DutyOffCount").arg((unsigned int)chan), count);
            emit channelDutyCycleOffCountChanged(chan, count);
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 duty cycle off count.").arg((unsigned int)chan));
            emit channelDutyCycleOffCountChanged(chan, m_chanDutyOff[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setChannelGateMode(char chan, int mode) {
    if (chan >= 1 && chan < 5) {
        if (mode >= 0 && mode < 3) {
            if (mode != m_chanGateMode[chan]) {
                bool _ok = false;
                _ok      = parseSCPIok(
                    sendSCPICommand(QString(":PULSE%1:CGATE %2").arg((unsigned int)chan).arg(mode).toLocal8Bit()));
                if (_ok) {
                    //                    m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                    this->setChannelEnabled(0, false);
                    m_chanGateMode[chan] = mode;
                    m_parameters.insert(QString("Chan%1GateMode").arg((unsigned int)chan), mode);
                } else {
                    emit sendDebugMessage(
                        LIBS::Error, tr("Unable to set channel %1 to gate mode %2.").arg((unsigned int)chan).arg(mode));
                }
            } else {
                emit sendDebugMessage(
                    LIBS::Info, tr("Channel %1 already in gate mode %2, ignoring.").arg((unsigned int)chan).arg(mode));
                return;
            }
        } else {
            emit sendDebugMessage(LIBS::Warning, tr("Invalid gate mode %1.").arg((unsigned int)mode));
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, QString("Invalid channel number %1.").arg((unsigned int)chan));
    }
    //    updateChannelGateMode(chan);
}

void LibsDelayGeneratorSystem::updateChannelGateMode(char chan) {
    if (chan >= 0 && chan <= 4) {
        bool ok  = false;
        int mode = -1;
        mode     = parseSCPIint(sendSCPICommand(QString(":PULSE%1:CGATE?").arg((unsigned int)chan).toLocal8Bit()), &ok);
        if (ok) {
            if (mode >= 0 && mode <= 3) {
                m_chanGateMode[chan] = mode;
                m_parameters.insert(QString("Chan%1GateMode").arg((unsigned int)chan), mode);
                emit channelGateModeChanged(chan, mode);
            } else {
                sendDebugMessage(LIBS::Error, tr("Invalid channel %1 gate mode %2.").arg((unsigned int)chan).arg(mode));
                emit channelGateModeChanged(chan, m_chanGateMode[chan]);
            }
        } else {
            sendDebugMessage(LIBS::Error, tr("Unable to get channel %1 gate mode.").arg((unsigned int)chan));
            emit channelGateModeChanged(chan, m_chanGateMode[chan]);
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid channel number %1.").arg((unsigned int)chan));
    }
}

void LibsDelayGeneratorSystem::setPeriod(double period) {
    QLocale cloc = QLocale::c();
    cloc.setNumberOptions(QLocale::OmitGroupSeparator);
    if (period != m_period) {
        setChannelEnabled(0, false);
        bool _ok = false;
        _ok      = parseSCPIok(sendSCPICommand(QString(":PULSE0:PERIOD %1").arg(cloc.toString(period)).toLocal8Bit()));
        if (_ok) {
            //            m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
            m_period = period;
            m_parameters.insert(QString("Period"), period);
        } else {
            emit sendDebugMessage(LIBS::Error, tr("Unable to set DDG period to %2 ms.").arg(period * 1e3));
        }
    } else {
        emit sendDebugMessage(LIBS::Info, tr("DDG has already period %1 ms, ignoring.").arg(period * 1e3));
        return;
    }
    //    updatePeriod();
}

void LibsDelayGeneratorSystem::updatePeriod() {
    bool ok       = false;
    double period = -1.0;
    period        = parseSCPIdouble(sendSCPICommand(QString(":PULSE0:PERIOD?").toLocal8Bit()), &ok);
    if (ok) {
        m_period = period;
        m_parameters.insert(QString("Period"), period);
        emit periodChanged(period);
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get DDG period."));
        emit periodChanged(m_period);
    }
}

void LibsDelayGeneratorSystem::setExtTriggMode(int mode) {
    if (mode >= 0 && mode < 3) {
        if (mode != m_triggMode) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(QString(":PULSE0:EXTERNAL:MODE %1").arg(mode).toLocal8Bit()));
            if (_ok) {
                //                m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                //                m_triggMode = mode;
                //                m_parameters.insert(QString("ExtTriggMode"), mode);
            } else {
                emit sendDebugMessage(LIBS::Error, tr("Unable to set external trigger mode to %2.").arg(mode));
            }
        } else {
            emit sendDebugMessage(LIBS::Info, tr("External trigger mode already is %1, ignoring.").arg(mode));
            return;
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid external trigger mode %1.").arg((unsigned int)mode));
    }
    //    updateExtTriggMode();
}

void LibsDelayGeneratorSystem::updateExtTriggMode() {
    bool ok  = false;
    int mode = -1;
    mode     = parseSCPIint(sendSCPICommand(QString(":PULSE0:EXTERNAL:MODE?").toLocal8Bit()), &ok);
    if (ok) {
        if (mode >= 0 && mode <= 3) {
            m_triggMode = mode;
            m_parameters.insert(QString("ExtTriggMode"), mode);
            emit extTriggModeChanged(mode);
        } else {
            sendDebugMessage(LIBS::Error, tr("Invalid external trigger mode %1.").arg(mode));
            emit extTriggModeChanged(m_triggMode);
        }
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get external trigger mode."));
        emit extTriggModeChanged(m_triggMode);
    }
}

void LibsDelayGeneratorSystem::setExtTriggLevel(int level) {
    if (level >= 20 && level <= 240) {
        if (level != m_triggLevel) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(QString(":PULSE0:EXTERNAL:LEVEL %1").arg(level).toLocal8Bit()));
            if (_ok) {
                // m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                //                m_triggLevel = level;
                //                m_parameters.insert(QString("ExtTriggLevel"), level);
            } else {
                emit sendDebugMessage(LIBS::Error,
                                      tr("Unable to set external trigger level to %1 V.").arg(level * 0.1));
            }
        } else {
            emit sendDebugMessage(LIBS::Info, tr("External trigger level already is %1 V, ignoring.").arg(level * 0.1));
            return;
        }
    }
    //    updateExtTriggLevel();
}

void LibsDelayGeneratorSystem::updateExtTriggLevel() {
    bool ok      = false;
    double level = -1.0;
    level        = parseSCPIdouble(sendSCPICommand(QString(":PULSE0:EXTERNAL:LEVEL?").toLocal8Bit()), &ok);
    if (ok) {
        m_triggLevel = level;
        m_parameters.insert(QString("ExtTriggLevel"), level);
        emit extTriggLevelChanged(level);
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get external trigger level."));
        emit extTriggLevelChanged(m_triggLevel);
    }
}

void LibsDelayGeneratorSystem::setExtTriggEdge(int edge) {
    if (edge >= 0 && edge < 2) {
        if (edge != m_triggEdge) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(QString(":PULSE0:EXTERNAL:EDGE %1").arg(edge).toLocal8Bit()));
            if (_ok) {
                //                m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                m_triggEdge = edge;
                m_parameters.insert(QString("ExtTriggEdge"), edge);
                //                emit extTriggEdgeChanged(edge);
            } else {
                emit sendDebugMessage(LIBS::Error, tr("Unable to set external trigger edge to %1.").arg(edge));
            }
        } else {
            emit sendDebugMessage(LIBS::Info, tr("External trigger edge already is %1, ignoring.").arg(edge));
            return;
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid external trigger edge %1 .").arg(edge));
    }
    //    updateExtTriggEdge();
}

void LibsDelayGeneratorSystem::updateExtTriggEdge() {
    bool ok  = false;
    int edge = -1;
    edge     = parseSCPIint(sendSCPICommand(QString(":PULSE0:EXTERNAL:EDGE?").toLocal8Bit()), &ok);
    if (ok) {
        if (edge >= 0 && edge < 2) {
            m_triggEdge = edge;
            m_parameters.insert(QString("ExtTriggEdge"), edge);
            emit extTriggEdgeChanged(edge);
        } else {
            sendDebugMessage(LIBS::Error, tr("Invalid external trigger edge %1.").arg(edge));
            emit extTriggEdgeChanged(m_triggEdge);
        }
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get external trigger edge."));
        emit extTriggEdgeChanged(m_triggEdge);
    }
}

void LibsDelayGeneratorSystem::setExtTriggPolarity(int pol) {
    if (pol >= 0 && pol < 2) {
        if (pol != m_triggPol) {
            setChannelEnabled(0, false);
            bool _ok = false;
            _ok      = parseSCPIok(sendSCPICommand(QString(":PULSE0:EXTERNAL:POLARITY %1").arg(pol).toLocal8Bit()));
            if (_ok) {
                //                m_chanEnabled[0] = false; emit channelEnabledChanged(0,false);
                m_triggPol = pol;
                m_parameters.insert(QString("ExtTriggPolarity"), pol);
                //                emit extTriggPolarityChanged(pol);
            } else {
                emit sendDebugMessage(LIBS::Error, tr("Unable to set external trigger polarity to %1.").arg(pol));
            }
        } else {
            emit sendDebugMessage(LIBS::Info, tr("External trigger polarity already is %1, ignoring.").arg(pol));
            return;
        }
    } else {
        emit sendDebugMessage(LIBS::Warning, tr("Invalid external trigger polarity %1 .").arg(pol));
    }
    // updateExtTriggPolarity();
}

void LibsDelayGeneratorSystem::updateExtTriggPolarity() {
    bool ok = false;
    int pol = -1;
    pol     = parseSCPIint(sendSCPICommand(QString(":PULSE0:EXTERNAL:POLARITY?").toLocal8Bit()), &ok);
    if (ok) {
        if (pol >= 0 && pol < 2) {
            m_triggPol = pol;
            m_parameters.insert(QString("ExtTriggPolarity"), pol);
            emit extTriggPolarityChanged(pol);
        } else {
            sendDebugMessage(LIBS::Error, tr("Invalid external trigger polarity %1.").arg(pol));
            emit extTriggPolarityChanged(m_triggPol);
        }
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get external trigger polarity."));
        emit extTriggPolarityChanged(m_triggPol);
    }
}

void LibsDelayGeneratorSystem::setAutorun(bool run) {
    bool _ok = false;
    if (run != m_autorun) {
        _ok = parseSCPIok(sendSCPICommand(QString(":SYSTEM:AUTORUN %1").arg(run ? "1" : "0").toLocal8Bit()));
        if (!_ok) {
            emit sendDebugMessage(LIBS::Error, tr("Unable to set autorun."));
        } else {
            m_autorun = run;
            m_parameters.insert(QString("Autorun"), run);
        }
    } else {
        emit sendDebugMessage(LIBS::Info, tr("Autorun already %1, ignoring.").arg(run ? "enabled" : "disabled"));
        return;
    }
    //    updateAutorun();
}

void LibsDelayGeneratorSystem::updateAutorun() {
    bool ok = false;
    int run = -1;
    run     = parseSCPIint(sendSCPICommand(QString(":SYSTEM:AUTORUN?").toLocal8Bit()), &ok);
    if (ok) {
        m_autorun = run;
        m_parameters.insert(QString("Autorun"), run);
        emit autorunChanged(run);
    } else {
        sendDebugMessage(LIBS::Error, tr("Unable to get autorun settings."));
        emit autorunChanged(m_autorun);
    }
}

void LibsDelayGeneratorSystem::softwareTrigger() {
    if (!parseSCPIok(sendSCPICommand(QString("*TRG").toLocal8Bit()))) {
        emit sendDebugMessage(LIBS::Error,
                              QString("<i>%1</i> Unable to send software trigger.").arg(this->getDeviceName()));
    }
    emit sendDebugMessage(LIBS::Info, QString("<i>%1</i> Software trigger sent.").arg(this->getDeviceName()));
}

bool LibsDelayGeneratorSystem::armChannels() {
    if (m_chanEnabled[0]) {
        for (int i = 0; i < 5; i++) {
            if (!parseSCPIok(sendSCPICommand(QString("*ARM").toLocal8Bit()))) {
                emit sendDebugMessage(
                    LIBS::Error,
                    QString("<i>%1</i> Unable to arm channels %2/5.").arg(this->getDeviceName()).arg(i + 1));
                //                qDebug() << "armChannels thread(" << QThread::currentThreadId() << ")";
            } else {
                emit sendDebugMessage(LIBS::Info,
                                      QString("<i>%1</i> To je pravda %2/5.").arg(this->getDeviceName()).arg(i + 1));
                break;
            }
        }
    } else {
        setChannelEnabled(0, true);
    }
    //    emit sendDebugMessage(LIBS::Info,QString("<i>%1</i> Channels armed.").arg(this->getDeviceName()));
    return true;
}

void LibsDelayGeneratorSystem::enablePowerUpAutostart(bool enable) {
    if (!parseSCPIok(sendSCPICommand(
            QString(":SYSTEM:AUTORUN %1").arg(enable ? (unsigned int)1 : (unsigned int)0).toLocal8Bit()))) {
        m_parameters.insert(QString("AutorunPowerUp"), enable);
        emit sendDebugMessage(LIBS::Error, QString("<i>%1</i> Unable to arm channels.").arg(this->getDeviceName()));
    }
}

void LibsDelayGeneratorSystem::setChannelCustomName(char chan, QString name) {
    //    QSettings settings(m_controller->ConfigPrefix().Default(), QSettings::defaultFormat());
    switch (chan) {
        case 0:
            m_chanNames[0] = name;
            //        settings.setValue(QString("customChan1Name"),name);
            m_parameters.insert(QString("customChan1Name"), name);
            emit channel1NameChanged(name);
            break;
        case 1:
            m_chanNames[1] = name;
            m_parameters.insert(QString("customChan2Name"), name);
            emit channel2NameChanged(name);
            break;
        case 2:
            m_chanNames[2] = name;
            m_parameters.insert(QString("customChan3Name"), name);
            emit channel3NameChanged(name);
            break;
        case 3:
            m_chanNames[3] = name;
            m_parameters.insert(QString("customChan4Name"), name);
            emit channel4NameChanged(name);
            break;
    }
}

void LibsDelayGeneratorSystem::setDeviceCustomName(QString name) {
    //    QSettings settings(m_controller->ConfigPrefix().Default(), QSettings::defaultFormat());
    m_deviceName = name;
    //    settings.setValue(QString("customDeviceName"),name);
    m_parameters.insert(QString("customDeviceName"), name);
    emit deviceNameChanged(name);
}

void LibsDelayGeneratorSystem::writeSettings() {
    QSettings settings(m_controller->ConfigPrefix().Default(), QSettings::defaultFormat());
    QMapIterator<QString, QVariant> it(m_parameters);
    while (it.hasNext()) {
        it.next();
        settings.setValue(it.key(), it.value());
    }
}

void LibsDelayGeneratorSystem::readSettings() {
    QSettings settings(m_controller->ConfigPrefix().Default(), QSettings::defaultFormat());
    QStringList all = settings.allKeys();
    for (int i = 0; i < all.size(); i++) {
        m_parameters.insert(all.at(i), settings.value(all.at(i)));
    }
}

void LibsDelayGeneratorSystem::saveDeviceState(int slot) {
    bool _ok = false;
    if (slot > 0 && slot < 7) {
        _ok = parseSCPIok(sendSCPICommand(QString("*SAV %1").arg(slot).toLocal8Bit()));
        if (!_ok) {
            emit sendDebugMessage(LIBS::Error, tr("Unable to store device state to slot %1.").arg(slot));
        }
    } else {
        emit sendDebugMessage(LIBS::Error, tr("Invalid slot number %1.").arg(slot));
    }
}

void LibsDelayGeneratorSystem::recallDeviceState(int slot) {
    bool _ok = false;
    if (slot > 0 && slot < 7) {
        _ok = parseSCPIok(sendSCPICommand(QString("*RCL %1").arg(slot).toLocal8Bit()));
        if (!_ok) {
            emit sendDebugMessage(LIBS::Error, tr("Unable to recall device state from slot %1.").arg(slot));
        } else {
            updateAllSettings();
        }
    } else {
        emit sendDebugMessage(LIBS::Error, tr("Invalid slot number %1.").arg(slot));
    }
}

void LibsDelayGeneratorSystem::updateAllSettings() {

    for (char j = 1; j < 5; j++) {
        updateChannelEnabled(j);
        updateChannelMode(j);
        updateChannelDelay(j);
        updateChannelWidth(j);
        updateChannelSync(j);
        updateChannelMultiplexer(j);
        updateChannelPolarity(j);
        updateChannelGateMode(j);
        updateChannelWaitCount(j);
        updateChannelBurstCount(j);
        updateChannelDutyCycleOnCount(j);
        updateChannelDutyCycleOffCount(j);
    }
    updateChannelEnabled(0);
    updateAutorun();
    updatePeriod();
    updateChannelMode(0);
    updateChannelBurstCount(0);
    updateChannelDutyCycleOnCount(0);
    updateChannelDutyCycleOffCount(0);
    updateExtTriggMode();
    updateExtTriggLevel();
    updateExtTriggEdge();
    updateExtTriggPolarity();
    emit allSettingsUpdated();
}

void LibsDelayGeneratorSystem::init() {
    if (!m_autoInit) {
        for (int j = 0; j < 5; j++) {
            updateChannelEnabled(j);
        }
        m_chanEnabled[0] = !m_chanEnabled[0];
        setChannelEnabled(0, !m_chanEnabled[0]);
        for (int j = 1; j < 5; j++) {
            updateChannelDelay(j);
        }
    } else {
        updateAllSettings();
    }
}

LibsAbstractDeviceClass::responseType LibsDelayGeneratorSystem::initializeDevice() {
    if (!m_chanEnabled[0])
        this->setChannelEnabled(0, true);

    return LibsAbstractDeviceClass::cont;
}

LibsAbstractDeviceClass::responseType LibsDelayGeneratorSystem::triggerDevice() {
    if (m_parameters.value(QString("EnableArmOnShoot"), false).toBool())
        if (!this->armChannels()) {
            return LibsAbstractDeviceClass::retry;
        }
    if (m_parameters.value(QString("EnableSoftTriggOnShoot"), false).toBool())
        this->softwareTrigger();

    return LibsAbstractDeviceClass::cont;
}

LibsAbstractDeviceClass::responseType LibsDelayGeneratorSystem::finalizeDevice() {

    return LibsAbstractDeviceClass::cont;
}
