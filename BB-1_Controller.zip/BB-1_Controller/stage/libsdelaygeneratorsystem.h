#ifndef LIBSDELAYGENERATORSYSTEM_H
#define LIBSDELAYGENERATORSYSTEM_H

#include "../devices/libhardware/libsabstractdeviceclass.h"
#include "LIBS.h"
#include "hw_trinamic.h"
#include <QByteArray>
#include <QMutex>
#include <QMutexLocker>
#include <QObject>
#include <QVariantMap>

class LibsDelayGeneratorSystem : public TMCMGPIO {
    Q_OBJECT

    friend class LibsDelayGeneratorSystemSettingsDialog;
    friend class LibsDelayGeneratorSystemDockWidget;
    friend class LibsMain;

public:
    LibsDelayGeneratorSystem(TrinamicController* tmcmController, unsigned char address, QObject* parent);
    ~LibsDelayGeneratorSystem();

    enum pulseModes {
        continuousPulseMode = 0,
        singleShotPulseMode = 1,
        burstPulseMode      = 2,
        dutyCyclePulseMode  = 3,
    };

    QString getChannelName(char chan) {
        if (chan >= 0 && chan < 4)
            return m_chanNames[chan];
        return QString();
    }
    LibsAbstractDeviceClass::responseType initializeDevice();
    LibsAbstractDeviceClass::responseType triggerDevice();
    LibsAbstractDeviceClass::responseType finalizeDevice();

    void init();
public slots:
    QString getDeviceName() {
        if (m_deviceName.isEmpty()) {
            return QString("AT DDG on address %1").arg(m_address);
        } else {
            return m_deviceName;
        }
    }

    QByteArray sendSCPICommand(QByteArray command);
    bool parseSCPIok(QByteArray response);
    int parseSCPIint(QByteArray response, bool* ok);
    int parseSCPIstate(QByteArray response, bool* ok);
    double parseSCPIdouble(QByteArray response, bool* ok);

    void setChannelMode(char chan, int mode);
    void updateChannelMode(char chan);

    void setChannelEnabled(char chan, bool enabled);
    void updateChannelEnabled(char chan);

    //    void setChannelLevel(char chan, double level);
    void setChannelWidth(char chan, double width);
    void updateChannelWidth(char chan);

    void setChannelDelay(char chan, double delay);
    void updateChannelDelay(char chan);

    void setChannelSync(char chan, int sync);
    void updateChannelSync(char chan);

    void setChannelMultiplexer(char chan, unsigned char mux);
    void setChannelMultiplexer(char chan, bool chanA, bool chanB, bool chanC, bool chanD);
    void updateChannelMultiplexer(char chan);

    void setChannelPolarity(char chan, int pol);
    void updateChannelPolarity(char chan);

    void setChannelGateMode(char chan, int mode);
    void updateChannelGateMode(char chan);

    void setChannelWaitCount(char chan, int wait);
    void updateChannelWaitCount(char chan);

    void setChannelBurstCount(char chan, int count);
    void updateChannelBurstCount(char chan);

    void setChannelDutyCycleOnCount(char chan, int count);
    void updateChannelDutyCycleOnCount(char chan);

    void setChannelDutyCycleOffCount(char chan, int count);
    void updateChannelDutyCycleOffCount(char chan);

    void setChannelCustomName(char chan, QString name);
    void setDeviceCustomName(QString name);

    void setPeriod(double period);
    void updatePeriod();

    void setExtTriggMode(int mode);
    void updateExtTriggMode();

    void setExtTriggLevel(int level);
    void updateExtTriggLevel();

    void setExtTriggEdge(int edge);
    void updateExtTriggEdge();

    void setExtTriggPolarity(int pol);
    void updateExtTriggPolarity();

    void setAutorun(bool run);
    void updateAutorun();

    void saveDeviceState(int slot);
    void recallDeviceState(int slot);

    void updateAllSettings();

    void softwareTrigger();
    bool armChannels();
    void enableAutostart(bool enable) {
        m_parameters.insert(QString("AutoStart"), enable);
        m_autoInit = enable;
    }
    void enablePowerUpAutostart(bool enable);

    void enableSoftTriggOnShoot(bool enable) {
        m_parameters.insert(QString("EnableSoftTriggOnShoot"), enable);
    }
    void enableArmOnShoot(bool enable) {
        m_parameters.insert(QString("EnableArmOnShoot"), enable);
    }

    void writeSettings();
    void readSettings();

signals:
    void sendDebugMessage(LIBS::messageType mType, QString msg);

    void channelModeChanged(char chan, int mode);
    void channelEnabledChanged(char chan, bool enabled);
    void channelWidthChanged(char chan, double width);
    void channelDelayChanged(char chan, double delay);
    void channelSyncChanged(char chan, int sync);
    void channelMultiplexerChanged(char chan, int mux);
    void channelPolarityChanged(char chan, int polarity);
    void channelGateModeChanged(char chan, int mode);
    void channelWaitCountChanged(char chan, int wait);
    void channelBurstCountChanged(char chan, int count);
    void channelDutyCycleOnCountChanged(char chan, int count);
    void channelDutyCycleOffCountChanged(char chan, int count);
    void periodChanged(double period);
    void extTriggModeChanged(int mode);
    void extTriggLevelChanged(double level);
    void extTriggEdgeChanged(int edge);
    void extTriggPolarityChanged(int pol);

    void autorunChanged(bool run);

    void channel1NameChanged(QString name);
    void channel2NameChanged(QString name);
    void channel3NameChanged(QString name);
    void channel4NameChanged(QString name);

    void deviceNameChanged(QString name);

    void updateSCPIsendingProgress(QString progress);

    void allSettingsUpdated();

private:
    QString baToHex(QByteArray ba);
    unsigned char calculateCheckSum(QByteArray command);

    unsigned char m_address;
    TrinamicController* m_controller;

    QVariantMap m_parameters;

    int m_chanModes[5];
    bool m_chanEnabled[5];
    double m_chanLevel[5];
    double m_chanWidth[5];
    double m_chanDelay[5];
    int m_chanMux[5];
    int m_chanSync[5];
    int m_chanPolarity[5];
    int m_chanWait[5];
    int m_chanBurst[5];
    int m_chanDutyOn[5];
    int m_chanDutyOff[5];
    int m_chanGateMode[5];

    double m_period;
    int m_triggMode;
    int m_triggLevel;
    int m_triggEdge;
    int m_triggPol;
    bool m_autorun;
    bool m_autoInit;

    QString m_deviceName;
    QString m_chanNames[4];

    bool m_rearmRequired;
};

#endif // LIBSDELAYGENERATORSYSTEM_H
