#include "libsinterlocksystem.h"

LibsInterlockSystem::LibsInterlockSystem(TrinamicController* tmcmController, unsigned char address, QObject* parent)
    : TMCMGPIO(address, tmcmController, parent) {
    trinamicDriver    = tmcmController;
    isEnabled         = false;
    m_interlockStatus = 0;
}

LibsInterlockSystem::~LibsInterlockSystem() {
}

void LibsInterlockSystem::init() {
    if (!trinamicDriver) {
        emit sendDebugMessage(LIBS::Error, QString("Interlock system: Trinamic driver unavailable."));
        return;
    }
    isEnabled = true;
}

QStringList LibsInterlockSystem::checkInterlocks() {
    int ret             = -1;
    int interlockStatus = 0x00;
    emit sendDebugMessage(LIBS::Debug, QString("Interlock system: Checking interlocks."));
    QStringList interlocks;
    if (!isEnabled) {
        interlocks << QString("Interlock system is not working!!!");
        return interlocks;
    }
    QSettings stgs(Config("interlockSystem").Default(), QSettings::defaultFormat());
    for (int i = 1; i < 8; i++) {
        if ((ret = trinamicDriver->SendCommandEx(CommandInterlock, static_cast<quint8>(i), SystemStatusInfo, 0)) ==
            TMCMGPIO::STAT_OK) {
            interlockStatus = trinamicDriver->ReturnValue(0);
            if (interlockStatus == 0)
                interlocks.append(
                    stgs.value(QString("interlock%1Name").arg(i), QString("Interlock port #%1 opened").arg(i))
                        .toString());
            emit sendDebugMessage(
                LIBS::Debug,
                QString("%1 is set to %2")
                    .arg(stgs.value(QString("interlock%1Name").arg(i), QString("Interlock port #%1").arg(i)).toString())
                    .arg(interlockStatus));
            m_interlockStatus += ((interlockStatus > 0 ? 0 : 1) << i);
        } else {
            emit sendDebugMessage(
                LIBS::Error,
                QString("Interlock system: check interlock status returned error %1 and return value %2.")
                    .arg(ret)
                    .arg(trinamicDriver->ReturnValue(0)));
            interlocks << QString("Interlock failed to read!!!");
        }
    }
    emit interlockStatusTextUpdated(interlocks);
    return interlocks;
}

void LibsInterlockSystem::clearInterlocks(bool clear) {
    int ret = -1;
    emit sendDebugMessage(LIBS::Debug, QString("Interlock system: Clearing interlocks."));
    if (!isEnabled)
        return;
    if ((ret = trinamicDriver->SendCommand(CommandInterlock, ClearInterlocks, 0, clear ? 1 : 0)) == TMCMGPIO::STAT_OK) {
        emit sendDebugMessage(LIBS::Info, QString("Interlock system: Interlock cleared, laser is now enabled."));
    } else {
        emit sendDebugMessage(LIBS::Error,
                              QString("Interlock system: Clearing interlocks returned error %1.").arg(ret));
    }
}

int LibsInterlockSystem::getMaintenanceInfo() {
    int ret = -1;
    emit sendDebugMessage(LIBS::Debug, QString("Interlock system: Getting maintenance info."));
    if (!isEnabled)
        return 0;
    if ((ret = trinamicDriver->SendCommandEx(CommandInterlock, 0, SystemStatusInfo, 0)) == TMCMGPIO::STAT_OK) {
        emit maintenanceStatusUpdated(trinamicDriver->ReturnValue(0));
        emit sendDebugMessage(
            LIBS::Info,
            QString("Interlock system: Maintenance system is currently %1.")
                .arg(trinamicDriver->ReturnValue(0) > 0 ? QString("<b>ON</b>") : QString("<b>OFF</b>")));
        return trinamicDriver->ReturnValue(0);
    } else {
        emit sendDebugMessage(LIBS::Error,
                              QString("Interlock system: Maintenance system command returned %1.").arg(ret));
    }
    return 0;
}
