#ifndef LIBSINTERLOCKSYSTEM_H
#define LIBSINTERLOCKSYSTEM_H

#include "LIBS.h"
#include "hw_trinamic.h"
#include <QObject>

/*
     Command -> TB_CMD_BLACKBOX (18)
      Type -> BB_ACTIVE (1)
      Type -> BB_SETOUTPUT (2)
      Type -> BB_SETTIME (3)
      Type -> BB_SETMASK (4)

     Command -> TB_CMD_INTERLOCK (28)
      Type -> IL_INFO (0)
        Motor bank (0)
                Value -> 1 bit - servisni mod
        Motor bank (1)
        Value -> 1 bit - otevrena komora (log 1)
                 2 bit - otevrene oplasteni (log 1)
      Type -> IL_LASER (4)
       Motor bank (0)
            Value (1 bit) -> Nastavuje se povolení laseru (log 1), avšak provede se jenom v případě pokud je v servisním
   modu a je zavřena komora a oplasteni. Log 1 nastaví interlock na nulu tedy vypne laser.
*/

class LibsInterlockSystem : public TMCMGPIO {
    Q_OBJECT

public:
    explicit LibsInterlockSystem(TrinamicController* tmcmController, unsigned char address, QObject* parent);
    ~LibsInterlockSystem();

    enum InterlockSystemCommands {
        CommandBlackbox  = 18,
        CommandInterlock = 15,
    };

    enum InterlockSystemCommandType {
        SystemStatusInfo = 2,
        ClearInterlocks  = 4,
    };

    enum BlackBoxCommandType {
        Active    = 1,
        SetOutput = 2,
        SetTime   = 3,
        SetMask   = 4,
    };

    enum BasicInterlocks {
        ChamberOpen = 1 << 0,
        ShieldOpen  = 1 << 1,
    };

    void init();
    int getInterlockStatus() {
        return m_interlockStatus;
    }
signals:
    void sendDebugMessage(LIBS::messageType mType, QString msg);
    void interlockStatusUpdated(int interlocks);
    void interlockStatusTextUpdated(QStringList interlocks);
    void maintenanceStatusUpdated(int maintain);
public slots:
    void clearInterlocks(bool clear = true);
    QStringList checkInterlocks();
    int getMaintenanceInfo();

private:
    TrinamicController* trinamicDriver;
    bool isEnabled;
    int m_interlockStatus;
};

#endif // LIBSINTERLOCKSYSTEM_H
