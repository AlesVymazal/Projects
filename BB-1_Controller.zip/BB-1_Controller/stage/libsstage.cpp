#include "libsstage.h"

//#include "baslercameradriver.h"
//#include "thorlabscameradriver.h"

#include <QDebug>

//*********************************LIBSStageV2*********************************//

LIBSStageV2::LIBSStageV2(QObject* parent) : QObject(parent) {
    // 8 x y, 32 z
    QSettings settings;

    laserOffset = QPointF(cameraWidth / 2., cameraHeight / 2.);
    curPosPx    = QPointF(cameraWidth / 2., cameraHeight / 2.);

    //    pixToMmRatio=7.0/1280.0;       //ratio of milimeters per pixel
    //    pixToMmRatio=1.00/733.0;       //ratio of milimeters per pixel
    //    pixToMmRatio=1.00/1402.0;       //ratio of milimeters per pixel
    //    pixToMmRatio=0.25/245.0;
    //
    //    pixToMmRatio=1.0/695.3;
    //      pixToMmRatio=1.0/339.37; //Single expander
    //      pixToMmRatio=1.0/454.0; //Double expander
    //    pixToMmRatio=0.25/235.1;       //ratio of milimeters per pixel
    //      pixToMmRatio=0.25/172.0; // Sci-Trace
    pixToMmRatio = 0.25 / 197.314; // Sci-Trace

    // TODO: moveToThread do pracovnigho vlakna
    QSettings t_settings(Config("trinamic").Default(), QSettings::defaultFormat());
    tcmDriver   = new TMCM6110Driver485(Config("trinamic"), this);
    manipulator = new XYStage(t_settings.value(QString("private/stage/xAxis"), 0).toInt(),
                              t_settings.value(QString("private/stage/yAxis"), 1).toInt(),
                              t_settings.value(QString("private/stage/zAxis"), 2).toInt(),
                              tcmDriver,
                              this);
    attenuator  = new LibsAttenuator(t_settings.value(QString("private/stage/attAxis"), 3).toInt(), tcmDriver, this);
    focuser =
        new FixedLengthLinearAxis(t_settings.value(QString("private/stage/focusAxis"), 5).toInt(), tcmDriver, this);

    //
    // Main camera
    //
    //    QSettings cam_settings("./primaryCamera.xml", QSettings::defaultFormat());
    //    BaslerCameraDriver& driver = BaslerCameraDriver::getInstance();
    //    QString mainCameraID       = cam_settings.value("private/mainCamera/id").toString();
    //    m_mirrorCamHorizontally    = cam_settings.value("private/mainCamera/horizontalMirror", true).toBool();
    //    m_mirrorCamVertically      = cam_settings.value("private/mainCamera/verticalMirror", false).toBool();
    //    m_mainCamera               = driver.getByID(mainCameraID);
    //    //
    //    //  Place here any other camera obtaining
    //    //
    //    if (m_mainCamera == nullptr) { // there is no camera as mainCamera/id
    //        // qDebug() << "mainCamera not found, selecting Thorlabs";
    //        m_mainCamera = new ThorlabsCameraDriver();
    //        //        m_mainCamera = driver.getFirst();   //add all other cameras ids as a filter here
    //        //        if(m_mainCamera == nullptr) {
    //        //            qDebug() << "Could not find any free camera as mainCamera";
    //        //            m_mainCamera = BaslerCameraDriver::getDummyDevice();
    //        //        }
    //    }
    //    driver.seize(m_mainCamera); // it will not be listed for others

    //    // SHUTTER
    //    shutterDriver = new TMCM6110Driver485(Config("shutter"), this);
    //    mainShutter   = new LibsShutterV2(shutterDriver, 0, this);

    //    connect(mainShutter,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(this, SIGNAL(closeShutter()), mainShutter, SLOT(closeShutter()));
    //    connect(this, SIGNAL(openShutter()), mainShutter, SLOT(openShutter()));
    //    connect(mainShutter, SIGNAL(shutterOpened()), this, SIGNAL(shutterOpened()));
    //    connect(mainShutter, SIGNAL(shutterClosed()), this, SIGNAL(shutterClosed()));
    //    connect(mainShutter, SIGNAL(shutterStateChanged(bool)), this, SIGNAL(shutterStateChanged(bool)));

    //    // AUTOFOCUS
    //    autofocusThread = new QThread(this);
    //    autofocusThread->start();
    //    autofocusWorker = new AutofocusWorker();
    //    autofocusWorker->moveToThread(autofocusThread);

    //    connect(this, SIGNAL(startAutofocus()), autofocusWorker, SLOT(startAutofocus()));
    //    connect(this, SIGNAL(startFineAutofocus()), autofocusWorker, SLOT(startBinaryAutofocus()));
    //    connect(this, SIGNAL(setBinaryFinalStepSize(double)), autofocusWorker,
    //    SLOT(setupBinaryFinalStepSize(double))); connect(autofocusWorker,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(autofocusWorker, SIGNAL(updateSharpness(double, double)), this, SIGNAL(updateSharpness(double,
    //    double))); connect(autofocusWorker, SIGNAL(getInitialSharpnessImage()), this,
    //    SLOT(requestInitialSharpness())); connect(autofocusWorker,
    //            SIGNAL(getNextSharpnessImage(qreal, qreal, qreal)),
    //            this,
    //            SLOT(moveAllMotorsAbs(qreal, qreal, qreal)));
    //    connect(this, SIGNAL(cancelAutofocus()), autofocusWorker, SLOT(cancelAutofocus()));
    //    connect(autofocusWorker, SIGNAL(initialMoveZ()), this, SIGNAL(initialAutofocusMoveZ()));

    //    //
    //    connect(stage,SIGNAL(sendDebugMessage(LIBS::messageType,QString)),this,SIGNAL(sendMessage(LIBS::messageType,QString)),Qt::QueuedConnection);

    //    connect(m_mainCamera,
    //            SIGNAL(frameArrived(QImage, QPointF, double)),
    //            autofocusWorker,
    //            SLOT(frameFromCamera(QImage, QPointF, double)),
    //            Qt::QueuedConnection);

    //    connect(m_mainCamera, &LIBSAbstractCameraClass::sendMessage, this, &LIBSStageV2::sendMessage);

    // TESTING AREA
    //    try {
    //        QImage correction;
    //        correction.load("D:/Sandbox/correction.bmp");
    //        m_mainCameraVigentte.calibrate(correction);
    //        QImage correct("D:/Sandbox/input.bmp");
    //        QImage result = m_mainCameraVigentte.correct(correct);
    //        result.save("D:/sandbox/result.bmp");
    //    } catch (std::exception& e) {
    //        qDebug() << "Error: " << e.what();
    //    } catch (...) {
    //        qDebug() << "-------UNKNOWN EXCEPTION";
    //    }
    //    connect(m_mainCamera,
    //            static_cast<void (LIBSAbstractCameraClass::*)(QImage, QPointF, double) const>(
    //                &LIBSAbstractCameraClass::frameArrived),
    //            [=](QImage i, QPointF p, double z) {
    //                i = i.mirrored(m_mirrorCamHorizontally, m_mirrorCamVertically);
    //                if (m_mainCameraVigentteEnabled) {
    //                    QImage o = m_mainCameraVigentte.correct(i);
    //                    emit frameFromCamera(QPixmap::fromImage(o), p, z);
    //                } else
    //                    emit frameFromCamera(QPixmap::fromImage(i), p, z);
    //            });
    //    // connect(m_mainCamera, &LIBSAbstractCameraClass::liveFrameArrived, this, &LIBSStageV2::liveFrameFromCamera);
    //    connect(m_mainCamera, &LIBSAbstractCameraClass::liveFrameArrived, [=](QPixmap p) {
    //        QImage i = p.toImage();
    //        i        = i.mirrored(m_mirrorCamHorizontally, m_mirrorCamVertically);
    //        if (m_mainCameraVigentteEnabled) {
    //            if (m_mainCameraVignetteCompensation) {
    //                m_mainCameraVignetteCompensation = false;
    //                m_mainCameraVigentte.calibrate(i);
    //            }

    //            QImage o = m_mainCameraVigentte.correct(i);
    //            emit liveFrameFromCamera(QPixmap::fromImage(o));
    //        } else
    //            emit liveFrameFromCamera(QPixmap::fromImage(i));
    //    });

    connect(manipulator, SIGNAL(ManXStatus(QString)), SIGNAL(xMotorPosChanged(QString)));
    connect(manipulator, SIGNAL(ManXStatus(double)), SIGNAL(xMotorPosChanged(double)));
    connect(manipulator, SIGNAL(ManYStatus(QString)), SIGNAL(yMotorPosChanged(QString)));
    connect(manipulator, SIGNAL(ManYStatus(double)), SIGNAL(yMotorPosChanged(double)));
    connect(manipulator, SIGNAL(ManZStatus(QString)), SIGNAL(zMotorPosChanged(QString)));
    connect(manipulator, SIGNAL(ManZStatus(double)), SIGNAL(zMotorPosChanged(double)));
    connect(manipulator, SIGNAL(Stoped()), this, SIGNAL(motorMovementFinished()));
    // connect(manipulator, SIGNAL(Stoped()), this, SLOT(getFrameFromCamera()));
    connect(manipulator, SIGNAL(Referenced()), this, SIGNAL(calibrationProcessFinished()));
    connect(manipulator,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));

    connect(manipulator, SIGNAL(ManXLimitsChanged(double, double)), this, SLOT(updateManipulatorLimits()));
    connect(manipulator, SIGNAL(ManYLimitsChanged(double, double)), this, SLOT(updateManipulatorLimits()));

    validRect   = QRectF(cameraWidth / 2.0, cameraHeight / 2.0, xPixelMax() - cameraWidth, yPixelMax() - cameraHeight);
    invalidRect = QRectF(0, 0, xPixelMax(), yPixelMax());

    //    lightDriver = new TMCM6110Driver485(Config("lightSystem"), this);
    //    lightSystem = new LibsLightSystemV2(lightDriver, 3, this);

    //    //    lightDriver->moveToThread(this->thread());
    //    //    lightSystem->moveToThread(this->thread());

    //    purgerDriver = new TMCM6110Driver485(Config("purger"), this);
    //    purger       = new LibsPurgingSystem(purgerDriver, 9, this);
    //    connect(purger,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    //    connect(lightSystem,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(this, SIGNAL(lightRing1SetIntensity(int)), lightSystem, SLOT(setLight1Intensity(int)));
    //    connect(this, SIGNAL(lightRing2SetIntensity(int)), lightSystem, SLOT(setLight2Intensity(int)));
    //    connect(this, SIGNAL(lightRing1On(bool)), lightSystem, SLOT(setLight1On(bool)));
    //    connect(this, SIGNAL(lightRing2On(bool)), lightSystem, SLOT(setLight2On(bool)));

    //    connect(m_mainCamera, &LIBSAbstractCameraClass::exposureTimeChanged, this,
    //    &LIBSStageV2::cameraExposureChanged); connect(m_mainCamera, &LIBSAbstractCameraClass::frameRateChanged, this,
    //    &LIBSStageV2::cameraFrameRateChanged);

    //    connect(this, &LIBSStageV2::requestCameraFrame, m_mainCamera, &LIBSAbstractCameraClass::getCurrentFrame);

    tcmDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    tcmDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);

    // shutterDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    // shutterDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);

    // purgerDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    // purgerDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);

    connect(tcmDriver,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(shutterDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(lightDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(purgerDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(
    //        purger, SIGNAL(logMessage(LIBS::messageType, QString)), this, SIGNAL(sendMessage(LIBS::messageType,
    //        QString)));

    //    // Pressure
    //    pressureDriver = new TMCM6110Driver485(Config("pressureSystem"), this);
    //    pressureSystem = new LibsPressureSystem(pressureDriver, 5, this);

    //    connect(pressureDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(pressureSystem,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    // Interlock
    interlockDriver = new TMCM6110Driver485(Config("interlockSystem"), this);
    interlockSystem = new LibsInterlockSystem(interlockDriver, 6, this);
    connect(interlockDriver,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    connect(interlockSystem,
            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));

    // Sample holder system
    //    sampleHolderDriver = new TMCM6110Driver485(Config("sampleHolderSystem"), this);
    //    sampleHolderSystem = new LibsSampleHolderSystem(sampleHolderDriver, 0x0a, this);
    //    connect(sampleHolderDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(sampleHolderSystem,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)),
    //            Qt::QueuedConnection);

    // Module temperature system
    temperatureDriver = new TMCM6110Driver485(Config("temperatureSystem"), this);
    temperatureSystem = new ModuleTemperatureSensor(temperatureDriver, 0x0a);
        connect(temperatureDriver,
                SIGNAL(logMessage(LIBS::messageType, QString)),
                this,
                SIGNAL(sendMessage(LIBS::messageType, QString)));
        connect(temperatureSystem,
                SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
                this,
                SIGNAL(sendMessage(LIBS::messageType, QString)),
                Qt::QueuedConnection);

    // Range finder system
    rangeFinderDriver = new TMCM6110Driver485(Config("rangeFinderSystem"), this);
    rangeFinderSystem = new ModuleRangeFinder(rangeFinderDriver, 0x0a);
        connect(temperatureDriver,
                SIGNAL(logMessage(LIBS::messageType, QString)),
                this,
                SIGNAL(sendMessage(LIBS::messageType, QString)));
        connect(temperatureSystem,
                SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
                this,
                SIGNAL(sendMessage(LIBS::messageType, QString)),
                Qt::QueuedConnection);

    //    // Sci-Trace motherboard system
    //    motherboardDriver = new TMCM6110Driver485(Config("motherboardSystem"), this);
    //    motherboardDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    //    motherboardDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    //    motherboardSystem = new LibsSciTraceMotherboardSystem(motherboardDriver, 0x0b, this);
    //    connect(motherboardDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(motherboardSystem,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    //    m_generalPurposeOutputModuleDriver = new TMCM6110Driver485(Config("generalPurposeOutputModule"), this);
    //    m_generalPurposeOutputModuleDriver->Port()->SetBaudRate(
    //        t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    //    m_generalPurposeOutputModuleDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    //    m_generalPurposeOutputModule = new LibsGeneralPurposeOutputModule(m_generalPurposeOutputModuleDriver, 0x66,
    //    this); connect(m_generalPurposeOutputModuleDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(m_generalPurposeOutputModule,
    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    //    segmentedLightDriver = new TMCM6110Driver485(Config("segmentedLightSystem"), this);
    //    segmentedLightDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    //    segmentedLightDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    //    segmentedLightSystem = new LibsSegmentedLightSystem(segmentedLightDriver, 3, this);
    //    //    connect(segmentedLightDriver,
    //    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //    //            this,
    //    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    //    connect(segmentedLightSystem,
    //    //            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
    //    //            this,
    //    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    delayGeneratorDriver = new TMCM6110Driver485(Config("delayGeneratorSystem"), this);
    delayGeneratorDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    delayGeneratorDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    delayGenerator = new LibsDelayGeneratorSystem(delayGeneratorDriver, 0x6a, this);
    connect(delayGeneratorDriver,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    connect(delayGenerator,
            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(delayGenerator, &LibsDelayGeneratorSystem::logMessage, [=](LIBS::messageType mType, QString str) {
    //        qDebug() << "DelayGeneratorSystem::logMessage(" << mType << ", \"" << str << "\"";
    //    });
    //    connect(delayGenerator, &LibsDelayGeneratorSystem::sendDebugMessage, [=](LIBS::messageType mType, QString str)
    //    {
    //        qDebug() << "DelayGeneratorSystem::sendDebugMessage(" << mType << ", \"" << str << "\"";
    //    });

    secondaryDelayGeneratorDriver = new TMCM6110Driver485(Config("secondaryDelayGeneratorSystem"), this);
    secondaryDelayGeneratorDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    secondaryDelayGeneratorDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    secondaryDelayGenerator = new LibsDelayGeneratorSystem(secondaryDelayGeneratorDriver, 0x6b, this);
    connect(secondaryDelayGeneratorDriver,
            SIGNAL(logMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    connect(secondaryDelayGenerator,
            SIGNAL(sendDebugMessage(LIBS::messageType, QString)),
            this,
            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(secondaryDelayGenerator, &LibsDelayGeneratorSystem::logMessage, [=](LIBS::messageType mType, QString
    //    str) {
    //        qDebug() << "LibsDelayGeneratorSystem::logMessage(" << mType << ", \"" << str << "\"";
    //    });
    //    connect(secondaryDelayGenerator,
    //            &LibsDelayGeneratorSystem::sendDebugMessage,
    //            [=](LIBS::messageType mType, QString str) {
    //                qDebug() << "LibsDelayGeneratorSystem::sendDebugMessage(" << mType << ", \"" << str << "\"";
    //            });

    //    extractorDriver = new TMCM6110Driver485(Config("extractorSystem"), this);
    //    extractorDriver->Port()->SetBaudRate(t_settings.value("private/ftdiPort/BaudRate", 500000).toInt());
    //    extractorDriver->Port()->SetDataCharacteristics(FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
    //    extractorSystem = new LibsExtractorSystem(extractorDriver, 107, this);
    //    connect(extractorDriver,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));
    //    connect(extractorSystem,
    //            SIGNAL(logMessage(LIBS::messageType, QString)),
    //            this,
    //            SIGNAL(sendMessage(LIBS::messageType, QString)));

    //    m_fastMappingWorker = new LIBSFastMappingWorker(this, nullptr, this);
}

LIBSStageV2::~LIBSStageV2() {
    manipulator->XAxis()->holdBreak();
    manipulator->YAxis()->holdBreak();
    manipulator->ZAxis()->holdBreak();
    manipulator->XAxis()->SetOutput(0, 2, 1);
    // m_mainCamera->deinitializeCamera();

    if (focuser->IsReferenced()) {
        focuser->MoveToPosition(0.0);
    }

    // autofocusThread->quit();
    // autofocusThread->wait();

    // delete autofocusThread;
    // delete autofocusWorker;

    delete tcmDriver;
    //    delete shutterDriver;
    //    delete lightDriver;

    // delete pressureDriver;
    delete interlockDriver;
    //    delete sampleHolderDriver;

    //    delete purgerDriver;
    //    delete segmentedLightDriver;
    //    delete motherboardDriver;
    delete delayGeneratorDriver;
    delete secondaryDelayGeneratorDriver;
    // delete extractorDriver;
    // delete m_generalPurposeOutputModuleDriver;
}

void LIBSStageV2::OpenDevices() {
    tcmDriver->Port()->OpenDevice();
    // shutterDriver->Port()->OpenDevice();
    // lightDriver->Port()->OpenDevice();
    // pressureDriver->Port()->OpenDevice();
    interlockDriver->Port()->OpenDevice();
    //    sampleHolderDriver->Port()->OpenDevice();

    //    purgerDriver->Port()->OpenDevice();
    //    motherboardDriver->Port()->OpenDevice();
    //    segmentedLightDriver->Port()->OpenDevice();
    delayGeneratorDriver->Port()->OpenDevice();
    secondaryDelayGeneratorDriver->Port()->OpenDevice();
    // extractorDriver->Port()->OpenDevice();
    // m_generalPurposeOutputModuleDriver->Port()->OpenDevice();
    emit openDevicesFinished();
}

void LIBSStageV2::generateMetricGrid(QGraphicsScene* scene, qreal gridsize) {
    QPen cosPen = QPen(QBrush(QColor(0x55, 0x57, 0x53)), 1, Qt::DashLine);
    cosPen.setCosmetic(true);
    QGraphicsLineItem* line;
    //    QGraphicsRectItem *rect;
    //    rect = scene->addRect(0,0,xPixelMax,yPixelMax,Qt::NoPen,QBrush(QColor(0xba,0xbd,0xb6)));
    //    rect->setZValue(0.1);
    /*    rect =
       scene->addRect(cameraWidth/2.0,0,xPixelMax-cameraWidth/2.0,cameraHeight/2.0,Qt::NoPen,QBrush(QColor(0xba,0xbd,0xb6,120)));
        rect->setZValue(0.1);
        rect =
       scene->addRect(xPixelMax-cameraWidth/2.0,cameraHeight/2.0,cameraWidth/2.0,yPixelMax-cameraHeight/2.0,Qt::NoPen,QBrush(QColor(0xba,0xbd,0xb6,120)));
        rect->setZValue(0.1);
        rect =
       scene->addRect(0,yPixelMax-cameraHeight/2.0,xPixelMax-cameraWidth/2.0,cameraHeight/2.0,Qt::NoPen,QBrush(QColor(0xba,0xbd,0xb6,120)));
        rect->setZValue(0.1);
        rect =
       scene->addRect(0,0,cameraWidth/2.0,yPixelMax-cameraHeight/2.0,Qt::NoPen,QBrush(QColor(0xba,0xbd,0xb6,120)));
        rect->setZValue(0.1);
    */ //    rect =
       //    scene->addRect(cameraWidth/2.0,cameraHeight/2.0,xPixelMax-cameraWidth,yPixelMax-cameraHeight,Qt::NoPen,QBrush(QColor(0xff,0xff,0xff)));
    //    rect->setZValue(-3);
    for (qreal x = 0; x <= ((qreal)(xPixelMax() + 1) * (qreal)pixToMmRatio) / 2.; x += gridsize) {
        qreal xPx = mapMmToPx(QPoint(x, 0)).x();
        line      = scene->addLine(xPx, 0, xPx, yPixelMax(), cosPen);
        line->setZValue(0.5);
        xPx  = mapMmToPx(QPoint(-x, 0)).x();
        line = scene->addLine(xPx, 0, xPx, yPixelMax(), cosPen);
        line->setZValue(0.5);
    }

    for (qreal y = 0; y <= (((qreal)yPixelMax() + 1) * (qreal)pixToMmRatio) / 2.; y += gridsize) {
        qreal yPx = mapMmToPx(QPoint(0, y)).y();
        line      = scene->addLine(0, yPx, xPixelMax(), yPx, cosPen);
        line->setZValue(0.5);
        yPx  = mapMmToPx(QPoint(0, -y)).y();
        line = scene->addLine(0, yPx, xPixelMax(), yPx, cosPen);
        line->setZValue(0.5);
    }
    QFont font(QString("Palatino linotype"), gridsize * 0.07 / pixToMmRatio, QFont::Normal);

    for (qreal x = 0; x <= ((xPixelMax() + 1) * pixToMmRatio) / 2.0; x += gridsize) {
        for (qreal y = 0; y <= ((yPixelMax() + 1) * pixToMmRatio) / 2.0; y += gridsize) {
            QPointF pos(x, y);
            pos = mapMmToPx(pos);
            QGraphicsSimpleTextItem* text =
                scene->addSimpleText(QString("(%1;%2)").arg(x, 0, 'f', 0).arg(y, 0, 'f', 0), font);
            text->setPos(pos);
            text->setZValue(0.5);
            if (x != 0 && y != 0) {
                pos  = QPointF(-x, -y);
                pos  = mapMmToPx(pos);
                text = scene->addSimpleText(QString("(%1;%2)").arg(-x, 0, 'f', 0).arg(-y, 0, 'f', 0), font);
                text->setPos(pos);
                text->setZValue(0.5);
            }
            if (y != 0) {
                pos  = QPointF(x, -y);
                pos  = mapMmToPx(pos);
                text = scene->addSimpleText(QString("(%1;%2)").arg(x, 0, 'f', 0).arg(-y, 0, 'f', 0), font);
                text->setPos(pos);
                text->setZValue(0.5);
            }
            if (x != 0) {
                pos  = QPointF(-x, y);
                pos  = mapMmToPx(pos);
                text = scene->addSimpleText(QString("(%1;%2)").arg(-x, 0, 'f', 0).arg(y, 0, 'f', 0), font);
                text->setPos(pos);
                text->setZValue(0.5);
            }
        }
    }
}

void LIBSStageV2::setLaserOffset(QPointF offset) {
    laserOffset = offset;
    validRect.moveTopLeft(offset);
    emit validRectangleChanged(this->validRect);
}

// void LIBSStage::callPosChangedInMm(int pos, int motorID){
//    qreal tmp = mapStepToMm(pos,motorID);
//    const QString s = QString::number(tmp);
//    if(motorID == 0){
//        emit xMotorPosChanged(s);
//        emit xMotorPosChanged(tmp);
//    }
//    else if(motorID == 1){
//        emit yMotorPosChanged(s);
//        emit yMotorPosChanged(tmp);
//    }
//    else{
//        emit zMotorPosChanged(s);
//        emit zMotorPosChanged(tmp);
//    }
//}

// void LIBSStageV2::getFrameFromCamera() {
//    if (m_mainCamera->cameraIsOpened()) {
//        if (mainShutter->shutterIsOpened())
//            emit requestCameraFrame(
//                mapMmToPx(QPointF(manipulator->XAxis()->GetRealPosition(), manipulator->YAxis()->GetRealPosition())),
//                manipulator->ZAxis()->GetRealPosition());
//    }
//    emit enableMotors();
//}

void LIBSStageV2::moveToHomePos() {
    emit disableMotorControl();
    manipulator->MoveManXToOrigin();
    manipulator->MoveManYToOrigin();
    manipulator->MoveManZToOrigin();
}

void LIBSStageV2::moveAllMotorsAbs(qreal xPos_mm, qreal yPos_mm, qreal zPos_mm) {
    emit disableMotorControl();
    manipulator->ManipulatorXMoveTo(xPos_mm);
    manipulator->ManipulatorYMoveTo(yPos_mm);
    manipulator->ManipulatorZMoveTo(zPos_mm);
}

void LIBSStageV2::moveXMotorAbs(double xPos_mm) {
    emit disableMotorControl();
    manipulator->ManipulatorXMoveTo(xPos_mm);
}

void LIBSStageV2::moveYMotorAbs(double yPos_mm) {
    emit disableMotorControl();
    manipulator->ManipulatorYMoveTo(yPos_mm);
}

void LIBSStageV2::moveZMotorAbs(double zPos_mm) {
    emit disableMotorControl();
    manipulator->ManipulatorZMoveTo(zPos_mm);
}

QPointF LIBSStageV2::mapPxToMm(QPointF pos) {
    qreal x = ((pos.x() - cameraWidth / 2.0) * (xLengt() / ((qreal)xPixelMax() - cameraWidth))) - xMmHalf();
    qreal y = yMmHalf() - ((pos.y() - cameraHeight / 2.0) * (yLengt() / ((qreal)yPixelMax() - cameraHeight)));
    return QPointF(-x, y);
}

QPointF LIBSStageV2::mapMmToPx(QPointF pos) {
    qreal x = ((-pos.x() + xMmHalf()) / ((xMmHalf() * 2.0) / ((qreal)xPixelMax() - cameraWidth))) +
              (((qreal)cameraWidth) / 2.0);
    qreal y =
        (qreal)cameraHeight / 2.0 - (pos.y() - yMmHalf()) / ((yMmHalf() * 2.0) / ((qreal)yPixelMax() - cameraHeight));
    return QPointF(x, y);
}

void LIBSStageV2::moveToXYAbsolute(QPointF pos) {
    emit disableMotorControl();
    manipulator->MoveToPos(mapPxToMm(pos));
}

void LIBSStageV2::centerLaserAtXY(QPointF pos) {
    emit disableMotorControl();
    pos = pos + QPointF(cameraWidth / 2., cameraHeight / 2.) - laserOffset;
    // qDebug() << "centerign laser to" << mapPxToMm(pos);
    manipulator->MoveToPos(mapPxToMm(pos));
}

void LIBSStageV2::init() {
    readSettings();

    // camera
    //    if (m_mainCamera->initializeCamera() != 0)
    //        emit cameraDisconnected();
    //    else {
    //        emit signalCameraConnected(-1, m_mainCamera->getFrameRate(), m_mainCamera->getExposure());
    //        connect(m_mainCamera, SIGNAL(autoExposureFinished()), this, SIGNAL(autoExposureFinished()));
    //    }
    //    connect(this, &LIBSStageV2::startAutoExposure, m_mainCamera, &LIBSAbstractCameraClass::startAutoExposure);

    // motors
    // manipulator->InitMotorParameters();
    // manipulator->XAxis()->SetOutput(0, 2, 1);
    focuser->InitMotorParameters();
    attenuator->InitMotorParameters();

    // check reference status
    //    mainShutter->shutterInit();
    //    lightSystem->init();
    //    pressureSystem->init();
    interlockSystem->init();
    //    sampleHolderSystem->init();
    //    purger->init();
    //    motherboardSystem->init();
    //    m_generalPurposeOutputModule->init();
    //    segmentedLightSystem->init();
    //    if (segmentedLightSystem->isEnabled()) {
    //        connect(this, &LIBSStageV2::closeShutter, [=](void) {
    //            SegmentedLightSystem()->setServoPosition(LibsSegmentedLightSystem::servoRight);
    //        });
    //        connect(this, &LIBSStageV2::openShutter, [=](void) {
    //            SegmentedLightSystem()->setServoPosition(LibsSegmentedLightSystem::servoLeft);
    //        });
    //    }
    //    extractorSystem->init();
    delayGenerator->init();
    secondaryDelayGenerator->init();
    //    m_fastMappingWorker->init();

    //    if (m_mainCamera->cameraIsOpened())
    //        getFrameFromCamera();
}

void LIBSStageV2::launchLaser() {
    emit sendMessage(LIBS::FatalError, QString("Laser unimplemented !!!!"));
    emit laserFinished();
}

bool LIBSStageV2::calibrationNeeded() {
    bool _calibrationNeeded = false;
    if (manipulator->XAxis()->AutoReference()) {
        if (manipulator->XAxis()->ReadReferenceStatus())
            manipulator->XAxis()->ReferenceSearch();
        else
            _calibrationNeeded = true;
    }
    if (manipulator->YAxis()->AutoReference()) {
        if (manipulator->YAxis()->ReadReferenceStatus())
            manipulator->YAxis()->ReferenceSearch();
        else
            _calibrationNeeded = true;
    }
    if (manipulator->ZAxis()->AutoReference()) {
        if (manipulator->ZAxis()->ReadReferenceStatus())
            manipulator->ZAxis()->ReferenceSearch();
        else
            _calibrationNeeded = true;
    }
    if (Focuser()->AutoReference()) {
        if (Focuser()->ReadReferenceStatus())
            Focuser()->ReferenceSearch();
        else
            _calibrationNeeded = true;
    }
    if (Attenuator()->AutoReference()) {
        if (Attenuator()->ReadReferenceStatus())
            Attenuator()->ReferenceSearch();
        else
            _calibrationNeeded = true;
    }
    if (!_calibrationNeeded) {
        emit sendMessage(LIBS::Info, QString("Motors seems calibrated from previous run, autocalibration refresh."));
        manipulator->ReferenceSearch();
        if (Focuser()->AutoReference())
            Focuser()->ReferenceSearch();
        if (Attenuator()->AutoReference())
            Attenuator()->ReferenceSearch();
    }
    return _calibrationNeeded;
}

void LIBSStageV2::calibrate(bool force) {

    if (force) {
        manipulator->forceReferenceSearch();
        if (Attenuator()->AutoReference())
            Attenuator()->ReferenceSearch(true);
        if (Focuser()->AutoReference())
            Focuser()->ReferenceSearch(true);
        emit calibrationProcessStarted();
        //        }
    } else {
        manipulator->ReferenceSearch();
        if (Focuser()->AutoReference())
            Focuser()->ReferenceSearch();
        if (Attenuator()->AutoReference())
            Attenuator()->ReferenceSearch();
        emit calibrationProcessStarted();
    }
}

// void LIBSStageV2::setCameraExposition(qreal val) {
//    m_mainCamera->setExposure(val);
//}

void LIBSStageV2::requestInitialSharpness() {
    emit disableMotorControl();
    this->moveAllMotorsAbs(manipulator->XAxis()->GetRealPosition(),
                           manipulator->YAxis()->GetRealPosition(),
                           manipulator->ZAxis()->GetRealPosition());
    // TODO: proc se posouva stage na souradnice na kterych uz je
}

void LIBSStageV2::readSettings() {
    QSettings settings;
    QSettings cam_settings("./primaryCamera.xml", QSettings::defaultFormat());
    //    this->setLaserOffset(settings.value("stage/laserOffset",QPointF(cameraWidth / 2.0, cameraHeight
    //    / 2.0)).toPointF()); QSettings
    //    stgs(LibsGlobalSettings::getInstance()->getPath(),LibsGlobalSettings::getInstance()->getFormat(),this);
    this->setLaserOffset(
        cam_settings.value("private/stage/laserOffset", QPointF(cameraWidth / 2.0, cameraHeight / 2.0)).toPointF());
    pixToMmRatio = (cam_settings.value("private/stage/pixToMmRatio", 0.25 / 197.314).toReal());
    validRect    = QRectF(cameraWidth / 2.0, cameraHeight / 2.0, xPixelMax() - cameraWidth, yPixelMax() - cameraHeight);
    invalidRect  = QRectF(0, 0, xPixelMax(), yPixelMax());

    //    m_mainCamera->setGain(settings.value("private/mainCamera/gain", 1).toDouble());
    //    m_mainCamera->setExposure(settings.value("private/mainCamera/exposure", 500).toDouble());
    //    m_mainCamera->setFrameRate(settings.value("private/mainCamera/fps", 20).toDouble());
    //    m_mainCamera->setWhiteR(settings.value("private/mainCamera/wbR", 1).toDouble());
    //    m_mainCamera->setWhiteG(settings.value("private/mainCamera/wbG", 1).toDouble());
    //    m_mainCamera->setWhiteB(settings.value("private/mainCamera/wbB", 1).toDouble());
    //    m_mainCamera->setGrayscale(settings.value("private/mainCamera/gray", false).toBool());
    //    m_mainCameraVigentteEnabled = settings.value("private/mainCamera/vignetteCompensation", false).toBool();
    //    if (m_mainCameraVigentteEnabled) {
    //        try {
    //            m_mainCameraVigentte.loadFrom("vignetteCorrection.bmp");
    //        } catch (...) {
    //            emit sendMessage(LIBS::Error, "Could not load vignette calibration settings, please calibrate it
    //            first");
    //        }
    //    }
    delayGenerator->readSettings();
    secondaryDelayGenerator->readSettings();
    // autofocusWorker->readSettings();
}

void LIBSStageV2::writeSettings() {
    QSettings settings;
    QSettings cam_settings("./primaryCamera.xml", QSettings::defaultFormat());
    //    settings.setValue("stage/laserOffset",laserOffset);

    //    QSettings
    //    stgs(LibsGlobalSettings::getInstance()->getPath(),LibsGlobalSettings::getInstance()->getFormat(),this);
    cam_settings.setValue("private/stage/laserOffset", laserOffset);
    cam_settings.setValue("private/stage/pixToMmRatio", pixToMmRatio);
    cam_settings.setValue("private/mainCamera/horizontalMirror", m_mirrorCamHorizontally);
    cam_settings.setValue("private/mainCamera/verticalMirror", m_mirrorCamVertically);

    //    settings.setValue("private/mainCamera/gain", m_mainCamera->getGain());
    //    settings.setValue("private/mainCamera/exposure", m_mainCamera->getExposure());
    //    settings.setValue("private/mainCamera/wbR", m_mainCamera->getWhiteR());
    //    settings.setValue("private/mainCamera/wbG", m_mainCamera->getWhiteG());
    //    settings.setValue("private/mainCamera/wbB", m_mainCamera->getWhiteB());
    //    settings.setValue("private/mainCamera/gray", m_mainCamera->isGrayscale());
    //    settings.setValue("private/mainCamera/vignetteCompensation", m_mainCameraVigentteEnabled);

    //    cam_settings.setValue("private/mainCamera/id", m_mainCamera->getID());
    FTDIinterface* ftdi = qobject_cast<FTDIinterface*>(tcmDriver->Port());
    if (ftdi)
        settings.setValue("private/ftdiPort/BaudRate", (int)ftdi->getBaudRate());
    //    if (m_mainCameraVigentteEnabled)
    //        m_mainCameraVigentte.saveTo("vignetteCorrection.bmp");
    delayGenerator->writeSettings();
    secondaryDelayGenerator->writeSettings();
    // autofocusWorker->writeSettings();
}

void LIBSStageV2::setPixToMmRatio(qreal p) {
    if (pixToMmRatio != p) {
        pixToMmRatio = p;
        validRect =
            QRectF(cameraWidth / 2.0, cameraHeight / 2.0, xPixelMax() - cameraWidth, yPixelMax() - cameraHeight);
        invalidRect = QRectF(0, 0, xPixelMax(), yPixelMax());
        emit pixToMmRatioChanged(pixToMmRatio);
    }
}

void LIBSStageV2::updateManipulatorLimits() {
    validRect   = QRectF(cameraWidth / 2.0, cameraHeight / 2.0, xPixelMax() - cameraWidth, yPixelMax() - cameraHeight);
    invalidRect = QRectF(0, 0, xPixelMax(), yPixelMax());
    emit manipulatorLimitsChanged();
}

QTransform LIBSStageV2::getTransform() {
    QTransform trans;
    QPointF center = mapMmToPx(QPointF(0.0, 0.0));

    trans.translate(center.x(), center.y());
    trans.scale((Stage()->XAxis()->Direction() ? -1.0 : 1.0) / pixToMmRatio,
                (Stage()->YAxis()->Direction() ? -1.0 : 1.0) / pixToMmRatio);
    return trans;
}

void LIBSStageV2::appendMetadata(QVariantMap& metaData) {
    if (tcmDriver->Port()->IsInitialised()) {
        if (manipulator->XAxis()->IsReferenced()) {
            if (!metaData.contains(QString("x")))
                metaData.insert(QString("x"), manipulator->XAxis()->GetRealPosition());
        }
        if (manipulator->YAxis()->IsReferenced()) {
            if (!metaData.contains(QString("y")))
                metaData.insert(QString("y"), manipulator->YAxis()->GetRealPosition());
        }
        if (manipulator->ZAxis()->IsReferenced()) {
            if (!metaData.contains(QString("z")))
                metaData.insert(QString("z"), manipulator->ZAxis()->GetRealPosition());
        }
        if (Focuser()->IsReferenced()) {
            if (!metaData.contains(QString("defocus")))
                metaData.insert(QString("defocus"), Focuser()->GetRealPosition());
        }
        if (Attenuator()->IsReferenced()) {
            if (!metaData.contains(QString("attenuator")))
                metaData.insert(QString("attenuator"), Attenuator()->GetRealPosition());
        }
    }
    //    if (sampleHolderDriver->Port()->IsInitialised()) {
    //        if (!metaData.contains(QString("internalPressure"))) {
    //            metaData.insert(QString("internalPressure"), 940.12);
    //        }
    //    }
}
