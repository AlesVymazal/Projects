#ifndef LIBSSTAGE_H
#define LIBSSTAGE_H

#define NOMINMAX

#include "LIBS.h"
//#include "autofocusworker.h"
//#include "libsabstractcameraclass.h"
#include "libsattenuator.h"
#include "libsdelaygeneratorsystem.h"
//#include "libsextractorsystem.h"
//#include "libsgeneralpurposeoutputmodule.h"
#include "libsinterlocksystem.h"
#include "../devices/libhardware/moduletemperaturesensor.h"
#include "../devices/libhardware/modulerangefinder.h"
//#include "libslightsystem.h"
//#include "libspressuresystem.h"
//#include "libspurgingsystem.h"
//#include "libssampleholdersystem.h"
//#include "libsscitracemotherboardsystem.h"
//#include "libssegmentedlightsystem.h"
//#include "libsshutter.h"
//#include "vignette.h"
#include <QGraphicsLineItem>
#include <QGraphicsScene>
#include <QObject>
#include <QSettings>
#include <QVariantMap>
#include <QVector2D>
#include <QtGlobal>
#include <math.h>
#include <qthread.h>

#include "hw_fixedlengthlinearaxis.h"
#include "hw_stage.h"

//#include "libsfastmappingworker.h"

// class LIBSFastMappingWorker;

//*********************************LIBSStageV2*********************************//
class LIBSStageV2 : public QObject {
    Q_OBJECT

public:
    LIBSStageV2(QObject* parent = nullptr);
    ~LIBSStageV2() override;

    enum constants {
        StepsPerMm = 3200,

        xMotorMax = 188960,
        xMotorMin = 67360,

        yMotorMax = 156960,
        yMotorMin = 35360,
        zMotorMax = 600000,
        zMotorMin = 960,

        cameraWidth  = 1280,
        cameraHeight = 1024,
        xMotorID     = 0,
        yMotorID     = 1,
        zMotorID     = 2
    };

    void generateMetricGrid(QGraphicsScene* scene, qreal gridsize);

    int getXMax() {
        return xPixelMax();
    }
    int getYMax() {
        return yPixelMax();
    }

    XYStage* Stage() {
        return manipulator;
    }

    //    LibsShutterV2* MainShutter() {
    //        return mainShutter;
    //    }
    //    LibsLightSystemV2* LightSystem() {
    //        return lightSystem;
    //    }
    //    LibsPressureSystem* PressureSystem() {
    //        return pressureSystem;
    //    }
    //    LibsSampleHolderSystem* SampleHolderSystem() {
    //        return sampleHolderSystem;
    //    }
    LibsInterlockSystem* InterlockSystem() {
        return interlockSystem;
    }
    LibsAttenuator* Attenuator() {
        return attenuator;
    }
    FixedLengthLinearAxis* Focuser() {
        return focuser;
    }

    ModuleTemperatureSensor* TemperatureSystem() {
        return temperatureSystem;
    }

    ModuleRangeFinder * RangeFinderSystem(){
        return rangeFinderSystem;
    }


    //    LibsPurgingSystem* Purger() {
    //        return purger;
    //    }
    //    LibsSciTraceMotherboardSystem* SciTraceMoterboard() {
    //        return motherboardSystem;
    //    }
    //    LibsSegmentedLightSystem* SegmentedLightSystem() {
    //        return segmentedLightSystem;
    //    }
    //    LibsExtractorSystem* ExtractorSystem() {
    //        return extractorSystem;
    //    }

    LibsDelayGeneratorSystem* DelayGeneratorSystem() {
        return delayGenerator;
    }
    LibsDelayGeneratorSystem* SecondaryDelayGeneratorSystem() {
        return secondaryDelayGenerator;
    }

    //    LibsGeneralPurposeOutputModule* GeneralPurposeOutputModule() {
    //        return m_generalPurposeOutputModule;
    //    }

    //    LIBSAbstractCameraClass* MainCamera() {
    //        return m_mainCamera;
    //    }
    //    void setMainCamera(LIBSAbstractCameraClass* c) {
    //        m_mainCamera = c;
    //    }

    bool mainCameraVignetteCompensation() {
        return m_mainCameraVigentteEnabled;
    }

    qreal getZPosMm() {
        return manipulator->ZAxis()->GetRealPosition();
    }
    QPointF getRealPosition() {
        return QPointF(manipulator->XAxis()->GetRealPosition(), manipulator->YAxis()->GetRealPosition());
    }

    QPointF mapPxToMm(QPointF pos);
    QPointF mapMmToPx(QPointF pos);

    QPointF getLaserOffset() {
        return laserOffset;
    }

    QRectF getValidRect() {
        return validRect;
    }
    QRectF getInvalidRect() {
        return invalidRect;
    }

    //    bool isShutterEnabled() {
    //        if (this->mainShutter)
    //            return mainShutter->shutterIsEnabled();
    //        else
    //            return false;
    //    }
    //    bool isShutterOpened() {
    //        bool shtM = false;
    //        if (this->mainShutter)
    //            shtM = mainShutter->shutterIsOpened();
    //        bool shtS = false;
    //        if (this->segmentedLightSystem) {
    //            shtS = segmentedLightSystem->shutterIsOpened();
    //        }
    //        return shtM | shtS;
    //    }

    bool isMotorConnected() {
        return manipulator->Driver()->Port()->IsInitialised();
    }

    qreal getPixToMmRatio() {
        return pixToMmRatio;
    }

    void setPixToMmRatio(qreal p);
    QTransform getTransform();

    void appendMetadata(QVariantMap& metaData);
    //    AutofocusWorker* AutoFocusWorker() {
    //        return autofocusWorker;
    //    }

    //    LIBSFastMappingWorker* FastMappingWorker() {
    //        return m_fastMappingWorker;
    //    }

    Q_INVOKABLE bool calibrationNeeded();

signals:
    void sendMessage(LIBS::messageType mType, QString msg);
    void frameFromCamera(QPixmap frame, QPointF pos, double z);
    void liveFrameFromCamera(QPixmap frame);
    void stageCenterChanged(QPointF pos);

    void curPosChangedPx(QPointF pos);

    void enableMotors();

    void xMotorPosChanged(QString pos);
    void yMotorPosChanged(QString pos);
    void zMotorPosChanged(QString pos);

    void xMotorPosChanged(double pos);
    void yMotorPosChanged(double pos);
    void zMotorPosChanged(double pos);

    void disableMotorControl();

    void motorsDisconnected();
    void cameraDisconnected();

    void signalCameraConnected(int, double, double);

    void calibrationProcessStarted();
    void calibrationProcessFinished();
    void updateStatusBar(const QString msg, int time);

    void motorMovementFinished();
    void autofocusFinished();
    void laserFinished();

    void validRectangleChanged(QRectF valid);
    void invalidRectangleChanged(QRectF invalid);

    void shutterOpened();
    void shutterClosed();
    void shutterStateChanged(bool opened);

    void closeShutter();
    void openShutter();
    void lightRing1On(bool on);
    void lightRing2On(bool on);
    void lightRing1SetIntensity(int intensity);
    void lightRing2SetIntensity(int intensity);

    void updateSharpness(double sharp, double pos);

    void setCameraPixelClock(int clock);
    void setCameraMasterGain(int gain);
    void cameraMasterGainChanged(double gain);
    void cameraExposureChanged(double ex);
    void cameraPixelClockChanged(double px);
    void cameraFrameRateChanged(double fr);

    void requestCameraFrame(QPointF pos, double z);

    void startAutofocus();
    void cancelAutofocus();
    void startFineAutofocus();
    void setBinaryFinalStepSize(double stepSize);

    void autoExposureFinished();
    void startAutoExposure();

    void pixToMmRatioChanged(qreal pixTm);
    void manipulatorLimitsChanged();

    void initialAutofocusMoveZ();

    void openDevicesFinished();

public slots:
    void Stop() {
        manipulator->MotorStop();
    }

    void readSettings();
    void writeSettings();
    void clearSettings() {
    }

    void moveXRelative(qreal mm_pos) {
        emit disableMotorControl();
        manipulator->ManipulatorXMoveRelative(mm_pos);
    }
    void moveYRelative(qreal mm_pos) {
        emit disableMotorControl();
        manipulator->ManipulatorYMoveRelative(mm_pos);
    }
    void moveZRelative(qreal mm_pos) {
        emit disableMotorControl();
        manipulator->ManipulatorZMoveRelative(mm_pos);
    }

    void moveAllMotorsAbs(qreal xPos_mm, qreal yPos_mm, qreal zPos_mm);

    void moveXMotorAbs(double xPos_mm);
    void moveYMotorAbs(double yPos_mm);
    void moveZMotorAbs(double zPos_mm);

    void calibrate(bool force = false);
    void setLaserOffset(QPointF offset);

    void centerLaserAtXY(QPointF pos);
    void moveToXYAbsolute(QPointF pos);
    //    void getFrameFromCamera(QPointF pos);
    // void getFrameFromCamera();
    // void setCameraExposition(qreal val);
    void moveToHomePos();
    void requestInitialSharpness();

    void launchLaser();

    void init();

    //! otevre porty podle posledniho nastaveni
    void OpenDevices();

    void updateManipulatorLimits();

    void enableMainCameraVignetteCompensation(bool b) {
        m_mainCameraVigentteEnabled = b;
    }
    void calibrateMainCameraVignetteCompensation() {
        m_mainCameraVignetteCompensation = true;
    }

private:
    int xPixelMax() {
        return cameraWidth + xLengt() / pixToMmRatio;
    }
    int yPixelMax() {
        return cameraWidth + yLengt() / pixToMmRatio;
    }

    double xMmHalf() {
        return xLengt() / 2;
    }
    double yMmHalf() {
        return yLengt() / 2;
    }

    //! delka osy x v mm
    double xLengt() {
        return manipulator->XAxis()->StartPosition() - manipulator->XAxis()->StopPosition();
    }
    //! delka osy y v mm
    double yLengt() {
        return manipulator->YAxis()->StartPosition() - manipulator->YAxis()->StopPosition();
    }

    int xCur;
    int yCur;

    QPointF curPosPx;    // actual position in pix
    QPointF laserOffset; // calibration of the laser pointer

    int canvasHeight;
    int canvasWidth;
    qreal pixToMmRatio;
    qreal pixToStepRatio;

    // LIBSAbstractCameraClass* m_mainCamera{nullptr};
    // Vignette m_mainCameraVigentte;
    bool m_mainCameraVigentteEnabled{false};
    bool m_mainCameraVignetteCompensation{false};
    bool m_mirrorCamVertically{false};
    bool m_mirrorCamHorizontally{true};

    // QThread* autofocusThread;

    // AutofocusWorker* autofocusWorker;

    QRectF validRect;
    QRectF invalidRect;

    // LibsShutterV2* mainShutter;
    // LibsLightSystemV2* lightSystem;

    //    QThread *cameraThread;

    XYStage* manipulator;
    TMCM6110Driver485 *tcmDriver, *interlockDriver, *temperatureDriver, *rangeFinderDriver /*, *sampleHolderDriver,
        *purgerDriver, *motherboardDriver, *segmentedLightDriver, *shutterDriver, *lightDriver, *pressureDriver*/;

    // LibsPressureSystem* pressureSystem;
    LibsInterlockSystem* interlockSystem;
    // LibsSampleHolderSystem* sampleHolderSystem;

    LibsAttenuator* attenuator;
    FixedLengthLinearAxis* focuser;

    ModuleTemperatureSensor* temperatureSystem;
    ModuleRangeFinder* rangeFinderSystem;
    // LibsPurgingSystem* purger;
    // LibsSciTraceMotherboardSystem* motherboardSystem;
    // LibsSegmentedLightSystem* segmentedLightSystem;

    TMCM6110Driver485* delayGeneratorDriver;
    LibsDelayGeneratorSystem* delayGenerator;
    TMCM6110Driver485* secondaryDelayGeneratorDriver;
    LibsDelayGeneratorSystem* secondaryDelayGenerator;

    // TMCM6110Driver485* extractorDriver;
    // LibsExtractorSystem* extractorSystem;

    // TMCM6110Driver485* m_generalPurposeOutputModuleDriver;
    // LibsGeneralPurposeOutputModule* m_generalPurposeOutputModule;
    // LIBSFastMappingWorker* m_fastMappingWorker;
};

#endif // LIBSSTAGE_H
